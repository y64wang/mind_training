package cn.candone.appstepfun;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.umeng.analytics.MobclickAgent;

import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class SquareFragment extends Fragment {
	private final String mPageName = "SquareFragment";
	
	private SquareListFragment mSquareListFragment;
	
	public SquareFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.main_square_fragment, container, false);

    	MainActivity mainAct = (MainActivity) getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_SQUARE);
        }		
		
        ExecuteGetFamouseGroup(mainAct.mPerfData.getUserID());
        
		FragmentTransaction t = getActivity().getSupportFragmentManager().beginTransaction();
		mSquareListFragment = new SquareListFragment();
		t.replace(R.id.public_grouplist, mSquareListFragment);
		t.commit();

		return rootView;
	}

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
		
	private CallbackListener GetFamouseGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(getActivity(), HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"groupCount":2,"result":"success","groups":
				 *  [{"userCount":5,"users":[{"userId":"53984e3bbe2549fe3895f3fa",
				 *  "userName":"tony@test1"},{"userId":"53986869be258b40ec6975a7",
				 *  "userName":"̫������","photoUrl":"xxxx"},{"userId":"539d1d5d66115e3c0e564e07","userName":"tony"},
				 *  {"userId":"539d364066115e3c0e564e08","userName":"tony","photoUrl":"xxxx"},
				 *  {"userId":"539d38fb66115e3c0e564e0b","userName":"������","photoUrl":"xxxx"}]
				 *  ,"groupName":"C1"},{"userCount":2,"users":
				 *  [{"userId":"53986869be258b40ec6975a7","userName":"̫������","photoUrl":"xxxx"},
				 *  {"userId":"539d99b466115e3c0e564e25","userName":"ɺɺ"}],"groupName":"������"}]}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						System.out.println("get faouse group success ");
						//System.out.println(obj.toString());
						SetFamousGroup(obj);
						
					}else{
						Toast.makeText(getActivity(), "���޹㳡��ɼ���...", Toast.LENGTH_SHORT).show();
						System.out.println("get famous group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("GetFamouseGroup: parse famous group result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteGetFamouseGroup(String userId) {
    	
    	if(userId.equals("")){
    		return;
    	}
    	
        JSONObject getGroupObj = new JSONObject();  

        /**
         * json={"userId":"5392ea8572d69e4d30d22faf"}
         */
        try {
        	getGroupObj.put("userId", userId);

		} catch (JSONException e) {
			e.printStackTrace();
		}
        String getGroupStr = "json=" + getGroupObj.toString();
        
        //System.out.println(getGroupStr);
        
    	HttpConnection conn = new HttpConnection();
    	conn.post("/group/getfamousgroups", getGroupStr, GetFamouseGroupCallbackListener);
    }

    private void SetFamousGroup(JSONObject obj){
		try{
			MainActivity mainAct = (MainActivity) getActivity();
			
			int groupCount = Integer.parseInt(obj.getString("groupCount"));
 
			if(groupCount > 0){
				JSONArray famousGroupArray = new JSONArray();
				JSONArray groupArray = obj.getJSONArray("groups");
				for(int i=0; i<groupArray.length(); i++){
					JSONObject groupEntry = groupArray.getJSONObject(i);
					String groupName = groupEntry.getString("groupName");
					
					int myFamousGroupCount = mainAct.mFamousGroupArray.length();
					boolean isGroupExist = false;
					for(int l=0; l<myFamousGroupCount; l++){
						JSONObject myFamousGroupEntry = mainAct.mFamousGroupArray.getJSONObject(l);
						String myFamousGroupName = myFamousGroupEntry.getString("groupName");
						if(groupName.equals(myFamousGroupName)){
							isGroupExist = true;
							break;
						}
					}
					if(isGroupExist){
						continue;
					}
					
					String target = "������";
					if(groupEntry.has("dailyTarget")){
						target = groupEntry.getString("dailyTarget");
					}
					String ownerId = groupEntry.getString("owner");
					String ownerIconUrl = "";
					String userIconUrl[] = new String[3];
					
					int iconCount = 0;
 					
					JSONArray userArray = groupEntry.getJSONArray("users");
					int userCount = userArray.length();
					for(int j=0; j<userCount; j++){
						JSONObject userEntry = userArray.getJSONObject(j);
						
						String userId = userEntry.getString("userId");
						if(userId.equals(ownerId)){
							if(userEntry.has("photoUrl")){
								ownerIconUrl = userEntry.getString("photoUrl");
								if(ownerIconUrl.toLowerCase().startsWith("http://localhost")){
								    ownerIconUrl = "";
								}								
							}else{
								ownerIconUrl = "";
							}
						}else{
							if(userEntry.has("photoUrl") && iconCount < 3 ){
								String url = userEntry.getString("photoUrl");
								if(!url.toLowerCase().startsWith("http://localhost")){
									userIconUrl[iconCount] = url;
									iconCount ++;
								}
							}
						}
						userEntry.put("steps", "0");
					}

					for(int m=iconCount; m<3; m++){
						userIconUrl[m] = "";
					}
					
					JSONObject groupNameObj = new JSONObject();
					groupNameObj.put("groupName", groupName);
					groupNameObj.put("dailyTarget", target);
					groupNameObj.put("ownerPhotoUrl", ownerIconUrl);
					groupNameObj.put("userPhotoUrl1", userIconUrl[0]);
					groupNameObj.put("userPhotoUrl2", userIconUrl[1]);
					groupNameObj.put("userPhotoUrl3", userIconUrl[2]);
					
					groupNameObj.put("userNumber", userCount);
					groupNameObj.put("users", userArray);
					famousGroupArray.put(groupNameObj);
				}
				
				mSquareListFragment.SetFamousGroupListView(famousGroupArray);
			}
		}catch(Exception e){
			System.out.println("SetActivityGroup: " + e.toString());
    		return;
    	};
    }

}
