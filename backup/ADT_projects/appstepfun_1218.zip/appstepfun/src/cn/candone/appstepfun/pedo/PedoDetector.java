package cn.candone.appstepfun.pedo;

import java.util.ArrayList;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class PedoDetector implements SensorEventListener {

    private ArrayList<PedoListener> mPedoListeners = new ArrayList<PedoListener>();

    private float   mLimit = 5.86f;

    public void setSensitivity(float sensitivity) {
        mLimit = sensitivity; // 1.97  2.96  4.44  6.66  10.00  15.00  22.50  33.75  50.62
    }

    /**
    private float   mLastValues[] = new float[3*2];
    private float   mScale[] = new float[2];
    private float   mYOffset;

    private float   mLastDirections[] = new float[3*2];
    private float   mLastExtremes[][] = { new float[3*2], new float[3*2] };
    private float   mLastDiff[] = new float[3*2];
    private int     mLastMatch = -1;
	
	public PedoDetector(){
        int h = 480; // TODO: remove this constant
        mYOffset = h * 0.5f;
        mScale[0] = - (h * 0.5f * (1.0f / (SensorManager.STANDARD_GRAVITY * 2)));
        mScale[1] = - (h * 0.5f * (1.0f / (SensorManager.MAGNETIC_FIELD_EARTH_MAX)));
	}


   
    //private int logCount = 0;
	public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor; 
        synchronized (this) {
	        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
	        	//logCount++;
	        	//if(logCount > 100 ){
	        	//	System.out.println("onSensorChanged. x: "+ event.values[0]+ " y: " + event.values[1] + " z: " + event.values[2]);
	        	//	logCount = 0;
	        	//}
		        float vSum = 0;
		        for (int i=0 ; i<3 ; i++) {
		            final float v = mYOffset + event.values[i] * mScale[1];
		            vSum += v;
		        }
		        int k = 0;
		        float v = vSum / 3;
		        
		        float direction = (v > mLastValues[k] ? 1 : (v < mLastValues[k] ? -1 : 0));
		        if (direction == - mLastDirections[k]) {
		            // Direction changed
		            int extType = (direction > 0 ? 0 : 1); // minumum or maximum?
		            mLastExtremes[extType][k] = mLastValues[k];
		            float diff = Math.abs(mLastExtremes[extType][k] - mLastExtremes[1 - extType][k]);
		
		            if (diff > mLimit) {
		                
		                boolean isAlmostAsLargeAsPrevious = diff > (mLastDiff[k]*2/3);
		                boolean isPreviousLargeEnough = mLastDiff[k] > (diff/3);
		                boolean isNotContra = (mLastMatch != 1 - extType);
		                
		                if (isAlmostAsLargeAsPrevious && isPreviousLargeEnough && isNotContra) {
		                    for (PedoListener stepListener : mPedoListeners) {
		                    	System.out.println("onStep called");
		                        stepListener.onStep();
		                    }
		                    mLastMatch = extType;
		                }
		                else {
		                    mLastMatch = -1;
		                }
		            }
		            mLastDiff[k] = diff;
		        }
		        mLastDirections[k] = direction;
		        mLastValues[k] = v;
	        }
        }
	}
**/
    private static final int SPEED_UP = 1;
    private static final int SLOW_DOWN = -1;
    
    private float mLastValue = 0;
    private float mMaxValue = 0;
    private float mMinValue = 10000;
    private float mPreMaxValue = 0;
    private float mPreMinValue = 10000;
    private float mDirection = SPEED_UP;
    private long mLastStepTimeMills = 0;
    private long mDynamicLimitRefreshTimeMills = 0;
    
    public PedoDetector(){
    	mLastStepTimeMills = System.currentTimeMillis();
    	mDynamicLimitRefreshTimeMills = System.currentTimeMillis();
	}
    
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor; 
        synchronized (this) {
	        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
	        	float curValue = 0;
	        	float tempMax, tempMin;
	        	float diff = 0;
        	
	        	for(int i=0; i<3; i++){
	        		curValue += (event.values[i] * event.values[i]);
	        	}
	        	curValue = (float) Math.sqrt(curValue);  // curValue = sqrt(x^2 + y^2 + z^2)
	        	
	        	curValue = mLastValue * 0.2f + curValue * 0.8f;   // smooth the curValue
	        	
	        	long curTime = System.currentTimeMillis();
	        	
	        	if((curValue > mLastValue) && (mDirection == SLOW_DOWN)){
	        		mDirection = SPEED_UP;
	        		tempMin = mLastValue;
	        		diff = Math.abs(mPreMaxValue - tempMin);
        			mPreMinValue = tempMin;
	        		if(diff > mLimit ){
		            	//System.out.println("DOWN diff:" + diff);
	        			if(mMinValue > mPreMinValue){
	        				mMinValue = mPreMinValue;
	        			}
	        			long duration = curTime - mLastStepTimeMills;
	        			float dynamicLimit = (mMaxValue - mMinValue); 
	        			if(duration > 100 && diff > (dynamicLimit/3) && diff <(dynamicLimit * 10)){   /// step duration > 100ms = 0.1s 
	                    	//System.out.println("onStep called");
		                    for (PedoListener stepListener : mPedoListeners) {
		                        stepListener.onStep();
		                    }
		                    mLastStepTimeMills = curTime;
	        			}
	        		}
	        	}else if((curValue < mLastValue) && (mDirection == SPEED_UP)){
	        		mDirection = SLOW_DOWN;
	        		tempMax = mLastValue;
        			mPreMaxValue = tempMax;
	        		diff = Math.abs(tempMax - mPreMinValue);
	        		if(diff > mLimit){
		            	//System.out.println("UP diff:" + diff);
	        			if(mMaxValue < mPreMaxValue){
	        				mMaxValue = mPreMaxValue;
	        			}
	        		}
	        	}
	        	
	        	if((curTime - mDynamicLimitRefreshTimeMills) > 5000 ){
	        		/// refresh dynamical limit every 5s
	        		mMaxValue = 0;
	        		mMinValue = 10000;
	        		mDynamicLimitRefreshTimeMills = curTime;
	        	}
	        	
	        	mLastValue = curValue;
	        }
        }
	}
    public void addPedoListener(PedoListener sl) {
        mPedoListeners.add(sl);
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // TODO Auto-generated method stub
    }
    
    public float getCurrentDynamicLimit(){
    	return (mMaxValue - mMinValue);
    }
}
