package cn.candone.appstepfun;

import java.util.Calendar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.candone.appstepfun.graphview.GraphView;
import cn.candone.appstepfun.graphview.GraphViewDataInterface;
import cn.candone.appstepfun.graphview.GraphViewSeries;
import cn.candone.appstepfun.graphview.SimpleBarGraphView;
import cn.candone.appstepfun.graphview.ValueDependentColor;
import cn.candone.appstepfun.graphview.GraphView.GraphViewData;
import cn.candone.appstepfun.graphview.GraphViewSeries.GraphViewSeriesStyle;
import cn.candone.appstepfun.graphview.GraphViewStyle.GridStyle;
import cn.candone.appstepfun.widget.SwitchBox;

/**
 * A placeholder fragment containing all views.
 * The default view is the user login view.
 */
public class TrainingFragment extends Fragment {
	private final String mPageName = "TrainingFragment";

	public final static int PLAN_NOTSTARTED = 0;
	public final static int PLAN_INPROGRESS = 1;
	public final static int PLAN_COMPLETED = 2;
	
	private TextView mTrainingPlanName;
	private TextView mTrainingIntroduction;
	private LinearLayout mPlanChart;
	private Button mTrainingButton;
	private TextView mTrainingLevel;

    public TrainingFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

    	MainActivity mainAct = (MainActivity) getActivity();

        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_MOREPLAN);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_TRAINING);
        }		
		
    	View rootView = inflater.inflate(R.layout.main_training_fragment, container, false);
    	
    	mTrainingPlanName = (TextView) rootView.findViewById(R.id.training_name);
    	mTrainingIntroduction = (TextView) rootView.findViewById(R.id.training_introduction);
    	
    	mPlanChart = (LinearLayout) rootView.findViewById(R.id.training_planchart);
    	mTrainingButton = (Button) rootView.findViewById(R.id.training_joinButton);
    	
    	mTrainingLevel = (TextView)rootView.findViewById(R.id.training_level);
    	
    	mTrainingButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				TransToTrainingDetailFragment();
			}
		});
    	
    	String planName = mainAct.mPerfData.getCurrentPlans();
    	if(planName.equals("")){
    		planName = "���������ȼƻ�";
    		mainAct.mPerfData.setCurrentPlans(planName);
    	}

    	ShowTrainingPlan(planName);
    	
        return rootView;
    }
    
    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
	
	private void TransToTrainingDetailFragment(){
    	
    	MainActivity mainAct = (MainActivity)getActivity();
    	Fragment mainfragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_TRAININGDETAIL);
    	if(mainfragment == null){
        	Fragment currentfragment= mainAct.getSupportFragmentManager().findFragmentById(R.id.container);
        	mainAct.PushCurrentFragment(currentfragment.getTag());
        	
        	mainfragment = new TrainingDetailFragment();
        	FragmentTransaction t = mainAct.getSupportFragmentManager().beginTransaction();
        	t.add(R.id.container, mainfragment, MainActivity.TAG_FRAGMENT_TRAININGDETAIL);
            t.remove(currentfragment);
            t.commit();
    	}
    }
    

    private void ShowTrainingPlan(String planName){
    	
    	MainActivity mainAct = (MainActivity) getActivity();
    	String introduction = "";
    	String level="Lv1";
    	
    	if(planName.equals("���������ȼƻ�")){
    		introduction = getResources().getString(R.string.bellyrecoveryplan);
    		level = "Lv1";
    	}else if(planName.equals("�����߿����ƻ�")){
    		introduction = getResources().getString(R.string.bellyimprovementplan);
    		level = "Lv2";
    	}else if(planName.equals("��������ǿ�ƻ�")){
    		introduction = getResources().getString(R.string.bellyenhancementplan);
    		level = "Lv3";
    	}else if(planName.equals("�����߱��ּƻ�")){
    		introduction = getResources().getString(R.string.bellymaintainingplan);
    		level = "Lv4";
    	}else{
    		planName = "���������ȼƻ�";
    		introduction = getResources().getString(R.string.bellyrecoveryplan);
    		level = "Lv1";
    	}
    	
    	mTrainingPlanName.setText(planName);
    	mTrainingIntroduction.setText(introduction);
    	mTrainingLevel.setText(level);
    	
    	String buttonStr = "";
    	int color = MainActivity.COLOR_SKYBLUE;
       	int planStatus = mainAct.GetPlanStatus(planName);
      	if(planStatus == PLAN_NOTSTARTED){
    		buttonStr = "��ʼѵ����";
    	}else if(planStatus == PLAN_INPROGRESS){
    		buttonStr = "ѵ���У��鿴һ��";
    		color = MainActivity.COLOR_ORANGE;
    	}else if(planStatus == PLAN_COMPLETED){
    		buttonStr = "ѵ���ѽ������鿴���";
    	}
    	
    	mTrainingButton.setBackgroundColor(color);
    	mTrainingButton.setText(buttonStr);
    	
      	GraphViewData[] graphDataSet = new GraphViewData[28];
    	int[] taregetSteps = GetPlanTarget(planName, 0);
      	for(int i=0; i<7; i++){
      		//System.out.println( i + ":" +  taregetSteps[i]);
      		graphDataSet[i] = new GraphViewData(i, taregetSteps[i]);
      	}
    	taregetSteps = GetPlanTarget(planName, 1);
      	for(int i=0; i<7; i++){
      		//System.out.println( (i+7) + ":" +  taregetSteps[i]);
      		graphDataSet[i+7] = new GraphViewData(i+7, taregetSteps[i]);
      	}
    	taregetSteps = GetPlanTarget(planName, 2);
      	for(int i=0; i<7; i++){
      		graphDataSet[i+14] = new GraphViewData(i+14, taregetSteps[i]);
      	}

      	taregetSteps = GetPlanTarget(planName, 3);
      	for(int i=0; i<7; i++){
      		graphDataSet[i+21] = new GraphViewData(i+21, taregetSteps[i]);
      	}
      	
    	GraphViewSeriesStyle seriesStyle = new GraphViewSeriesStyle();
      	seriesStyle.setValueDependentColor(new ValueDependentColor() {
      	  //@Override
      	  //public int get(GraphViewDataInterface data) {
      	  //  return Color.CYAN;
      	  //}
      		
      	  @Override
    	  public int get(GraphViewDataInterface data, double max) {
    		if(max <= 0 ){ max = 10000;}
    	    // the higher the more green
    	    return Color.rgb((int)((1.0f-data.getY()/max)*255), 255, (int)((data.getY()/max)*255));
    	  }
    	});

       	GraphViewSeries hourStepSeries = new GraphViewSeries("TrainingSteps", seriesStyle, graphDataSet);

        // graph with dynamically genereated horizontal and vertical labels
        GraphView graphView = new SimpleBarGraphView(
                    getActivity(), // context
                    "" // heading
            );
       ((SimpleBarGraphView) graphView).setDrawValuesOnTop(true);
       ((SimpleBarGraphView) graphView).setValueUnit("��");
       ((SimpleBarGraphView) graphView).setValuesOnTopColor(getResources().getColor(R.color.orange));
       ((SimpleBarGraphView) graphView).setShowVerticalLabels(false);
       ((SimpleBarGraphView) graphView).setManualYAxis(false);

        // custom static labels
        graphView.setHorizontalLabels(new String[] {"","","","","","1��","","","","","","","2��","","","","","","","3��","","","","","","4��",""});
        graphView.setVerticalLabels(new String[] {""});
        graphView.getGraphViewStyle().setGridStyle(GridStyle.NONE);
        graphView.getGraphViewStyle().setHorizontalLabelsColor(MainActivity.COLOR_SKYBLUE);
        graphView.addSeries(hourStepSeries); // data

        mPlanChart.removeAllViews();
        mPlanChart.addView(graphView);		
    }
	
    public static int[] GetPlanTarget(String planName, int week){
    	int[] target = new int[7];
    	
    	if(planName.equals("���������ȼƻ�")){
    		target[0]=10000+week*2500;
    		target[1]=12000+week*2500;
    		target[2]=14000+week*2500;
    		target[3]=16000+week*2500;
    		target[4]=14000+week*2500;
    		target[5]=12000+week*2500;
    		target[6]=10000+week*2500;
        }else if(planName.equals("�����߿����ƻ�")){
        	target[0]=12000+week*3000;
        	target[1]=14000+week*3000;
            target[2]=16000+week*3000;
            target[3]=18000+week*3000;
            target[4]=16000+week*3000;
            target[5]=14000+week*3000;
            target[6]=12000+week*3000;
            
        }else if(planName.equals("��������ǿ�ƻ�")){
        	target[0]=14000+week*3500;
            target[1]=16000+week*3500;
            target[2]=18000+week*3500;
            target[3]=20000+week*3500;
            target[4]=18000+week*3500;
            target[5]=16000+week*3500;
            target[6]=14000+week*3500;
        }else if(planName.equals("�����߱��ּƻ�")){
        	target[0]=16000+week*4000;
        	target[1]=18000+week*4000;
        	target[2]=20000+week*4000;
        	target[3]=22000+week*4000;
        	target[4]=20000+week*4000;
            target[5]=18000+week*4000;
            target[6]=16000+week*4000;
        }else{
        	target[0]=10000+week*2000;
        	target[1]=12000+week*2000;
            target[2]=14000+week*2000;
            target[3]=16000+week*2000;
            target[4]=14000+week*2000;
            target[5]=12000+week*2000;
            target[6]=10000+week*2000;
        }
    	
    	return target;
    }
}

