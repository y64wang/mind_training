package cn.candone.appstepfun;


import cn.candone.appstepfun.R;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MenuListFragment extends ListFragment {
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.list, null);
	}

	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		MenuAdapter adapter = new MenuAdapter(getActivity());

		adapter.add(new MenuItem("����Ȧ", R.drawable.menu_groupicon));
		adapter.add(new MenuItem("�Ʋ���", R.drawable.menu_pedometericon));
		adapter.add(new MenuItem("��    ��", R.drawable.menu_maprunicon));
		adapter.add(new MenuItem("��    ��", R.drawable.menu_rankingicon));
		adapter.add(new MenuItem("��    ��", R.drawable.menu_trainingicon));
		adapter.add(new MenuItem("��    ��", R.drawable.menu_shouting));
		setListAdapter(adapter);
	}
	
	private class MenuItem {
		public String tag;
		public int iconRes;
		public MenuItem(String tag, int iconRes) {
			this.tag = tag; 
			this.iconRes = iconRes;
		}
	}

	public class MenuAdapter extends ArrayAdapter<MenuItem> {

		public MenuAdapter(Context context) {
			super(context, 0);
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = LayoutInflater.from(getContext()).inflate(R.layout.menu_row, null);
			}
			ImageView icon = (ImageView) convertView.findViewById(R.id.row_icon);
			icon.setImageResource(getItem(position).iconRes);
			TextView title = (TextView) convertView.findViewById(R.id.row_title);
			title.setText(getItem(position).tag);

			return convertView;
		}
	}
	
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		Fragment newfragment = null;
		String strTag = "";
		
		MainActivity mainAct = (MainActivity)getActivity();

		Fragment currentfragment = mainAct.getSupportFragmentManager().findFragmentById(R.id.container);

		if(id == 0){
			Fragment myactfragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_MYGROUP);
			if(myactfragment == null){
				newfragment = new MyGroupFragment();
				strTag = MainActivity.TAG_FRAGMENT_MYGROUP;
			}
		}
		if(id == 1){
			Fragment pedofragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_PEDO);
			if(pedofragment == null){
				newfragment = new PedoFragment();
				strTag = MainActivity.TAG_FRAGMENT_PEDO;
			}
		}
		if(id == 2){
			Fragment mapfragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_MAP);
			if(mapfragment == null){
				newfragment = new MapFragment();
				strTag = MainActivity.TAG_FRAGMENT_MAP;
			}
		}
		if(id == 3){
			Fragment squarefragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_RECORD);
			if(squarefragment == null){
				newfragment = new RecordFragment();
				strTag = MainActivity.TAG_FRAGMENT_RECORD;
			}
		}
		if(id == 4){
			Fragment squarefragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_TRAINING);
			if(squarefragment == null){
				newfragment = new TrainingFragment();
				strTag = MainActivity.TAG_FRAGMENT_TRAINING;
			}
		}
		if(id == 5){
			mainAct.mFeedback.startFeedbackActivity();
		}
		

		
        if (newfragment != null) {
            //mainAct.PushCurrentFragment(currentfragment.getTag());
        	mainAct.ClearFragmentStack();
        	
        	FragmentTransaction t = getActivity().getSupportFragmentManager().beginTransaction(); 
            t.add(R.id.container, newfragment, strTag);
            t.remove(currentfragment);
            t.commit();
        } else {    
            // error in creating fragment    
            //Log.e("MenuListFragment", "Error in creating fragment");
        	System.out.println("id:"+id);
        }    

        mainAct.toggle();

		super.onListItemClick(l, v, position, id);
	}	
}
