package cn.candone.appstepfun;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.social.UMPlatformData;
import com.umeng.analytics.social.UMPlatformData.GENDER;
import com.umeng.analytics.social.UMPlatformData.UMedia;

import cn.candone.appstepfun.R;
import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;
import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.framework.utils.UIHandler;
import cn.sharesdk.sina.weibo.SinaWeibo;
import cn.sharesdk.tencent.qq.QQ;
import cn.sharesdk.wechat.friends.Wechat;

//import com.umeng.socialize.bean.SHARE_MEDIA;
//import com.umeng.socialize.controller.UMServiceFactory;
//import com.umeng.socialize.controller.UMSocialService;
//import com.umeng.socialize.controller.listener.SocializeListeners.UMAuthListener;
//import com.umeng.socialize.controller.listener.SocializeListeners.UMDataListener;
//import com.umeng.socialize.exception.SocializeException;
//import com.umeng.socialize.weixin.controller.UMWXHandler;

public class ThirdPartLoginActivity extends Activity implements Callback, 
OnClickListener, PlatformActionListener{
	private final  String mPageName = "ThirdPartLoginActivity";	
	//public static final UMSocialService mController = UMServiceFactory.getUMSocialService("com.umeng.login");

	private static final int MSG_USERID_FOUND = 1;
	private static final int MSG_LOGIN = 2;
	private static final int MSG_AUTH_CANCEL = 3;
	private static final int MSG_AUTH_ERROR= 4;
	private static final int MSG_AUTH_COMPLETE = 5;
	
	private static final int MSG_USERLOGIN = 6;
		
	private PreferencesData mPerfData;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		ShareSDK.initSDK(this);

		//UMWXHandler wxSsoHandler = new UMWXHandler(ThirdPartLoginActivity.this, "wx61ee68f854d77229",
        //      "fd99eeb2159dc1f8fc3a0b1248b67e77");
		//wxSsoHandler.addToSocialSDK();

		mPerfData  = (PreferencesData) getApplicationContext();

		setContentView(R.layout.thirdpartylogin_activity);

		findViewById(R.id.textviewWeibo).setOnClickListener(this);
		findViewById(R.id.textviewQq).setOnClickListener(this);
		findViewById(R.id.textviewWeichat).setOnClickListener(this);
	}
	
    @Override
    protected void onResume() {
        super.onResume();
		MobclickAgent.onPageStart( mPageName );
		MobclickAgent.onResume(this);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
		MobclickAgent.onPageEnd( mPageName );
		MobclickAgent.onPause(this);
	}

	@Override
	public void onDestroy() {
		ShareSDK.stopSDK(this);
		super.onDestroy();
	}

	public void onClick(View v) {
		if(v.getId() == R.id.textviewWeibo){
				// remove account info first.
				Platform sina = ShareSDK.getPlatform(this, SinaWeibo.NAME);
				if (sina.isValid ()) {
					sina.removeAccount();
				}
				authorize(new SinaWeibo(this));
			}else if(v.getId() == R.id.textviewQq) {
				// remove account info first.
				Platform qq = ShareSDK.getPlatform(this, QQ.NAME);
				if (qq.isValid ()) {
					qq.removeAccount();
				}
				authorize(new QQ(this));
			} else if(v.getId() == R.id.textviewWeichat){
				Platform wechat = ShareSDK.getPlatform(this, Wechat.NAME);
				if (wechat.isValid ()) {
					wechat.removeAccount();
				}
				authorize(new Wechat(this)); 
				/**
				mController.doOauthVerify(ThirdPartLoginActivity.this, SHARE_MEDIA.WEIXIN,new UMAuthListener() {
		            @Override
		            public void onError(SocializeException e, SHARE_MEDIA platform) {
		            	findViewById(R.id.login_progressBar).setVisibility(View.GONE);
		            	Toast.makeText(ThirdPartLoginActivity.this, R.string.auth_error,  Toast.LENGTH_SHORT).show();		            	
		            }
		            @Override
		            public void onComplete(Bundle value, SHARE_MEDIA platform) {
		                if (value != null && !TextUtils.isEmpty(value.getString("uid"))) {
		                    Toast.makeText(ThirdPartLoginActivity.this, R.string.auth_complete, Toast.LENGTH_SHORT).show();
		                    WeiXinGetUserInfo();
		                } else {
		                    Toast.makeText(ThirdPartLoginActivity.this, R.string.auth_error,  Toast.LENGTH_SHORT).show();
		                }
		            }
		            @Override
		            public void onCancel(SHARE_MEDIA platform) {
		            	findViewById(R.id.login_progressBar).setVisibility(View.GONE);
		            	Toast.makeText(ThirdPartLoginActivity.this, R.string.auth_cancel,  Toast.LENGTH_SHORT).show();
		            }
		            @Override
		            public void onStart(SHARE_MEDIA platform) {}
				});
				**/
			}
		
		findViewById(R.id.login_progressBar).setVisibility(View.VISIBLE);
	}

	private Handler loginHandler = new Handler() {
		@Override
		public void handleMessage(Message message) {
			switch (message.what) {
			case MSG_USERLOGIN: {
				ExecuteLogin((String)message.obj);
				break;
			}
			}
		}
	};	
	
	private void authorize(Platform plat) {
		if (plat == null) {
			return;
		}
		
		if(plat.isValid()) {
			String userId = plat.getDb().getUserId();
			if (!TextUtils.isEmpty(userId)) {
				UIHandler.sendEmptyMessage(MSG_USERID_FOUND, this);
				login(plat.getName(), userId, null);
				return;
			}
		}
		plat.setPlatformActionListener(this);
		plat.SSOSetting(false);
		plat.showUser(null);
	}

	public void onComplete(Platform platform, int action,
			HashMap<String, Object> res) {
		
		if (action == Platform.ACTION_USER_INFOR) {

			UMedia media = null;
			
			UIHandler.sendEmptyMessage(MSG_AUTH_COMPLETE, this);
			login(platform.getName(), platform.getDb().getUserId(), res);
			
			mPerfData.setThirdPartID(platform.getDb().getUserId());  // open id from qq/weixin/sina
			mPerfData.setUserName(platform.getDb().getUserName());
			mPerfData.setUserIconUrl(platform.getDb().getUserIcon());
			
			if(platform.getId() == 1){          // SINA
				mPerfData.setLoginMode(PreferencesData.LOGIN_SINA);
				media = UMedia.SINA_WEIBO;
			}else if(platform.getId() == 4){    // WeChat
				mPerfData.setLoginMode(PreferencesData.LOGIN_WEIXIN);
				if(res.containsKey("openid")){
					mPerfData.setThirdPartID(res.get("openid").toString());
				}
				media = UMedia.WEIXIN_CIRCLE;
			}else if(platform.getId() == 7){	// QQ
				mPerfData.setLoginMode(PreferencesData.LOGIN_QQ);
				media = UMedia.TENCENT_QQ;
			}else{
			}
			
			if(media != null){
				UMPlatformData umplatform = new UMPlatformData(media, mPerfData.getThirdPartID());
				umplatform.setName(mPerfData.getUserName());
				MobclickAgent.onSocialEvent(this, umplatform);
			}
			
			mPerfData.SaveUserLoginInfo();

            String postStr = PrepareThridPartLoginString(mPerfData.getLoginMode(), 
            		mPerfData.getThirdPartID(),
            		mPerfData.getUserName(),
            		mPerfData.getUserIconUrl());

            //Send message to mainThread to do ExecuteLogin() ;
            Message msg = new Message();
            msg.what = MSG_USERLOGIN;
            msg.obj = postStr;
            loginHandler.sendMessage(msg);
		}
	}
	
	public void onError(Platform platform, int action, Throwable t) {
		if (action == Platform.ACTION_USER_INFOR) {
			UIHandler.sendEmptyMessage(MSG_AUTH_ERROR, this);
		}
		t.printStackTrace();
	}
	
	public void onCancel(Platform platform, int action) {
		if (action == Platform.ACTION_USER_INFOR) {
			UIHandler.sendEmptyMessage(MSG_AUTH_CANCEL, this);
		}
	}
	
	private void login(String plat, String userId, HashMap<String, Object> userInfo) {
		Message msg = new Message();
		msg.what = MSG_LOGIN;
		msg.obj = plat;
		UIHandler.sendMessage(msg, this);
	}
	
	public boolean handleMessage(Message msg) {
		switch(msg.what) {
			case MSG_USERID_FOUND: {
				Toast.makeText(this, R.string.userid_found, Toast.LENGTH_SHORT).show();
			}
			break;
			case MSG_LOGIN: {
				
				String text = getString(R.string.logining, msg.obj);
				Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
				
//				Builder builder = new Builder(this);
//				builder.setTitle(R.string.if_register_needed);
//				builder.setMessage(R.string.after_auth);
//				builder.setPositiveButton(R.string.ok, null);
//				builder.create().show();
			}
			break;
			case MSG_AUTH_CANCEL: {
				Toast.makeText(this, R.string.auth_cancel, Toast.LENGTH_SHORT).show();
				findViewById(R.id.login_progressBar).setVisibility(View.GONE);
			}
			break;
			case MSG_AUTH_ERROR: {
				Toast.makeText(this, R.string.auth_error, Toast.LENGTH_SHORT).show();
				findViewById(R.id.login_progressBar).setVisibility(View.GONE);
			}
			break;
			case MSG_AUTH_COMPLETE: {
				Toast.makeText(this, R.string.auth_complete, Toast.LENGTH_SHORT).show();
			}
			break;
		}
		return false;
	}
	
	/**
	private void WeiXinGetUserInfo(){
		mController.getPlatformInfo(ThirdPartLoginActivity.this, SHARE_MEDIA.WEIXIN, new UMDataListener() {
		    @Override
		    public void onStart() {
		        Toast.makeText(ThirdPartLoginActivity.this, "��ȡƽ̨���ݿ�ʼ...", Toast.LENGTH_SHORT).show();
		    }                                             
		    @Override
	        public void onComplete(int status, Map<String, Object> info) {
	            if(status == 200 && info != null){
	                StringBuilder sb = new StringBuilder();
	                Set<String> keys = info.keySet();
	                for(String key : keys){
	                   sb.append(key+"="+info.get(key).toString()+"\r\n");
	                }
	                System.out.println(sb.toString());

	                mPerfData.setThirdPartID(info.get("openid").toString());
	                mPerfData.setUserName(info.get("nickname").toString());
	                mPerfData.setUserIconUrl(info.get("headimgurl").toString());

	                mPerfData.setLoginMode(PreferencesData.LOGIN_WEIXIN);
	                mPerfData.SaveUserLoginInfo();
                    
                    String postStr = PrepareThridPartLoginString(mPerfData.getLoginMode(),
                    		mPerfData.getThirdPartID(), 
                    		mPerfData.getUserName(),
                    		mPerfData.getUserIconUrl());
                    
                    //Send message to mainThread to do ExecuteLogin() ;
                    Message msg = new Message();
                    msg.what = MSG_USERLOGIN;
                    msg.obj = postStr;
                    loginHandler.sendMessage(msg);
               }else{
	            	System.out.println("WeChat auth failed with status: "+status);
	           }
	        }
		});
	}
	**/
	private void TransToMainActivity(){
		
        Intent mainIntent = new Intent();
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        mainIntent.setClass(this, MainActivity.class);
        
        startActivity(mainIntent);  
        finish();
	}

	private CallbackListener callbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(ThirdPartLoginActivity.this, "������粻����", Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success","userId":"53a008fb9f68f41988fb4897",
				 *  "userName":"RobinNewName2"}
				 *  
				 *  {"result":"failed","reason":"user Not exist!"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						mPerfData.setUserID(obj.getString("userId"));
						mPerfData.UpdateUserID();
						
						Toast.makeText(ThirdPartLoginActivity.this, "ע������ɹ�", Toast.LENGTH_SHORT).show();
						System.out.println("appstepfun login successfully!");
						
						TransToMainActivity();

					}else{
						Toast.makeText(ThirdPartLoginActivity.this, "ע������ʧ��", Toast.LENGTH_SHORT).show();
						String reason = obj.getString("reason");
						System.out.println("appstepfun login failed: " + reason);
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			findViewById(R.id.login_progressBar).setVisibility(View.GONE);
		}
	};
	
    private void ExecuteLogin(String postStr) {
    	HttpConnection conn = new HttpConnection();
    	conn.post("/register/userlogin", postStr, callbackListener);
    }      	

	public static String PrepareThridPartLoginString(int loginMode, String uuId,
			String userName, String userHeadImageUrl){

	    if(loginMode < PreferencesData.LOGIN_WEIXIN || loginMode > PreferencesData.LOGIN_SINA ){
	    	return null;
	    }
        /**
         * httpPost JSON format: json={"source":"QQ","info":{"UUID":"Robin","userName":"RobinNewName2",
         *  "photoUrl":"http://yds.com.cn"}} 
         */
        JSONObject infoObj = new JSONObject();  
        JSONObject loginObj = new JSONObject();  
		
        try {
        	infoObj.put("UUID", uuId);
        	infoObj.put("userName", userName);
        	infoObj.put("photoUrl", userHeadImageUrl);
        	
			if(loginMode == PreferencesData.LOGIN_WEIXIN){
				loginObj.put("source", "weChat");
			}else if(loginMode == PreferencesData.LOGIN_QQ){
				loginObj.put("source", "QQZone");
			}else if(loginMode == PreferencesData.LOGIN_SINA){
				loginObj.put("source", "Sina");
			}
			
			loginObj.put("info", infoObj);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

       String retStr = "json=" + loginObj.toString();
       System.out.println(retStr);
 
       return retStr;
	}
}
