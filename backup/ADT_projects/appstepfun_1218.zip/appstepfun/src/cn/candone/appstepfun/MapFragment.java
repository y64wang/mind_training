package cn.candone.appstepfun;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.MapsInitializer;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.amap.api.maps.offlinemap.OfflineMapCity;
import com.amap.api.maps.offlinemap.OfflineMapManager;
import com.amap.api.maps.offlinemap.OfflineMapManager.OfflineMapDownloadListener;
import com.amap.api.maps.offlinemap.OfflineMapStatus;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MapFragment extends Fragment implements OfflineMapDownloadListener{
	private final String mPageName = "MapFragment";
	
	public AMap aMap = null;
	public MapView mapView = null;

	public Marker marker;
	
	private boolean mIsNetworkOn = false;
	private boolean mIsGPSOn = false;
	
	private OfflineMapManager mAmapManager = null;
	private List<OfflineMapCity> mCityArray = new ArrayList<OfflineMapCity>();
	
	private ProgressDialog mProgressDialog = null;

	private TextView  mWalkingButton = null;
	public TextView mWalkingTV = null;
	
	public TextView mWalkingDurationTV = null;
	public TextView mWalkingDistanceTV = null;
	public TextView mWalkingUnitTV = null;
	public TextView mWalkingCaloriesTV = null;
	public TextView mWalkingDateTV = null;
	public TextView mWalkingTimeTV = null;
	public TextView mWalkingSpeedTV = null;
	
	public MapFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.main_map_fragment, container, false);

    	MainActivity mainAct = (MainActivity)getActivity();
    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
		if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_MAP);
		}
		

		mapView = (MapView) rootView.findViewById(R.id.map_view);
		mapView.onCreate(savedInstanceState);// �˷���������д
		
		//System.out.println("CameraPos: " + mapView.getMap().getCameraPosition().toString());

        mAmapManager = new OfflineMapManager(getActivity(), this);
		mCityArray =  mAmapManager.getDownloadOfflineMapCityList();
		
		mIsGPSOn = isGpsEnable();
		if(! mIsGPSOn){
			Toast.makeText(getActivity(), "�������GPS", Toast.LENGTH_SHORT).show();
		}
		
		mIsNetworkOn = isNetworkConnected();
		if(!mIsNetworkOn){
			Toast.makeText(getActivity(), "�������粻����", Toast.LENGTH_SHORT).show();
		}
		
		//init walking status
    	mainAct.mMaxSpeed = 0;
    	mainAct.mTotalDistance = 0;
    	mainAct.mMapTracking = false;
		
		mWalkingTV = (TextView) rootView.findViewById(R.id.walkingTV);
		mWalkingTV.setText("��ʼ");
		mWalkingTV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);	
		
		mWalkingDurationTV = (TextView) rootView.findViewById(R.id.walking_durationTV);

		mWalkingUnitTV = (TextView) rootView.findViewById(R.id.walking_unitTV);
		
		mWalkingDistanceTV = (TextView) rootView.findViewById(R.id.walking_distanceTV);
		
		mWalkingCaloriesTV = (TextView) rootView.findViewById(R.id.walking_caloriesTV);
		
		mWalkingDateTV = (TextView) rootView.findViewById(R.id.walking_dateTV);
		
		mWalkingTimeTV = (TextView) rootView.findViewById(R.id.walking_timeTV);
		
		mWalkingSpeedTV = (TextView) rootView.findViewById(R.id.walking_speedTV);
		
		mWalkingButton = (TextView) rootView.findViewById(R.id.walkingButton);
		mWalkingButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				MainActivity mainAct = (MainActivity)getActivity();
				if(mainAct.mMapTracking){

		            AlertDialog isQuit = new AlertDialog.Builder(getActivity()).create();  
		            isQuit.setTitle("��������");  
		            isQuit.setMessage("�����˶���");  
		            isQuit.setButton("�����˶�", quitWakingListener);  
		            isQuit.setButton2("�����˳���", quitWakingListener);  
		            isQuit.show();
					
				}else{
					
					if(mWalkingTV.getText().equals("��ʼ")){
						mIsGPSOn = isGpsEnable();
						if(! mIsGPSOn){
							Toast.makeText(getActivity(), "����GPSû�п���, �޷���¼�����˶��켣, ��ȷ�ϴ�����GPS!", Toast.LENGTH_SHORT).show();
						}else{
							StartWalking();
						}
					}else{
			            AlertDialog isRestart = new AlertDialog.Builder(getActivity()).create();  
			            isRestart.setTitle("��������");  
			            isRestart.setMessage("���¿�ʼ��һ��?");  
			            isRestart.setButton("�õ�", restartWakingListener);  
			            isRestart.setButton2("�����ٿ���", restartWakingListener);  
			            isRestart.show();
					}
				}
				
			}
			
		});

		initMap();
		return rootView;
	}
	
	private void StartWalking(){
		

		MainActivity mainAct = (MainActivity)getActivity();

		ResetWalkingData();
		
		Calendar cd = Calendar.getInstance();
		mainAct.mStartTiming = cd.getTimeInMillis();
		
		aMap.setMyLocationType(AMap.LOCATION_TYPE_MAP_ROTATE);
		
		mWalkingTV.setText("��������");
		mWalkingTV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);

		mainAct.mMapTracking = true;
		mainAct.acquireWakeLock();
		
		mainAct.sendSwitchGPSCmd(true);
		
		walkingTimerHandler.postDelayed(walkingTimerRunnable, 1000);
	}

	private void StopWalking(){
    	MainActivity mainAct = (MainActivity)getActivity();
    	
		walkingTimerHandler.removeCallbacks(walkingTimerRunnable);
		
		mainAct.mMapTracking = false;
		mainAct.releaseWakeLock();

    	mainAct.sendSwitchGPSCmd(false);

    	Calendar cd = Calendar.getInstance();
    	long stopTime = cd.getTimeInMillis();
    	
    	long duration = stopTime - mainAct.mStartTiming;
    	mainAct.mAvgSpeed = (mainAct.mTotalDistance * 3600) / duration;
    	
    	DecimalFormat dcmFmt2 = new DecimalFormat("0.00");
    	mWalkingSpeedTV.setText(dcmFmt2.format(mainAct.mAvgSpeed));
    	
    	if(mWalkingTV.getText().equals("��������")){
    		mWalkingTV.setText("0��");
    	}
    	
    	mainAct.AddWalkingRecList(mWalkingDateTV.getText() + " " + mWalkingTimeTV.getText(),
    			duration, 
    			mainAct.mTotalDistance, 
    			mainAct.mCalories, 
    			mainAct.mAvgSpeed);
    	
    	aMap.setMyLocationType(AMap.LOCATION_TYPE_LOCATE);
    	
    	addEndMarker();
    	aMap.setMyLocationStyle(null);
	}
	
	private void ResetWalkingData(){
    	MainActivity mainAct = (MainActivity)getActivity();
    	mainAct.mTotalDistance = 0;
    	mainAct.mFirstGPSLocated = false;
    	
		Calendar cd = Calendar.getInstance();
		Date date = cd.getTime();
    	
		SimpleDateFormat formatterDate = new SimpleDateFormat("yyyy-MM-dd", getResources().getConfiguration().locale);       
       	String dateStr = formatterDate.format(date);

       	SimpleDateFormat formatterTime = new SimpleDateFormat("HH:mm:ss", getResources().getConfiguration().locale);       
       	String timeStr = formatterTime.format(date);
       	
		mWalkingDistanceTV.setText("0.0");
		mWalkingUnitTV.setText("��");
		mWalkingDurationTV.setText("00:00:00");
		mWalkingCaloriesTV.setText("0.0");
		mWalkingDateTV.setText(dateStr);
		mWalkingTimeTV.setText(timeStr);
		mWalkingSpeedTV.setText("0.0");

    	aMap.clear();
    	setUpMap();
	}
	
	public void addStartMarker(LatLng curLatLng){
		MainActivity mainAct = (MainActivity)getActivity();
		aMap.addMarker(new MarkerOptions().position(curLatLng).draggable(false)
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.walking_start)));
	}

	public void addEndMarker(){
		MainActivity mainAct = (MainActivity)getActivity();
		LatLng curLatLng = new LatLng(mainAct.mLatitude, mainAct.mLongitude);
		aMap.addMarker(new MarkerOptions().position(curLatLng).draggable(false)
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.walking_end)));
	}
	
    DialogInterface.OnClickListener restartWakingListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
				if(! mIsGPSOn){
					Toast.makeText(getActivity(), "����GPSû�п���, �޷���¼�����˶��켣, ��ȷ�ϴ�����GPS!", Toast.LENGTH_SHORT).show();
				}else{
	            	StartWalking();
				}
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  

				break;  
            default:  
                break;  
            }  
        }  
    }; 
    
    DialogInterface.OnClickListener quitWakingListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
            	StopWalking();
				break;  
            default:  
                break;  
            }  
        }  
    }; 
    
	private void initMap() {
		if (aMap == null) {
			aMap = mapView.getMap();
			ResetWalkingData();
		}
	}

	private void setUpMap() {
		
		MainActivity mainAct = (MainActivity)getActivity();
		LatLng curLatLng = new LatLng(mainAct.mLatitude, mainAct.mLongitude);
		
		ArrayList<BitmapDescriptor> giflist = new ArrayList<BitmapDescriptor>();
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point1));
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point2));
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point3));
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point4));
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point5));
		giflist.add(BitmapDescriptorFactory.fromResource(R.drawable.point6));
		marker = aMap.addMarker(new MarkerOptions().anchor(0.5f, 0.5f)
				.icons(giflist).period(50).setFlat(true).perspective(true));
		// �Զ���ϵͳ��λС����
		MyLocationStyle myLocationStyle = new MyLocationStyle();
		myLocationStyle.myLocationIcon(BitmapDescriptorFactory.fromResource(R.drawable.location_marker));// ����С�����ͼ��
		myLocationStyle.strokeColor(MainActivity.COLOR_SKYBLUE);// ����Բ�εı߿���ɫ
		myLocationStyle.radiusFillColor(Color.TRANSPARENT);// ����Բ�ε������ɫ
		// myLocationStyle.anchor(int,int)//����С�����ê��
		myLocationStyle.strokeWidth(0.1f);// ����Բ�εı߿��ϸ
		aMap.setMyLocationStyle(myLocationStyle);
		aMap.setMyLocationRotateAngle(180);
		aMap.setLocationSource(mainAct.mService);// ���ö�λ����
		aMap.getUiSettings().setMyLocationButtonEnabled(true);// ����Ĭ�϶�λ��ť�Ƿ���ʾ
		aMap.setMyLocationEnabled(true);// ����Ϊtrue��ʾ��ʾ��λ�㲢�ɴ�����λ��false��ʾ���ض�λ�㲢���ɴ�����λ��Ĭ����false
		//���ö�λ������Ϊ��λģʽ �������ɶ�λ��������ͼ������������ת���� 
		aMap.setMyLocationType(AMap.LOCATION_TYPE_LOCATE);
		//aMap.setMapTextZIndex(2);
		aMap.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.builder()
				.target(curLatLng)
				.zoom(18)
				.tilt(45)
				.build()));
	}

	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
		mapView.onResume();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd(mPageName);
		mapView.onPause();
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		mapView.onSaveInstanceState(outState);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		
		MainActivity mainAct = (MainActivity) getActivity();
		SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);

		if(mainAct.mMapTracking){
			StopWalking();
		}
		mapView.onDestroy();
	}


	public void IsOfflineMapDownloaded(){

		MainActivity mainAct = (MainActivity)getActivity();
		
		int cityCount = mCityArray.size();
		boolean cityFound = false;
		for(int i=0; i<cityCount; i++){
			OfflineMapCity city = mCityArray.get(i);
			System.out.println(city.getCity() + " found");
			if(city.getCode().equals(mainAct.mLocalCityCode)){
				cityFound = true;
				break;
			}
		}
		
		if(!cityFound){
            AlertDialog isDownload = new AlertDialog.Builder(getActivity()).create();
            isDownload.setTitle("������ʾ");  
            isDownload.setMessage("����û��"+mainAct.mLocalCity+"�����ߵ�ͼ,�Ƿ�����? ���ߵ�ͼ���Խ�ʡ90%����������Ŷ, ������WIFI����������!");  
            isDownload.setButton("ȷ��", downloadListener);
            isDownload.setButton2("ȡ��", downloadListener);
            isDownload.show();
		}		
	}
	
    DialogInterface.OnClickListener downloadListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳�����
            	MainActivity mainAct = (MainActivity)getActivity();
			    boolean start = false;
			    try {
			        start = mAmapManager.downloadByCityCode(mainAct.mLocalCityCode);
			        if (!start) {
			        	Toast.makeText(getActivity(), "����" + mainAct.mLocalCity + "�����ߵ�ͼʧ��" , Toast.LENGTH_SHORT).show();
			        } else {
			        	//Toast.makeText(getActivity(), "��ʼ����" + mCurrentCity + "�����ߵ�ͼ" , Toast.LENGTH_SHORT).show();
			        	mProgressDialog = new ProgressDialog(getActivity());
			        	mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			        	mProgressDialog.setCancelable(false);
			        	mProgressDialog.setIcon(R.drawable.app_icon);
			        	mProgressDialog.setTitle("������ʾ");
			        	mProgressDialog.setMessage("��������"+ mainAct.mLocalCity +"���ߵ�ͼ��...");
			        	mProgressDialog.setProgress(0);
			        	mProgressDialog.setMax(100);
			        	mProgressDialog.show();
			        	
			        	// 20s download exception timer.
			        	downloadExceptionTimerHandler.postDelayed(downloadExceptionTimerRunnable, 20000);
			        }
			    } catch (Exception e) {
			        System.out.println("Download offline Map error: " + e.toString());
			        Toast.makeText(getActivity(), "�������粻����" , Toast.LENGTH_SHORT).show();
			    }
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
                break; 
            }  
        }  
    };    

	@Override
	public void onDownload(int status, int completeCode, String downName) {
		switch (status) {
		case OfflineMapStatus.SUCCESS:
			//changeOfflineMapTitle(OfflineMapStatus.SUCCESS);
			MainActivity mainAct = (MainActivity)getActivity();
			if(mProgressDialog!= null){
				mProgressDialog.setProgress(100);
				mProgressDialog.setMessage(mainAct.mLocalCity + "�����ߵ�ͼ���سɹ�!");
				completeTimerHandler.postDelayed(completeTimerRunnable,2000);
			}
			//Toast.makeText(getActivity(), mCurrentCity + "�����ߵ�ͼ���سɹ���" , Toast.LENGTH_SHORT).show();
			break;
		case OfflineMapStatus.LOADING:
			if(mProgressDialog != null){
				mProgressDialog.setProgress(completeCode);
				downloadExceptionTimerHandler.removeCallbacks(downloadExceptionTimerRunnable);
			}
			break;
		case OfflineMapStatus.UNZIP:
			//OfflineMapActivity.this.completeCode = completeCode;
			//changeOfflineMapTitle(OfflineMapStatus.UNZIP);
			if( mProgressDialog !=null){
				mProgressDialog.setMessage("���ڽ�ѹ���ߵ�ͼ��...");
				mProgressDialog.setProgress(completeCode);
			}
			break;
		case OfflineMapStatus.WAITING:
			break;
		case OfflineMapStatus.PAUSE:
			break;
		case OfflineMapStatus.STOP:
			if(mProgressDialog!= null){
				mProgressDialog.dismiss();
				
				downloadExceptionTimerHandler.removeCallbacks(downloadExceptionTimerRunnable);
			}
			break;
		case OfflineMapStatus.ERROR:
			if(mProgressDialog!= null){
				mProgressDialog.dismiss();
				
				downloadExceptionTimerHandler.removeCallbacks(downloadExceptionTimerRunnable);
			}
			break;
		default:
			break;
		}	
	}

    private Handler completeTimerHandler = new Handler( );

    private Runnable completeTimerRunnable = new Runnable( ){
	    public void run ( ) {
			if(mProgressDialog!= null){
				mProgressDialog.dismiss();
			}
	    }
    };
    
    private Handler downloadExceptionTimerHandler = new Handler( );

    private Runnable downloadExceptionTimerRunnable = new Runnable( ){
	    public void run ( ) {
			if(mProgressDialog!= null){
				mProgressDialog.dismiss();
				
				Toast.makeText(getActivity(), "���ߵ�ͼ����ʧ��" , Toast.LENGTH_SHORT).show();
			}
	    }
    };
    
    private Handler walkingTimerHandler = new Handler( );

    private Runnable walkingTimerRunnable = new Runnable( ){
	    public void run ( ) {
    		MainActivity mainAct = (MainActivity)getActivity();
    		
	    	if(mWalkingDurationTV != null && mainAct.mMapTracking){
	    		Calendar cd = Calendar.getInstance();
	    		long elapsedTimeMillis = cd.getTimeInMillis() - mainAct.mStartTiming;
	    		
	    		long elapsedTimeSeconds = elapsedTimeMillis / 1000; 
	    		mWalkingDurationTV.setText(String.format("%02d:%02d:%02d", elapsedTimeSeconds / 3600, 
	    				(elapsedTimeSeconds % 3600) / 60, 
	    				(elapsedTimeSeconds % 60))); 
	    		
	    		walkingTimerHandler.postDelayed(this, 1000);
	    	}
	    }
    };

    private boolean isNetworkConnected() {  
        ConnectivityManager cm =   
                (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);  
        NetworkInfo network = cm.getActiveNetworkInfo();  
        if (network != null) {  
            return network.isAvailable();  
        }  
        return false;  
    } 
    
    private boolean isGpsEnable() {  
        LocationManager locationManager =   
                ((LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE));  
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);  
    }  
}
