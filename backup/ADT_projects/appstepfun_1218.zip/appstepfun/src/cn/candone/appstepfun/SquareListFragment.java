package cn.candone.appstepfun;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class SquareListFragment extends ListFragment {

	private DisplayImageOptions mImageLoaderOptions;
	private JSONArray mUnJoinedGroupArray = new JSONArray();
	private FamousGroupItem mSelectedItem;
	
	public SquareListFragment(){
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.list, null);

		mImageLoaderOptions = new DisplayImageOptions.Builder()  
        .showImageOnLoading(R.drawable.app_default)
        .showImageForEmptyUri(R.drawable.app_default)  
        .showImageOnFail(R.drawable.app_default)
        .cacheInMemory(true)  
        .cacheOnDisk(true)  
        .considerExifParams(true)
        //.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
        .bitmapConfig(Bitmap.Config.RGB_565)
        //.decodingOptions(android.graphics.BitmapFactory.Options decodingOptions)//����ͼƬ�Ľ�������  
        //.delayBeforeLoading(1000)   //int delayInMillisΪ�����õ�����ǰ���ӳ�ʱ��
        //����ͼƬ���뻺��ǰ����bitmap��������  
        //.preProcessor(BitmapProcessor preProcessor)  
        //.resetViewBeforeLoading(true)//����ͼƬ������ǰ�Ƿ����ã���λ  
        .displayer(new RoundedBitmapDisplayer(180)) // round conner
        .handler(new Handler())
        .build();
		return rootView;
	}

	@Override
	public void onDestroy(){
    	ImageLoader.getInstance().stop();
    	super.onDestroy();
	}
	
	private class FamousGroupItem {
		public String groupName;
		public String ownerIconUrl;
		public String userIconUrl[];
		public int  userNumber;
		
		public String target;
		
		public FamousGroupItem(String groupName, String ownerIconUrl,
				       String userIconUrl[], int number, String target) {
			this.groupName = groupName;
			this.ownerIconUrl = ownerIconUrl;
			this.userIconUrl = userIconUrl;
			this.userNumber = number;
			this.target = target;
		}
	}

	public class FamousGroupAdapter extends ArrayAdapter<FamousGroupItem> {

		public FamousGroupAdapter(Context context) {
			super(context, 0);
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = LayoutInflater.from(getContext()).inflate(R.layout.square_group_row, null);
			}
			ImageView ownerIconIV = (ImageView) convertView.findViewById(R.id.public_row_icon1);
			displayHeadImage(getItem(position).ownerIconUrl, ownerIconIV);
			
			ImageView userIconIV1 = (ImageView) convertView.findViewById(R.id.public_row_icon2);
			if(getItem(position).userIconUrl[0].equals("")){
				userIconIV1.setVisibility(View.GONE);
			}else{
				displayHeadImage(getItem(position).userIconUrl[0], userIconIV1);
				userIconIV1.setVisibility(View.VISIBLE);
			}

			ImageView userIconIV2 = (ImageView) convertView.findViewById(R.id.public_row_icon3);
			if(getItem(position).userIconUrl[1].equals("")){
				userIconIV2.setVisibility(View.GONE);
			}else{
				displayHeadImage(getItem(position).userIconUrl[1], userIconIV2);
				userIconIV2.setVisibility(View.VISIBLE);
			}
			
			ImageView userIconIV3 = (ImageView) convertView.findViewById(R.id.public_row_icon4);
			if(getItem(position).userIconUrl[2].equals("")){
				userIconIV3.setVisibility(View.GONE);
			}else{
				displayHeadImage(getItem(position).userIconUrl[2], userIconIV3);
				userIconIV3.setVisibility(View.VISIBLE);
			}
			
			TextView groupNameTV = (TextView) convertView.findViewById(R.id.public_row_groupName);
			groupNameTV.setText(MainActivity.GetRealGroupName(getItem(position).groupName));
			
			TextView numberTV = (TextView) convertView.findViewById(R.id.public_row_number);
			numberTV.setText("�ܹ�" + getItem(position).userNumber+"λ��������������");

			return convertView;
		}
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		FamousGroupAdapter adapter =  (FamousGroupAdapter) getListAdapter();
		
		mSelectedItem = adapter.getItem(position);

        AlertDialog isQuit = new AlertDialog.Builder(getActivity()).create();  
        isQuit.setTitle("����");  
        isQuit.setMessage("�������ѣ�����");  
        isQuit.setButton("���뿴��", joinGroupListener);  
        isQuit.setButton2("���ˣ�û��Ȥ", joinGroupListener);  
        isQuit.show();

		super.onListItemClick(l, v, position, id);
	}			

    DialogInterface.OnClickListener joinGroupListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳�����
            	if(mSelectedItem != null){
            		ExecuteJoinFamousGroup(mSelectedItem.groupName);
            	}
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
                break;  
            default:  
                break;  
            }  
        }  
    }; 	
	
	private CallbackListener joinFamousGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(getActivity(), HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						Toast.makeText(getActivity(), "�����ɹ�", Toast.LENGTH_SHORT).show();
						
						String groupName = obj.getString("groupName");
						JSONObject selectedGroupEntry = RemoveSelectedFamousGroup(groupName);
						AddSelectedFamousGroup(selectedGroupEntry);
						
						MainActivity mainAct = (MainActivity) getActivity();
						mainAct.mNeedUpdateGroupInfo = true;
						mainAct.sendUpdateReportJSONCmd();
						
						System.out.println("join famous group success");
					}else{
						Toast.makeText(getActivity(), "����ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("join famous group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("SquareListFragment: " + e.toString());
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteJoinFamousGroup(String groupName) {

    	MainActivity mainAct = (MainActivity) getActivity();
        JSONObject joinGroupObj = new JSONObject();  

        if(! groupName.equals("")){
	        /**
	         * json={"userId":"539322f172d6355d63ab4f3d","groupName":"������","password":"123"}
	         */
	        try {
	        	joinGroupObj.put("userId", mainAct.mPerfData.getUserID());
	        	joinGroupObj.put("groupName", groupName);
	        	joinGroupObj.put("password", "123");
			} catch (JSONException e) {
				System.out.println("SquareListFragment: " + e.toString());
			}
	        String joinGroupStr = "json=" + joinGroupObj.toString();
	        
	        System.out.println(joinGroupStr);
	        
	    	HttpConnection conn = new HttpConnection();
	    	conn.post("/group/joingroup", joinGroupStr, joinFamousGroupCallbackListener);
        }
    }	
	
    public void SetFamousGroupListView(JSONArray groupArray){

		FamousGroupAdapter adapter = new FamousGroupAdapter(getActivity());
		mUnJoinedGroupArray = groupArray;

		int groupCount = groupArray.length();
		if(groupCount > 0){
			try{
				
				for(int i=0; i<groupCount; i++){
					JSONObject groupEntry = groupArray.getJSONObject(i);
					String groupName = groupEntry.getString("groupName");
					String target = groupEntry.getString("dailyTarget");
					String ownerIconUrl = groupEntry.getString("ownerPhotoUrl");
					String userIconUrl[] = new String[3];
					userIconUrl[0] = groupEntry.getString("userPhotoUrl1");
					userIconUrl[1] = groupEntry.getString("userPhotoUrl2");
					userIconUrl[2] = groupEntry.getString("userPhotoUrl3");
					
					int userNumber = groupEntry.getInt("userNumber");
					
					adapter.add(new FamousGroupItem(groupName, ownerIconUrl, userIconUrl, 
							userNumber, target));
				}
				
			}catch(JSONException e){
				System.out.println("SetFamousGroupListView: " + e.toString());
			};
		}
		
		setListAdapter(adapter);
	}

    private JSONObject RemoveSelectedFamousGroup(String selectedGroupName){
    
    	JSONObject returnObj = null;
    	
    	int groupCount = mUnJoinedGroupArray.length();
    	try{
	    	JSONArray newUnJoinedGroupArray = new JSONArray();
	    	for(int i=0; i<groupCount; i++){
	    		JSONObject groupEntry = mUnJoinedGroupArray.getJSONObject(i);
	    		String groupName  = groupEntry.getString("groupName");
	    		if(groupName.equals(selectedGroupName)){
	    			returnObj = groupEntry;
	    		}else{
	    			newUnJoinedGroupArray.put(groupEntry);
	    		}
	    	}
	    	
	    	SetFamousGroupListView(newUnJoinedGroupArray);
	    	if(newUnJoinedGroupArray.length() == 0){
	    		Toast.makeText(getActivity(), "���޹㳡��ɼ���...", Toast.LENGTH_SHORT).show();
	    	}
	    	
    	}catch(JSONException e){
    		System.out.println("RemoveSelectedFamousGroup: " + e.toString());
    	}
    	
    	return returnObj;
    }
    
    private void AddSelectedFamousGroup(JSONObject selectedObj){
		if(selectedObj != null){
			MainActivity mainAct = (MainActivity) getActivity();
			if(mainAct.mFamousGroupArray != null){
		    	try{
		    		String groupName = selectedObj.getString("groupName");
		    		String ownIconUrl = selectedObj.getString("ownerPhotoUrl");
		    		String target = selectedObj.getString("dailyTarget");
		    		
					JSONObject newGroupEntry = new JSONObject();
					newGroupEntry.put("groupName", groupName);
					newGroupEntry.put("ownerPhotoUrl", ownIconUrl);
					newGroupEntry.put("dailyTarget", target);

					newGroupEntry.put("mySequence", "���޳ɼ�");
					newGroupEntry.put("champion", "���޳ɼ�");
					
					JSONArray userArray = selectedObj.getJSONArray("users");
					int userCount = userArray.length();
					for(int i=0; i<userCount; i++){
						JSONObject userEntry = userArray.getJSONObject(i);
						userEntry.put("steps", "0");
					}

					JSONObject myEntry = new JSONObject();
					myEntry.put("userName", mainAct.mPerfData.getUserName());
					myEntry.put("userId", mainAct.mPerfData.getUserID());
					myEntry.put("photoUrl", mainAct.mPerfData.getUserIconUrl());
					myEntry.put("steps", "" + mainAct.mSteps);
					userArray.put(myEntry);
					
					newGroupEntry.put("userNumber", userCount + 1);
					
					mainAct.mFamousGroupArray.put(newGroupEntry);
					mainAct.mPerfData.setFamousGroupArray(mainAct.mFamousGroupArray.toString());
					mainAct.mPerfData.SaveGroupUsersInfo(groupName, userArray.toString());
					
		    	}catch(JSONException e){
		    		System.out.println("AddSelectedFamousGroup: " + e.toString());
		    	}
			}
		}    	
    }
    
    private void displayHeadImage(String url, ImageView imgView){
    	ImageLoader.getInstance().displayImage(url, imgView, mImageLoaderOptions);
    }
}
