package cn.candone.appstepfun;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Stack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.PowerManager.WakeLock;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;
import cn.candone.appstepfun.helper.LogcatHelper;
import cn.candone.appstepfun.onekeyshare.OnekeyShare;
import cn.candone.appstepfun.pedo.PedoService;
import cn.candone.appstepfun.widget.RoundRndProgressBar;

import com.amap.api.maps.AMap.OnMapScreenShotListener;
import com.amap.api.maps.AMapUtils;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.MapsInitializer;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.api.services.core.LatLonPoint;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.FeedbackAgent;
import com.umeng.update.UmengUpdateAgent;


import cn.candone.appstepfun.R;
import cn.sharesdk.framework.ShareSDK;


public class MainActivity extends SlidingFragmentActivity implements GroupListFragment.OnGroupListFragmentCreatedListener, 
		UserListFragment.OnUserListFragmentCreatedListener, OnMapScreenShotListener{

	private boolean mQuitPedoService = false;
	
	//umeng analytics
	private Context mContext;
	private final  String mPageName = "MainActivity";	

	// color theme
	public static final int COLOR_SKYBLUE = Color.rgb(30, 144, 255);
	public static final int COLOR_BOTTOMBLUE = Color.rgb(114, 200, 200);
	public static final int COLOR_ORANGE = Color.rgb(255, 140, 0);
	
	// fragment tag definition
	public final static String TAG_FRAGMENT_LOGINVIEW="loginViewFragment";
	public final static String TAG_FRAGMENT_PEDO="pedoFragment";
	public final static String TAG_FRAGMENT_PEDOHISTORY="pedoHistoryFragment";
	public final static String TAG_FRAGMENT_MYGROUP="myActivityFragment";
	public final static String TAG_FRAGMENT_JOINGROUP="joinGroupFragment";
	public final static String TAG_FRAGMENT_GROUPDETAIL="groupDetailFragment";
	public final static String TAG_FRAGMENT_SQUARE="squareFragment";
	public final static String TAG_FRAGMENT_TRAINING="trainingFragment";
	public final static String TAG_FRAGMENT_TRAININGLIST="trainingListFragment";
	public final static String TAG_FRAGMENT_TRAININGDETAIL="trainingDetailFragment";
	public final static String TAG_FRAGMENT_MAP="mapFragment";
	public final static String TAG_FRAGMENT_RECORD="recordFragment";

	
	/* ----------------------Fragment stack --------------------------------*/
	public void ClearFragmentStack(){
		mFragmentStack.clear();
		

		mActionBarHomeIcon.setImageResource(R.drawable.icon_home);
		mActionBarHomeIcon.invalidate();
	}
	
    public void PushCurrentFragment(String fragmentTag){
    	mFragmentStack.removeElement(fragmentTag);
    	mFragmentStack.push(fragmentTag);

    	mActionBarHomeIcon.setImageResource(R.drawable.ic_back);
    	mActionBarHomeIcon.invalidate();
    	//System.out.println(mFragmentStack.toString());
    }

	public boolean ReturnToPrevFragment(){
		if(mFragmentStack.isEmpty()){
			return false;
		}

		String prevFragmentTag = mFragmentStack.pop();
    	if(mFragmentStack.isEmpty()){
    		mActionBarHomeIcon.setImageResource(R.drawable.icon_home);
    		mActionBarHomeIcon.invalidate();
    	}

    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(prevFragmentTag);
    	if(mainfragment == null){
        	Fragment currentfragment=getSupportFragmentManager().findFragmentById(R.id.container);
        	if(prevFragmentTag.equals(TAG_FRAGMENT_LOGINVIEW)){
            	mainfragment = new LoginViewFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_PEDO)){
        		mainfragment = new PedoFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_PEDOHISTORY)){
        		mainfragment = new PedoHistoryFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_MYGROUP)){
        		mainfragment = new MyGroupFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_JOINGROUP)){
        		mainfragment = new JoinGroupFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_GROUPDETAIL)){
        		mainfragment = new GroupDetailFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_SQUARE)){
        		mainfragment = new SquareFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_TRAINING)){
        		mainfragment = new TrainingFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_TRAININGLIST)){
        		mainfragment = new TrainingListsFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_TRAININGDETAIL)){
        		mainfragment = new TrainingDetailFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_MAP)){
        		mainfragment = new MapFragment();
        	}else if(prevFragmentTag.equals(TAG_FRAGMENT_RECORD)){
        		mainfragment = new RecordFragment();
        	}
        	
        	if(mainfragment != null){
	        	FragmentTransaction t = getSupportFragmentManager().beginTransaction();
	        	t.add(R.id.container, mainfragment, prevFragmentTag);
	            t.remove(currentfragment);
	            t.commit();

	            return true;
        	}
		}
		

    	
    	return false;
	}
	/* ----------------------Fragment stack --------------------------------*/
	
	// menuTitle definition\
	public final static String MENUTITLE_DISABLED="";
	public final static String MENUTITLE_LOGIN_LOGIN="ע��";
	public final static String MENUTITLE_LOGIN_LOGOUT="ע��";
	public final static String MENUTITLE_SHARE="����";
	public final static String MENUTITLE_GROUP_CREATE="����";
	public final static String MENUTITLE_GROUP_SWITCH="�л�";
	public final static String MENUTITLE_GROUP_QUIT="�˳��";
	public final static String MENUTITLE_MOREPLAN="����ƻ�";
	public final static String MENUTITLE_RESTARTPLAN="�˳�ѵ��";

	//actionbar title definition
	public final static String BARTITLE_LOGINVIEW = "";
	public final static String BARTITLE_JOINGROUP = "�μӻ";
	public final static String BARTITLE_CREATEGROUP = "�����";
	public final static String BARTITLE_PEDO = "�Ʋ���";
	public final static String BARTITLE_MYGROUP = "�ҵĻ";
	public final static String BARTITLE_SQUARE = "�㳡�";
	public final static String BARTITLE_PEDOHISTORY = "�ֶγɼ�";
	public final static String BARTITLE_TRAINING="ѵ���ƻ�";
	public final static String BARTITLE_MAP="�˶�";
	public final static String BARTITLE_RECORD="�ҵĳɼ�";
	
	public final static int REQUEST_JOINGROUPACTIVITY=1;
	public final static int REQUEST_QUITGROUPACTIVITY=2;

	public final static int RESULT_JOINGROUPACTIVITY=1;
	public final static int RESULT_QUITGROUPACTIVITY=2;

	public final static int ACTIONBAR_BOTTON_ID=1000;
	
	protected ListFragment mFrag;
	protected TextView mActionBarMenu;
	protected ImageView mActionBarHomeIcon;
	protected TextView mActionBarTitle;
	protected RelativeLayout mActionBarIconBG;
    //protected int mStepValue = 0;

	public Stack<String> mFragmentStack = new Stack<String>();
	
	private boolean mPedoServiceIsRunning = false;
    public PedoService mService;
	public PreferencesData mPerfData;

    public boolean mNeedUpdateGroupInfo = false;  //update groupinfo onCreate.
    public JSONObject mReportGroupObj = new JSONObject();

	//groupdetail fragment state
	public int mSteps = 0;
	public boolean mTargetReminderDone = false;
	public String mSelectedGroupName = "";
	public JSONArray mPedoUserArray = new JSONArray();
	private long mLastFetchTime = 0;
	
	// mygroup fragment state
	public String mJoinGroupState = BARTITLE_JOINGROUP;
	public JSONArray mGroupArray = new JSONArray();
	public JSONArray mFamousGroupArray = new JSONArray();
	public JSONArray mHideGroupArray = new JSONArray();
	public long mLastGetGroupInfoTime = 0;
	private long mLastGetGroupPedoTime = 0;
	private boolean mDefaultGroupJoined = false;

	//training fragment
	public JSONArray mTrainArray = new JSONArray();
	
	//map fragment
	private boolean mOfflineMapChecked = false;
	public boolean mMapTracking = false;
	public boolean mFirstGPSLocated = false;
	public double mLatitude, mLongitude, mSpeed = 0, mAvgSpeed = 0;
	public double mCalories = 0;
	public double mMaxSpeed = 0;
	public float mTotalDistance = 0;
	public String mLocalCityCode = "";
	public String mLocalCity="";
	public long mStartTiming = 0;
	public JSONArray mWalkingRecList = new JSONArray();
	private JSONArray mWalkingArray = new JSONArray();
	private int mWalkingPositionIndex = 0;

	// feedback
	public FeedbackAgent mFeedback;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UmengUpdateAgent.update(this);

        ShareSDK.initSDK(this);
        
        mContext = this;
        MobclickAgent.setDebugMode(true);
//      SDK��ͳ��Fragmentʱ����Ҫ�ر�Activity�Դ���ҳ��ͳ�ƣ�
//		Ȼ����ÿ��ҳ�������¼���ҳ��ͳ�ƵĴ���(���������� onResume �� onPause ��Activity)��
		MobclickAgent.openActivityDurationTrack(false);
//		MobclickAgent.setAutoLocation(true);
//		MobclickAgent.setSessionContinueMillis(1000);
		MobclickAgent.updateOnlineConfig(this);
        
		MapsInitializer.sdcardDir = getSdCacheDir(this);
        try {
            MapsInitializer.initialize(this); 
        } catch (RemoteException e) {
        	System.out.println("MapsInitializer error." + e.toString());
        }
                
        initActionBarTitle();
        
        mFeedback = new FeedbackAgent(this);
        mFeedback.sync();

        mPerfData = (PreferencesData) getApplicationContext();
		mPerfData.LoadUserLoginInfo();
		mPerfData.LoadSelectedGroupInfo();
		mPerfData.LoadGroupArrayInfo();
		mPerfData.LoadFetchGroupInfo();
		mPerfData.LoadLocationInfo();

		mLatitude = mPerfData.getLastLatitude();
		mLongitude = mPerfData.getLastLongtitude();
		
		mSteps = mPerfData.getUserSteps();
		mSelectedGroupName = mPerfData.getSelectedGroupName();

		mLastFetchTime = mPerfData.getFetchGroupDate();
		
		mPedoServiceIsRunning = CheckPedoServiceRunning();
		
		initImageLoader(getApplicationContext());

		System.out.println("Name: " + mPerfData.getUserName());
		System.out.println("UUID: " + mPerfData.getThirdPartID());
		System.out.println("headimageurl: " + mPerfData.getUserIconUrl());
		
        // set the Behind View
		setBehindContentView(R.layout.menu_frame);
		if (savedInstanceState == null) {
			Fragment mainFragment = new PedoFragment();
			FragmentTransaction t = this.getSupportFragmentManager().beginTransaction();
			t.add(R.id.container, mainFragment, TAG_FRAGMENT_PEDO);

            mFrag = new MenuListFragment();
			t.replace(R.id.list_frame, mFrag);
			t.commit();
		} else {
			mFrag = (ListFragment)this.getSupportFragmentManager().findFragmentById(R.id.list_frame);
		}

		// customize the SlidingMenu
		SlidingMenu sm = getSlidingMenu();
		sm.setShadowWidthRes(R.dimen.shadow_width);
		sm.setShadowDrawable(R.drawable.shadow);
		sm.setBehindOffsetRes(R.dimen.slidingmenu_offset);
		sm.setFadeDegree(0.35f);
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);

		this.setSlidingActionBarEnabled(true);
		
		if(!mPerfData.getUserID().equals("")){

			// update userName and headImage in SlidingMenu
			TextView nameTxView =(TextView)findViewById(R.id.name_TextView);
			nameTxView.setText(mPerfData.getUserName());
			
			ImageView headImage = (ImageView)findViewById(R.id.headimageButton);
			displayHeadImage(mPerfData.getUserIconUrl(), headImage);
			
			try {
				if( ! mPerfData.getGroupArray().equals("")){
					// if saved data exists, display it first.
					mGroupArray = new JSONArray(mPerfData.getGroupArray());
				}
	
				if( ! mPerfData.getHideGroup().equals("")){
					// if saved data exists, display it first.
					mHideGroupArray = new JSONArray(mPerfData.getHideGroup());
				}
	
				if( ! mPerfData.getFamousGroupArray().equals("")){
					mFamousGroupArray = new JSONArray(mPerfData.getFamousGroupArray());
				}
				
		    	if( ! mPerfData.getTrainingPlans().equals("")){
	    			mTrainArray = new JSONArray(mPerfData.getTrainingPlans());
		    	}
		    	
		    	if( ! mPerfData.getFetchUserArray().equals("")){
		    		mPedoUserArray = new JSONArray(mPerfData.getFetchUserArray());
		    	}
		    	
		    	if(! mPerfData.getWalkingRecList().equals("")){
		    		mWalkingRecList = new JSONArray(mPerfData.getWalkingRecList());
		    	}
			} catch (JSONException e) {
				System.out.println("MainActivity: Parse saved groupArray failed.");
			}
			
			// update data on create.
			ExecuteGetGroupInfo(mPerfData.getUserID());
		}
    }

    private void initActionBarTitle() {

    	requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.main_activity);
    	getWindow().setFeatureInt(
   			 Window.FEATURE_CUSTOM_TITLE, 
   			 R.layout.action_bar);
    	
    	mActionBarMenu = (TextView)findViewById(R.id.actionbar_menubutton);
    	mActionBarHomeIcon = (ImageView)findViewById(R.id.actionbar_icon);
    	mActionBarTitle = (TextView)findViewById(R.id.actionbar_title);
    	mActionBarIconBG = (RelativeLayout)findViewById(R.id.actionbar_iconbackground);
     	
    	mActionBarMenu.setOnClickListener(new View.OnClickListener() { 
    		 @Override 
    		 public void onClick(View v) { 
    		    	TextView tv = (TextView)v;
    		    	String menuTitle = (String) tv.getText();
    		    	if(menuTitle.equals(MENUTITLE_LOGIN_LOGIN)){
    		        	System.out.println("botton: ע��");
    		    		
    		    	}else if(menuTitle.equals(MENUTITLE_LOGIN_LOGOUT)){
    		        	System.out.println("botton: ע��");
    		            AlertDialog isLogout = new AlertDialog.Builder(MainActivity.this).create();  
    		            isLogout.setTitle("ע��");  
    		            isLogout.setMessage("ȷ��Ҫע��"+ mPerfData.getUserName() + "��");  
    		            isLogout.setButton("ȷ��", logoutListener);  
    		            isLogout.setButton2("ȡ��", logoutListener);  
    		            isLogout.show();  

    		    	}else if(menuTitle.equals(MENUTITLE_SHARE)){
    		        	System.out.println("botton: ����");
    		        	if(mActionBarTitle.getText().equals(BARTITLE_PEDO)){
    		        		showPedoShare();
    		        	}else if(mActionBarTitle.getText().equals(BARTITLE_RECORD)){
    		        		showRecordShare();
    		        	}
    		    	}else if(menuTitle.equals(MENUTITLE_GROUP_CREATE)){
    		        	System.out.println("botton: ����");
    		        	TransToJoinGroupFragment(BARTITLE_CREATEGROUP);
    		    	}else if(menuTitle.equals(MENUTITLE_GROUP_SWITCH)){
    		        	System.out.println("botton: �л�");
    		    		SwitchJoinGroupState();
    		    	}else if(menuTitle.equals(MENUTITLE_GROUP_QUIT)){
    		        	System.out.println("botton: �˳��");
    		            AlertDialog isQuit = new AlertDialog.Builder(MainActivity.this).create();  
    		            isQuit.setTitle("������ʾ");  
    		            isQuit.setMessage("û���������˳�����");  
    		            isQuit.setButton("ȷ��", quitGroupListener);  
    		            isQuit.setButton2("�����棬���˳�", quitGroupListener);  
    		            isQuit.show();
    		    	}else if(menuTitle.equals(MENUTITLE_MOREPLAN)){
    		    		TransToTrainingListsFragment();
    		    		
    		    	}else if(menuTitle.equals(MENUTITLE_RESTARTPLAN)){
    		            AlertDialog isRestart = new AlertDialog.Builder(MainActivity.this).create();  
    		            isRestart.setTitle("������ʾ");  
    		            isRestart.setMessage("ѵ���ƻ����ڽ����У����Ҫ����?");  
    		            isRestart.setButton("�ټ��һ��", restartPlanListener);  
    		            isRestart.setButton2("���ˣ��´�����", restartPlanListener);  
    		            isRestart.show();
    		    	}
    		 } 
    	});
    	
    	mActionBarMenu.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(!mActionBarMenu.getText().equals("")){
			    	  switch (event.getAction()) { 	  
		    	        case MotionEvent.ACTION_DOWN:
		    	        	mActionBarMenu.setBackgroundResource(R.color.orange);
		    	            break;
		    	        case MotionEvent.ACTION_CANCEL:
		    	        case MotionEvent.ACTION_UP:
		    	        	mActionBarMenu.setBackgroundResource(R.color.deepskyblue);
		    	            break;
		    	        default:
		    	            break;
		    	    }
				}
	    	    return false;
			}
		});
    	
    	mActionBarHomeIcon.setOnClickListener(new View.OnClickListener() {
	   		 @Override 
	   		 public void onClick(View v) { 
	   	    	if(!ReturnToPrevFragment()){
	   	        	toggle();
	   	    	}
	   		 }
    	});
    	
    	mActionBarHomeIcon.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	  switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mActionBarIconBG.setBackgroundResource(R.color.orange);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mActionBarIconBG.setBackgroundResource(R.color.deepskyblue);
	    	            break;
	    	        default:
	    	            break;
	    	    }
			    return false;
			}
		});
    	
    	//ActionBar actionBar = getSupportActionBar();
        
        //actionBar.setDisplayShowTitleEnabled(false);
        //actionBar.setDisplayUseLogoEnabled(false);
        //actionBar.setDisplayHomeAsUpEnabled(false);
    	//actionBar.setLogo(R.drawable.icon_home);
        //actionBar.setTitle("");

        //View mainActionBarView = LayoutInflater.from(this).inflate(R.menu.main, null);
        //actionBar.setCustomView(mainActionBarView);

    }

    public void onClick_headimageButton(View v){
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_LOGINVIEW);
    	if(mainfragment == null){
        	Fragment currentfragment=getSupportFragmentManager().findFragmentById(R.id.container);
        	
        	PushCurrentFragment(currentfragment.getTag());
        	
        	mainfragment = new LoginViewFragment();
        	FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        	t.add(R.id.container, mainfragment, TAG_FRAGMENT_LOGINVIEW);
            t.remove(currentfragment);
            t.commit();
    	}
        //toggle();
        getSlidingMenu().showContent();
        
    }    
   
    @Override
    protected void onResume() {
        super.onResume();
		MobclickAgent.onPageStart( mPageName );
		MobclickAgent.onResume(mContext);
        
        // Start the service if this is considered to be an application start (last onPause was long ago)
        if (!mPedoServiceIsRunning) {
            startStepService();
            bindStepService();
        }
        else{
            bindStepService();
        }
    }

    @Override
    protected void onPause() {
        if (mPedoServiceIsRunning) {
            unbindStepService();
        }
        super.onPause();
		MobclickAgent.onPageEnd( mPageName );
		MobclickAgent.onPause(mContext);
	}

    @Override
    protected void onDestroy() {
        if (mQuitPedoService && mPedoServiceIsRunning) {
            stopStepService();
        }
        
		mPerfData.SaveUserLoginInfo();
		mPerfData.SaveSelectedGroupInfo();
		mPerfData.SaveGroupArrayInfo();
		mPerfData.SaveFetchGroupInfo();
		mPerfData.SaveLocationInfo();
        
		super.onDestroy();
    }

    /**===============================  Pedo Service Functions End =============================**/
    private void startStepService() {
        if (! mPedoServiceIsRunning) {
        	mPedoServiceIsRunning = true;

        	Intent intent = new Intent();
        	intent.setClass(MainActivity.this, PedoService.class);
            startService(intent);
        }
    }
    
    private void bindStepService() {
        bindService(new Intent(MainActivity.this, 
                PedoService.class), mPedoConnection, Context.BIND_AUTO_CREATE + Context.BIND_DEBUG_UNBIND);
    }

    private void unbindStepService() {
        unbindService(mPedoConnection);
    }
    
    private void stopStepService() {
        if (mService != null) {
            stopService(new Intent(MainActivity.this,
                  PedoService.class));
        }
   }
    
    private ServiceConnection mPedoConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            mService = ((PedoService.PedoBinder)service).getService();
            mService.registerCallback(mPedoCallback);
        }

        public void onServiceDisconnected(ComponentName className) {
            mService = null;
        }
    };

    /**
     *  Receive msg from Pedo service.
     */
    private PedoService.ICallback mPedoCallback = new PedoService.ICallback() {
        public void stepsChanged(int value) {
        	mPedoMsgHandler.sendMessage(mPedoMsgHandler.obtainMessage(STEPS_MSG, value, 0));
        }
        
        public void locationChanged(double latitude, double longitude, double speed, String city, String citycode, String provider){
        	Message msg = mPedoMsgHandler.obtainMessage(LOCATION_MSG);
        	
    		Bundle b=new Bundle();
    		b.putDouble("latitude", latitude);
    		b.putDouble("longitude", longitude);
    		b.putDouble("speed", speed);
    		b.putString("city",  city);
    		b.putString("citycode", citycode);
    		b.putString("provider", provider);
    		msg.setData(b);

    		mPedoMsgHandler.sendMessage(msg);
        }
    };    

    private static final int STEPS_MSG = 1;
    private static final int LOCATION_MSG = 2;

    private Handler mPedoMsgHandler = new Handler(){
        @Override 
        public void handleMessage(Message msg) {
            switch(msg.what) {
                case STEPS_MSG:
                	mSteps = (int)msg.arg1;
                    
                	if(mSteps >= mPerfData.getUserTarget()){
	                	if(mPerfData.getTargetReminder() && !mTargetReminderDone){
	                		Toast.makeText(MainActivity.this, "����Ŀ�������", Toast.LENGTH_SHORT).show();
	                		Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
	                		if(v.hasVibrator()){
	                			long[] pattern = { 0, 500, 200, 500, 200, 500, 200, 500 };
	                			v.vibrate(pattern, -1);
	                		}
	    	            	mTargetReminderDone = true;
	                	}
                	}else{
                		mTargetReminderDone = false;
                	}
                	
                	Fragment pedofragment=getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_PEDO);
                	if(pedofragment != null)
                    {
                		TextView curTextView = (TextView) MainActivity.this.findViewById(R.id.cur_progress);
                		curTextView.setText(mSteps + "��");
                		
                		RoundRndProgressBar pBar= (RoundRndProgressBar) MainActivity.this.findViewById(R.id.progressBar_pedo); 
                		pBar.setMax(mPerfData.getUserTarget());
                		pBar.setProgress(mSteps);
                		
                        int calorie = (int)(mSteps * 400 / 10000);
                        int chicken_num  = (int)(calorie / 200);
                        int rice_num = (int)((calorie%200)/50);
                        int coffee_num = (int)((calorie%50)/20);
                        
                        TextView calText = (TextView) MainActivity.this.findViewById(R.id.calorie);
                        calText.setText("ȼ��"+calorie+"��");
                        
                        TextView chickenNumTV = (TextView) MainActivity.this.findViewById(R.id.chicken_number);
                        chickenNumTV.setText("x" + chicken_num);
                        
                        TextView riceNumTV = (TextView) MainActivity.this.findViewById(R.id.rice_number);
                        riceNumTV.setText("x" + rice_num);
                        
                        TextView coffeeNumTV = (TextView) MainActivity.this.findViewById(R.id.coffee_number);
                        coffeeNumTV.setText("x" + coffee_num);
                		
                	}
                    break;
                case LOCATION_MSG:
        			Bundle b = msg.getData();
        			double latitude = b.getDouble("latitude");
        			double longitude = b.getDouble("longitude");
        			double speed = b.getDouble("speed");
        			String city = b.getString("city");
        			String citycode = b.getString("citycode");
        			String provider = b.getString("provider");

        			MapFragment mapfragment=(MapFragment)getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_MAP);
                	if(mapfragment != null){

            			if(provider.equals("lbs") ){
            				
            				if(!mLocalCityCode.equals(citycode)){
            					mOfflineMapChecked = false;
            				}
            				
            				mLocalCityCode = citycode;
            				mLocalCity = city;
            				
            				if(!mOfflineMapChecked){
            					mapfragment.IsOfflineMapDownloaded();
            					mOfflineMapChecked = true;
            				}
            			}
            			
            			if(provider.equals("gps") &&
            					mapfragment.aMap != null && mapfragment.marker != null &&
            					(latitude != mLatitude || longitude != mLongitude)){

            				LatLng newLatLng = new LatLng(latitude, longitude);
            				LatLng origLatLng = new LatLng(mLatitude, mLongitude);

        					float distance = AMapUtils.calculateLineDistance(origLatLng, newLatLng);
        					//check for abnormal point.
        					if(distance > 200){
        						distance = 10;
        					}
        					
    						mTotalDistance += distance;
       						mSpeed = speed * 3.6;   // 1 m/s = 3.6 km/h

       						// cal = distance(m) * 0.063,  
       						mCalories =  (mTotalDistance) * 0.063f;
       						
        					if(speed > mMaxSpeed){
        						mMaxSpeed = speed;
        					}
            					
            				mapfragment.marker.setPosition(newLatLng);// ��λ�״�Сͼ��

            				if(mMapTracking){
            					
            					DecimalFormat dcmFmt1 = new DecimalFormat("0.0");
            					DecimalFormat dcmFmt2 = new DecimalFormat("0.00");

            					if(mTotalDistance <= 1000){
            						mapfragment.mWalkingDistanceTV.setText(dcmFmt1.format(mTotalDistance));
            						mapfragment.mWalkingUnitTV.setText("��");
            					}else{
            						mapfragment.mWalkingDistanceTV.setText(dcmFmt2.format(mTotalDistance/1000));
            						mapfragment.mWalkingUnitTV.setText("ǧ��");
            					}
            					
            					mapfragment.mWalkingSpeedTV.setText(dcmFmt2.format(mSpeed));

            					mapfragment.mWalkingCaloriesTV.setText(dcmFmt1.format(mCalories));
            					
            					float bearing = mapfragment.aMap.getCameraPosition().bearing;
		            			float zoom = mapfragment.aMap.getCameraPosition().zoom;
		            			//mapfragment.marker.setRotateAngle(bearing);
		            			//mapfragment.aMap.setMyLocationRotateAngle(bearing);// ����С������ת�Ƕ�
	            				mapfragment.aMap.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.builder()
	            					.target(newLatLng)
	            					.zoom(zoom)
	            					.bearing(bearing)
	            					.tilt(45)
	            					.build()));
	            				
	            				if(mFirstGPSLocated){
		            				double ratio = mSpeed / 20;
		            				if(ratio > 1.0f){
		            					ratio = 1.0f;
		            				}
		            				int color =  Color.rgb(((int)(1.0f-ratio)*255), 255, (int)(ratio*255));
		            				
		            				mapfragment.aMap.addPolyline((new PolylineOptions()).add(origLatLng, newLatLng)
		            						.width(25).geodesic(false).color(color));
		            				
		            				mWalkingPositionIndex ++;
		            				RecordCurrentLocation(mWalkingPositionIndex, newLatLng);
	            				}else{
	            					//first point
	    							mapfragment.addStartMarker(newLatLng);
	    							mFirstGPSLocated = true;
	    							
	    							mWalkingArray = new JSONArray();
	    							mWalkingPositionIndex = 0;
	    							RecordCurrentLocation(mWalkingPositionIndex, newLatLng);
	    						}
	    						
	            				int totalDist = Math.round(mTotalDistance);
	            				if(totalDist > 0){
	            					mapfragment.mWalkingTV.setText( totalDist + "��");
	            				}
	            			}
            				
            				//only update location on GPS provider
                			mLatitude = latitude;
                			mLongitude = longitude;
            			}
        			}

                	break;
                default:
                    super.handleMessage(msg);
            }
        }
    };    

    
    /**===============================  MapView Functions Start =============================**/
	private CallbackListener locationReportCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					//System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						Toast.makeText(MainActivity.this, "�ϴ��ɼ��ɹ�", Toast.LENGTH_SHORT).show();
						System.out.println("location report success");
					}else{
						Toast.makeText(MainActivity.this, "�ϴ��ɼ�ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("location report failed");
					}
					
				} catch (JSONException e) {
					System.out.println("ExecuteLocationReport: " + e.toString());
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteLocationReport(JSONArray walkArray, String date) {
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_MAP);
    	
    	if(mainfragment != null){

	        JSONObject locReportObj = new JSONObject();  
	        
	        /**
	         * json={"userId":"53986869be258b40ec6975a7","locations":[{"LocatY":0,"LocatX":1},
	         * {"LocatY":2,"LocatX":2},{"LocatY":4,"LocatX":3}],"date":"2014-07-06 16:53:19"}
	         */
	        if(walkArray != null){
		        try {
		        	locReportObj.put("userId", mPerfData.getUserID());
		        	locReportObj.put("date", date);
		        	
		        	JSONArray locArray = new JSONArray();
		        	int locCount = walkArray.length();
		        	for(int i=0; i<locCount; i++){
		        		JSONObject locEntry = walkArray.getJSONObject(i);
		        		
			        	JSONObject locObj = new JSONObject();
			        	locObj.put("LocatX", locEntry.getDouble("lat"));
			        	locObj.put("LocatY", locEntry.getDouble("long"));
			        	locArray.put(locObj);
		        	}
		        	
		        	locReportObj.put("locations", locArray);
	
				} catch (JSONException e) {
					System.out.println("ExecuteLocationReport: " + e.toString());
				}
		        String locReportStr = "json=" + locReportObj.toString();
		        
		        System.out.println(locReportStr);
		        
		    	HttpConnection conn = new HttpConnection();
		    	conn.post("/user/location/report", locReportStr, locationReportCallbackListener);
	        }
    	}
    }

	private CallbackListener locationGetCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * {"result":"success","locations":[{"locations":[{"LocatY":0,"LocatX":1},
				 * {"LocatY":2,"LocatX":2},{"LocatY":4,"LocatX":3}],
				 * "userId":"53986869be258b40ec6975a7","date":"2014-07-06 16:23:50"}],
				 * "lcCount":1}
				 */
				try {
					
					System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						int locCount = obj.getInt("lcCount");
						Toast.makeText(MainActivity.this, "��ȡ" + locCount + "����ʷ�ɼ�", Toast.LENGTH_SHORT).show();

						SaveDownloadedRecord(obj);
						
						System.out.println("location get success");
					}else{
						Toast.makeText(MainActivity.this, "��ȡ��ʷ�ɼ�ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("location get failed");
					}
					
				} catch (JSONException e) {
					System.out.println("ExecuteLocationGet: " + e.toString());
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteLocationGet(String startTime) {
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_RECORD);
    	
    	if(mainfragment != null){

	        JSONObject locGetObj = new JSONObject();  
	        
	        /**
	         * json={"startTime":"2014-07-06 16:53:19","userId":"539286dc26a8fca879756506"}��
	         */
	        try {
	        	locGetObj.put("userId", mPerfData.getUserID());
	        	locGetObj.put("startTime", startTime);
			} catch (JSONException e) {
				System.out.println("ExecuteLocationGet: " + e.toString());
			}
	        String locGetStr = "json=" + locGetObj.toString();
	        
	        //System.out.println(locGetStr);
	        
	    	HttpConnection conn = new HttpConnection();
	    	conn.post("/user/location/get", locGetStr, locationGetCallbackListener);
    	}
    }    
    
    private void SaveDownloadedRecord(JSONObject obj){
		/**
		 * {"result":"success","locations":[{"locations":[{"LocatY":0,"LocatX":1},
		 * {"LocatY":2,"LocatX":2},{"LocatY":4,"LocatX":3}],
		 * "userId":"53986869be258b40ec6975a7","date":"2014-07-06 16:23:50"}],
		 * "lcCount":1}
		 */
    	if(obj != null){
			DecimalFormat dcmFmt2 = new DecimalFormat("0.00");
			
			try {
				JSONArray locResultArray = obj.getJSONArray("locations");
				int locResultCount = locResultArray.length();
				for(int i=0; i<locResultCount; i++){
					JSONObject locResultEntry = locResultArray.getJSONObject(i);
					String date = locResultEntry.getString("date");
					//TODO: check if there is duplicated records
					
					JSONArray saveArray = new JSONArray();
					JSONArray locArray = locResultEntry.getJSONArray("locations");
					int locCount = locArray.length();
					for(int j=0; j<locCount; j++){
						JSONObject locEntry = locArray.getJSONObject(j);
						double lat = locEntry.getDouble("LocatX");
						double lng = locEntry.getDouble("LocatY");
						
						JSONObject savePoint = new JSONObject();
						savePoint.put("ind", j);
						savePoint.put("lat", lat);
						savePoint.put("long", lng);
						
						saveArray.put(savePoint);
						
						System.out.println("Location " + j + ": " + dcmFmt2.format(lat) + " : " + dcmFmt2.format(lng));
					}
					
					mPerfData.SaveWalkingRecord(date, saveArray.toString());
					//TODO: update the mWalkingRecList
				}
			} catch (JSONException e) {
				System.out.println("SaveDownloadedRecord: " + e.toString());
			}
    	}
    }
    
    public void AddWalkingRecList(String walkDate, long duration, 
    		double distance, double cal, double avgspeed){

    	if(mWalkingRecList != null && distance > 0){
    		JSONObject walkEntry = new JSONObject();
    		try {
				walkEntry.put("date", walkDate);
				walkEntry.put("duration", duration);
				walkEntry.put("distance", distance);
				walkEntry.put("calories", cal);
				walkEntry.put("speed", avgspeed);
				
				mWalkingRecList.put(walkEntry);
				
				mPerfData.setWalkingRecList(mWalkingRecList.toString());
				mPerfData.SaveWalkingRecordList();
				mPerfData.SaveWalkingRecord(walkDate, mWalkingArray.toString());
			} catch (JSONException e) {
				System.out.println("AddWalkingRecList: " + e.toString());
			}
    	}
    }
    
    private void RecordCurrentLocation(int index, LatLng latlng){
    	
    	if(mWalkingArray != null){
    		JSONObject locationEntry = new JSONObject();
    		try{
    			locationEntry.put("ind", index);
    			locationEntry.put("lat", latlng.latitude);
    			locationEntry.put("long", latlng.longitude);
    			
    			mWalkingArray.put(index, locationEntry);
    		}catch( JSONException e){
    			System.out.println("RecordCurrentLocation: " + e.toString());
    		}
    	}
    }
    
    /**
     *  Send broadcast msg to PedoService to switch location servcie.
     */
    public void sendSwitchGPSCmd(boolean onOff) {  
    	
        Intent intent = new Intent(PedoService.SWITCH_GPS);
        intent.putExtra(PedoService.SWITCH_GPS, onOff);
        sendBroadcast(intent);
    }
    /**===============================  MapView Functions End =============================**/
    
    /**
     *  Send broadcast msg to PedoService to update step.
     */
    protected void sendUpdateStepCmd() {  
        Intent intent = new Intent(PedoService.UPDATE_STEP);  
        sendBroadcast(intent);
    }
    
    /**
     *  Send broadcast msg to PedoService to update report JSON.
     */
    protected void sendUpdateReportJSONCmd() {  
    	
        Intent intent = new Intent(PedoService.UPDATE_USERGROUP);
        //intent.putExtra(PreferencesData.PreferenceStrings[PreferencesData.USER_USERID], mPerfData.getUserID());
        //intent.putExtra(PreferencesData.PreferenceStrings[PreferencesData.USER_USERNAME], mPerfData.getUserName());
        //intent.putExtra(PreferencesData.PreferenceStrings[PreferencesData.GROUP_LIST], mPerfData.getGroupArray());
        //intent.putExtra(PreferencesData.PreferenceStrings[PreferencesData.GROUP_HIDEGROUP], mPerfData.getHideGroup());
        sendBroadcast(intent);
    }
	
    private boolean CheckPedoServiceRunning(){
    	boolean isPedoServiceRunning = false; 
	    ActivityManager manager = (ActivityManager)getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE); 
	    for (RunningServiceInfo service :manager.getRunningServices(Integer.MAX_VALUE)) { 
		    if(service.service.getClassName().equals("cn.candone.appstepfun.pedo.PedoService")) 
		    { 
		    	isPedoServiceRunning = true; 
		    } 
	    }
    	return isPedoServiceRunning;
    }    
    /**===============================  Pedo Service Functions End =============================**/

    /**
     *  Check if quit the appStepfun and stop Pedo service.
     */
    @Override  
    public boolean onKeyDown(int keyCode, KeyEvent event)  
    {  
        if (keyCode == KeyEvent.KEYCODE_BACK )  
        {
        	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_MAP);
        	if(mainfragment != null){

        	}
        	
        	if(! ReturnToPrevFragment()){
	            AlertDialog isExit = new AlertDialog.Builder(this).create();  
	            isExit.setTitle("�˳�");  
	            isExit.setMessage("ȷ��Ҫ�˳�������");  
	            isExit.setButton("����һ���", exitListener);
	            isExit.setButton3("�����ǲ���", exitListener);
	            isExit.setButton2("����������", exitListener);
	            isExit.show();
        	}
        }  
        return false;  
    }
    
    DialogInterface.OnClickListener exitListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
                break;  
            case AlertDialog.BUTTON_NEUTRAL: //
    			Intent intent = new Intent(Intent.ACTION_MAIN);
    			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    			intent.addCategory(Intent.CATEGORY_HOME);
    			startActivity(intent);
    			break;
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
            	mQuitPedoService = true;
                finish(); 
                break; 
            }  
        }  
    };    
 
    public static void displayHeadImage(String url, ImageView imgView){
    	try{
	        DisplayImageOptions options = new DisplayImageOptions.Builder()  
	        .showImageOnLoading(R.drawable.app_default)
	        .showImageForEmptyUri(R.drawable.app_default)  
	        .showImageOnFail(R.drawable.app_default)
	        .cacheInMemory(true)
	        .cacheOnDisk(true)
	        .considerExifParams(true)
	        //.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)  
	        //.bitmapConfig(Bitmap.Config.RGB_565)  
	        //.decodingOptions(android.graphics.BitmapFactory.Options decodingOptions)//����ͼƬ�Ľ�������  
	        //.delayBeforeLoading(int delayInMillis)//int delayInMillisΪ�����õ�����ǰ���ӳ�ʱ��
	        //����ͼƬ���뻺��ǰ����bitmap��������  
	        //.preProcessor(BitmapProcessor preProcessor)  
	        //.resetViewBeforeLoading(true)//����ͼƬ������ǰ�Ƿ����ã���λ  
	        .displayer(new RoundedBitmapDisplayer(180)) // round conner  
	        .build();
	    	
	        ImageLoader.getInstance().displayImage(url, imgView, options); 
		}catch(Exception e){
			System.out.println("displayHeadImage: " + e.toString());
		}
    }


	
    /**===============================  LoginView Functions Start =============================**/
	
    DialogInterface.OnClickListener logoutListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
            	LogOutAppStepFun();
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
                break;  
            default:  
                break;  
            }  
        }  
    }; 
    
    private void TransToThirdPartLoginActivity(){
        Intent it = new Intent();
        it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        it.setClass(MainActivity.this,  
            		ThirdPartLoginActivity.class);
        MainActivity.this.startActivity(it);  
        MainActivity.this.finish();  
    }
    
	private void LogOutAppStepFun(){
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_LOGINVIEW);
    	
    	if(mainfragment != null){
	 		// clear user state 
			mPerfData.ClearUserLoginInfo();
			//mPerfData.SaveUserLoginInfo();

			mPerfData.ClearGroupArrayInfo();
			//mPerfData.SaveGroupArrayInfo();
			
			mPerfData.ClearFetchGroupInfo();
			
			//groupdetail fragment state
			mSelectedGroupName = "";
			
			// mygroup fragment state
			mGroupArray = new JSONArray();
			mHideGroupArray = new JSONArray();
			mFamousGroupArray = new JSONArray();
			mTrainArray = new JSONArray();
			
			// update UI 
			TextView nameTxtView = (TextView)findViewById(R.id.nameTextView);
			nameTxtView.setText("����û�е�½");
			nameTxtView = (TextView)findViewById(R.id.name_TextView);
			nameTxtView.setText("����û�е�½");
			
			ImageView headImage = (ImageView)findViewById(R.id.headerImage);
			displayHeadImage(mPerfData.getUserIconUrl(), headImage);
			headImage = (ImageView)findViewById(R.id.headimageButton);
			displayHeadImage(mPerfData.getUserIconUrl(), headImage);
			
			mActionBarMenu.setText(MENUTITLE_LOGIN_LOGIN);
	    	sendUpdateReportJSONCmd();
	    	
	    	ClearFragmentStack();
	    	
	    	TransToThirdPartLoginActivity();
	    	
    	}
    }

    /**===============================  LoginView Functions Start =============================**/

    /**===============================  MyGroup Functions Start =============================**/

	public void TransToJoinGroupFragment(String state){
		if(mPerfData.getUserID().equals("")){
	        Toast.makeText(MainActivity.this, "����û�е�½", Toast.LENGTH_SHORT).show();
		}else{
			
			mJoinGroupState = state;
			
	    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_JOINGROUP);
	    	if(mainfragment == null){
	        	Fragment currentfragment=getSupportFragmentManager().findFragmentById(R.id.container);
	        	PushCurrentFragment(currentfragment.getTag());
	        	
	        	mainfragment = new JoinGroupFragment();
	        	FragmentTransaction t = getSupportFragmentManager().beginTransaction();
	        	t.add(R.id.container, mainfragment, TAG_FRAGMENT_JOINGROUP);
	            t.remove(currentfragment);
	            t.commit();
	    	}
		}
		
	}

	public void TransToSquareFragment(){
		if(mPerfData.getUserID().equals("")){
	        Toast.makeText(MainActivity.this, "����û�е�½", Toast.LENGTH_SHORT).show();
		}else{
			
	    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_SQUARE);
	    	if(mainfragment == null){
	        	Fragment currentfragment=getSupportFragmentManager().findFragmentById(R.id.container);
	        	PushCurrentFragment(currentfragment.getTag());
	        	
	        	mainfragment = new SquareFragment();
	        	FragmentTransaction t = getSupportFragmentManager().beginTransaction();
	        	t.add(R.id.container, mainfragment, TAG_FRAGMENT_SQUARE);
	            t.remove(currentfragment);
	            t.commit();
	    	}
		}
		
	}
	
	@Override
	public void OnGroupListFragmentCreated(GroupListFragment context){
		if(context.getGroupListFragmentTag().equals(GroupListFragment.TAG_PRIVATE)){
			UpdateMyGroupListView(context, mGroupArray);
		}else{
			UpdateMyGroupListView(context, mFamousGroupArray);
		}
	}
    /**===============================  MyGroup Functions End =============================**/

	/**=============  GroupInfo & UserInfo refresh Functions Start ========================**/
	private CallbackListener GetGroupInfoCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"groupCount":2,"result":"success","groups":
				 *  [{"userCount":5,"users":[{"userId":"53984e3bbe2549fe3895f3fa",
				 *  "userName":"tony@test1"},{"userId":"53986869be258b40ec6975a7",
				 *  "userName":"̫������","photoUrl":"xxxx"},{"userId":"539d1d5d66115e3c0e564e07","userName":"tony"},
				 *  {"userId":"539d364066115e3c0e564e08","userName":"tony","photoUrl":"xxxx"},
				 *  {"userId":"539d38fb66115e3c0e564e0b","userName":"������","photoUrl":"xxxx"}]
				 *  ,"groupName":"C1"},{"userCount":2,"users":
				 *  [{"userId":"53986869be258b40ec6975a7","userName":"̫������","photoUrl":"xxxx"},
				 *  {"userId":"539d99b466115e3c0e564e25","userName":"ɺɺ"}],"groupName":"������"}]}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						System.out.println("get group success ");
						//System.out.println(obj.toString());
						SetActivityGroup(obj);

						Calendar cd = Calendar.getInstance();
						mLastGetGroupInfoTime = cd.getTimeInMillis();

						
					}else{
						Toast.makeText(MainActivity.this, "��ȡ�Ȧʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("get group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("MyGroupFragment: parse get group result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteGetGroupInfo(String userId) {
    	
    	if(userId.equals("")){
    		return;
    	}
    	
        JSONObject getGroupObj = new JSONObject();  

        /**
         * json={"userId":"5392ea8572d69e4d30d22faf"}
         */
        try {
        	getGroupObj.put("userId", userId);

		} catch (JSONException e) {
			e.printStackTrace();
		}
        String getGroupStr = "json=" + getGroupObj.toString();
        
        //System.out.println(getGroupStr);
        
    	HttpConnection conn = new HttpConnection();
    	conn.post("/group/getusergroups", getGroupStr, GetGroupInfoCallbackListener);
    }


    
	private CallbackListener GetGroupPedoCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"groupCount":2,"result":"success","groupsData":
				 *  [{"groupName":"C1","dataCount":1,"pedoData":[{"groupName":"C1","userId":"53984e3bbe2549fe3895f3fa",
				 *  "userName":"tony@test1","steps":"3517","date":"2014-06-12...
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						System.out.println("get group pedo success ");
						//System.out.println(obj.toString());
						Calendar cd = Calendar.getInstance();
						mLastGetGroupPedoTime = cd.getTimeInMillis();
						
						MyGroupFragment myGroupFragment = (MyGroupFragment) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_MYGROUP);
						mGroupArray = SetUserSequence(mGroupArray, obj);
						mPerfData.setGroupArray(mGroupArray.toString());
						
						
						if(myGroupFragment != null)
						{
							UpdateMyGroupListView(myGroupFragment.mPrivateGroupList, mGroupArray);
						}
						
						mFamousGroupArray = SetUserSequence(mFamousGroupArray, obj);
						mPerfData.setFamousGroupArray(mFamousGroupArray.toString());
						//System.out.println("mFamousGroupArray: " + mFamousGroupArray.toString());
						if(myGroupFragment != null)
						{
							UpdateMyGroupListView(myGroupFragment.mFamousGroupList, mFamousGroupArray);
						}
		            	sendUpdateReportJSONCmd();
						ExecutePedoFetch();
						
					}else{
						System.out.println("get group pedo failed");
					}
					
				} catch (JSONException e) {
					System.out.println("MyGroupFragment: parst get group pedo result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteGetGroupPedo( boolean optional) {
    	
		long curTime = Calendar.getInstance().getTimeInMillis();
    	if( optional){
    		//check frequency on optional update. The time between two Get must larger than 10s.
    		if((curTime - mLastGetGroupPedoTime) < (10 * 1000)){
    			return;
    		}
    	}
  	
        JSONObject getGroupPedoObj = new JSONObject();  
        /**
         * json={"groupName":[{"groupName":"C1"},{"groupName":"C2"}]}
         */
        try {
        	
            JSONArray nameArray = new JSONArray();

            int groupCount = mGroupArray.length();
    		for(int i=0; i<groupCount; i++){
    			JSONObject groupEntry = mGroupArray.getJSONObject(i);
    			String groupName = groupEntry.getString("groupName");
    			
    			JSONObject groupNameObj = new JSONObject();
    			groupNameObj.put("groupName", groupName);
    			nameArray.put(groupNameObj);
    		}
    		
            int famousGroupCount = mFamousGroupArray.length();
    		for(int i=0; i<famousGroupCount; i++){
    			JSONObject groupEntry = mFamousGroupArray.getJSONObject(i);
    			String groupName = groupEntry.getString("groupName");
    			
    			JSONObject groupNameObj = new JSONObject();
    			groupNameObj.put("groupName", groupName);
    			nameArray.put(groupNameObj);
    		}    		
    		
    		getGroupPedoObj.put("groupName", nameArray);
		} catch (JSONException e) {
			System.out.println("MyGroupFragment: put groupName failed.");
		}
        
        if(getGroupPedoObj.length() > 0){
	        String getGroupPedoStr = "json=" + getGroupPedoObj.toString();
	        
	        //System.out.println(getGroupPedoStr);
	        
	    	HttpConnection conn = new HttpConnection();
	    	conn.post("/pedo/getgrouppedo", getGroupPedoStr, GetGroupPedoCallbackListener);
        }
    }

	private CallbackListener GetPedoFetchCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"groupCount":2,"result":"success","groupsData":
				 *  [{"groupName":"C1","dataCount":1,"pedoData":[{"groupName":"C1","userId":"53984e3bbe2549fe3895f3fa",
				 *  "userName":"tony@test1","steps":"3517","date":"2014-06-12...
				 */
				try {
					//System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						System.out.println("pedo fetch success ");
						//System.out.println(obj.toString());
						SetUserPedoRecords(obj);
						
				    	Calendar cd = Calendar.getInstance();
				    	long curDateTime = cd.getTimeInMillis();
				    	mLastFetchTime = curDateTime;
				    	mPerfData.setFetchGroupDate(mLastFetchTime);
					}else{
						System.out.println("pedo fetch failed");
					}
					
				} catch (JSONException e) {
					System.out.println("MyGroupFragment: parst pedo fetch result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecutePedoFetch() {

    	Calendar cd = Calendar.getInstance();
    	int curYear = cd.get(Calendar.YEAR);
    	int curMonth = cd.get(Calendar.MONTH);
    	int curDay = cd.get(Calendar.DAY_OF_MONTH);
    	int curHour = cd.get(Calendar.HOUR_OF_DAY);

    	cd.setTimeInMillis(mLastFetchTime);
    	int lastYear = cd.get(Calendar.YEAR);
    	int lastMonth = cd.get(Calendar.MONTH);
    	int lastDay = cd.get(Calendar.DAY_OF_MONTH);
    	int lastHour = cd.get(Calendar.HOUR_OF_DAY);
        
        if((curYear == lastYear) && (curMonth == lastMonth) && (curDay == lastDay) && (curHour == lastHour)){
        	SetUserPedoRecords(null);
        	return;
        }
        
        if((curYear == lastYear) && (curMonth == lastMonth) && (curDay == lastDay) && (lastHour >= 1)){
        	cd.set(Calendar.HOUR_OF_DAY, lastHour - 1);
        }else{
        	cd.set(Calendar.YEAR, curYear);
        	cd.set(Calendar.MONTH, curMonth);
        	cd.set(Calendar.DAY_OF_MONTH, curDay);
        	cd.set(Calendar.HOUR_OF_DAY, 0);
        	cd.set(Calendar.MILLISECOND, 0);
        	
        	mPerfData.setFetchUserArray("");
        	mPedoUserArray = new JSONArray();
        }
    	
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:00:00", getResources().getConfiguration().locale);       
       	String startDate = formatter.format(cd.getTime());
       
        JSONObject getPedoFetchObj = new JSONObject();  
        
        
        /**
         * json={"startTime":"2014-07-18 22:50:27","groupName":[{"groupName":"OPEN_GROUP_COMMON"},
         * {"groupName":"������"},{"groupName":"������"},{"groupName":"E1"},
         * {"groupName":"C1"},{"groupName":"÷������"}]}
         */
        try {
            JSONArray nameArray = new JSONArray();
            int groupCount = mGroupArray.length();
    		for(int i=0; i<groupCount; i++){
    			JSONObject groupEntry = mGroupArray.getJSONObject(i);
    			String groupName = groupEntry.getString("groupName");
    			
    			JSONObject groupNameObj = new JSONObject();
    			groupNameObj.put("groupName", groupName);
    			nameArray.put(groupNameObj);
    		}
    		
            int famousGroupCount = mFamousGroupArray.length();
    		for(int i=0; i<famousGroupCount; i++){
    			JSONObject groupEntry = mFamousGroupArray.getJSONObject(i);
    			String groupName = groupEntry.getString("groupName");
    			
    			JSONObject groupNameObj = new JSONObject();
    			groupNameObj.put("groupName", groupName);
    			nameArray.put(groupNameObj);
    		}
    		
    		getPedoFetchObj.put("groupName", nameArray);
        	getPedoFetchObj.put("startTime", startDate);
        	
        	
		} catch (JSONException e) {
			System.out.println("MyGroupFragment: put groupName failed.");
		}
        String getPedoFetchStr = "json=" + getPedoFetchObj.toString();
        
        //System.out.println(getPedoFetchStr);
        
    	HttpConnection conn = new HttpConnection();
    	conn.post("/group/pedofetch", getPedoFetchStr, GetPedoFetchCallbackListener);
    }    
	
	private void SetActivityGroup(JSONObject obj){
		try{
			int groupCount = Integer.parseInt(obj.getString("groupCount"));
 
			if(groupCount > 0){
				mGroupArray = new JSONArray();
				mFamousGroupArray = new JSONArray();
				
				JSONArray groupArray = obj.getJSONArray("groups");
				for(int i=0; i<groupArray.length(); i++){
					JSONObject groupEntry = groupArray.getJSONObject(i);
					String groupName = groupEntry.getString("groupName");

					String target = "������";
					if(groupEntry.has("dailyTarget")){
						target = groupEntry.getString("dailyTarget");
					}
					String ownerId = groupEntry.getString("owner");
					String ownerIconUrl = "";
					
					ArrayList<JSONObject> userList = new ArrayList<JSONObject>();
					JSONArray userArray = groupEntry.getJSONArray("users");
					int userCount = userArray.length();
					for(int j=0; j<userCount; j++){
						JSONObject userEntry = userArray.getJSONObject(j);
						
						String userId = userEntry.getString("userId");
						if(userId.equals(ownerId)){
							if(userEntry.has("photoUrl")){
								ownerIconUrl = userEntry.getString("photoUrl");
								if(ownerIconUrl.toLowerCase().startsWith("http://localhost")){
								    ownerIconUrl = "";
								}
							}else{
								ownerIconUrl = "";
							}
						}
						userEntry.put("steps", "0");
						userList.add(userEntry);
					}
					mPerfData.SaveGroupUsersInfo(groupName, userList.toString());
					
					JSONObject groupNameObj = new JSONObject();
					groupNameObj.put("groupName", groupName);
					groupNameObj.put("dailyTarget", target);
					groupNameObj.put("photoUrl", ownerIconUrl);
					groupNameObj.put("userNumber", userCount);
					
					String preStr = "";
					if(groupName.length()>8){
						preStr = groupName.substring(0, 8);
					}
					
					if(preStr.equals("FAMOUSG_")){
						mFamousGroupArray.put(groupNameObj);
					}else{
						mGroupArray.put(groupNameObj);
					}
					
				}
				
				if(! CheckUserDefaultGroupState()){
				    // if no default group joining happened, get group pedo info. or else wait for joinDefaultgroupcallback.
					ExecuteGetGroupPedo(false);
				}
			}
		}catch(Exception e){
			System.out.println("SetActivityGroup: " + e.toString());
    		return;
    	};
    }
	
	private JSONArray SetUserSequence(JSONArray groupArray, JSONObject obj){
		
		JSONArray returnArray = groupArray;
		
		if(obj != null){
			try{
				int groupDataCount = Integer.parseInt(obj.getString("groupCount"));
				
				if(groupDataCount > 0){
					JSONArray groupDataArray = obj.getJSONArray("groupsData");
					JSONArray newGroupArray = new JSONArray();
					
					int dataCount = groupDataArray.length();
					int groupCount = groupArray.length();
					for(int k=0; k<groupCount; k++){
						JSONObject groupEntry = groupArray.getJSONObject(k);
						String groupName = groupEntry.getString("groupName");
						
						String userListStr=mPerfData.LoadGroupUsersInfo(groupName);
						JSONArray userArray = new JSONArray(userListStr);
						int userCount = userArray.length();
						
						//find corresponding data in groupsData.
						JSONObject selectedEntry = null;
						for(int i=0; i<dataCount; i++){
							JSONObject groupDataEntry=groupDataArray.getJSONObject(i);
							String groupDataName = groupDataEntry.getString("groupName");
							if(groupDataName.equals(groupName)){
								selectedEntry = groupDataEntry;
								break;
							}
						}
						
						ArrayList<JSONObject> userList = new ArrayList<JSONObject>();
						
						if(selectedEntry != null){
							JSONArray pedoArray = selectedEntry.getJSONArray("pedoData");
							int pedoCount = pedoArray.length();

							for(int m=0; m<userCount; m++){
								JSONObject userEntry = userArray.getJSONObject(m);
								String userId = userEntry.getString("userId");

								String steps = "0";
								if(userId.equals(mPerfData.getUserID())){
									steps = "" + mSteps;
								}else{
									for(int j=0; j<pedoCount; j++){
										JSONObject pedoEntry = pedoArray.getJSONObject(j);
										String pedoUserId = pedoEntry.getString("userId");
										String pedoUserSteps = "0";
										if(pedoEntry.has("steps")){
											pedoUserSteps = pedoEntry.getString("steps");
										}
										
										if(userId.equals(pedoUserId)){
											steps = pedoUserSteps;
											break;
										}
									}
								}								
								
								userEntry.put("steps", steps);
								userList.add(userEntry);
							}
						}else{
							// pedo data not received for this group and set them all to "0"
							for(int m=0; m<userCount; m++){
								JSONObject userEntry = userArray.getJSONObject(m);
								String userId = userEntry.getString("userId");
								if(userId.equals(mPerfData.getUserID())){
									userEntry.put("steps", "" + mSteps);
								}else{
									userEntry.put("steps", "0");
								}
								userList.add(userEntry);
							}							
						}
						
						//sort user pedo data by steps.
						Comparator pedoComp = new PedoDataSortComparator();
						Collections.sort(userList, pedoComp);
						
						String newUserArrayStr = userList.toString();
						mPerfData.SaveGroupUsersInfo(groupName, newUserArrayStr);
						if(mSelectedGroupName.equals(groupName)){
							JSONArray newUserArray = new JSONArray(newUserArrayStr);
							UpdateUserListView(newUserArray);
						}

				        // the first one is champion.
			        	JSONObject userEntry = userList.get(0);
						String champUserName = userEntry.getString("userName");
						String champSteps = userEntry.getString("steps");
						if(champSteps.equals("0")){
							groupEntry.put("champion", "���޳ɼ�");
						}else{
							groupEntry.put("champion", "�ھ�: " + champUserName);
						}

						// find my own sequence in the user list.
						int mySeq = 9999;
						String myUserId = mPerfData.getUserID();
				        JSONObject myEntry = null;
			        	for(int l=0; l<userCount;l++){
			        		userEntry = userList.get(l);
							String userId = userEntry.getString("userId");
							if(userId.equals(myUserId)){
								myEntry = userEntry;
								mySeq = l+1;
								break;
							}
						}
				        
						if(myEntry != null){
							String mySteps = myEntry.getString("steps");
							if(mySteps.equals("0")){
								groupEntry.put("mySequence", "���޳ɼ�");
							}else{
								groupEntry.put("mySequence", "��������" + (mySeq));
							}
						}else{
							groupEntry.put("mySequence", "���޳ɼ�");
						}
						newGroupArray.put(groupEntry);
					}
					
					//update group array info.
					returnArray = newGroupArray;
					//mPerfData.setGroupArray(newGroupArray.toString());
					//mPerfData.SaveGroupArrayInfo();
					
					//UpdateMyGroupListView();
					//ExecutePedoFetch(mGroupArray);
				}

			}catch(Exception e){
				System.out.println("SetUserSequence: " + e.toString());
	    	};
		}
		
		return returnArray;
	}
	
    private void SetUserPedoRecords(JSONObject obj){
    	if(obj != null){
    		try{

    			JSONArray pedoRecArray = obj.getJSONArray("pedoRecords");
				int recordCount = pedoRecArray.length();
    			
				for(int i=0; i<recordCount; i++){
					JSONObject pedoEntry = pedoRecArray.getJSONObject(i);
					String pedoUserId = pedoEntry.getString("userId");
					String pedoUserName = pedoEntry.getString("userName");
					String pedoDateStr = pedoEntry.getString("date");
					String pedoStepsStr = pedoEntry.getString("steps");
					
					JSONObject newRecEntry = new JSONObject();
					newRecEntry.put("userId", pedoUserId);
					newRecEntry.put("userName", pedoUserName);
					newRecEntry.put("date", pedoDateStr);
					newRecEntry.put("steps", pedoStepsStr);
					
					mPedoUserArray.put(newRecEntry);
					
				}
				//System.out.println("SetUserPedoRecords: " + userArray.toString());
				mPerfData.setFetchUserArray(mPedoUserArray.toString());
				
			}catch(Exception e){
				System.out.println("SetUserPedoRecords: " + e.toString());
	    	};
    	}
    	
	    UpdateHourStepsChart();
    }
    
    public void UpdateHourStepsChart(){
		GroupDetailFragment groupDetailFragment = (GroupDetailFragment) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_GROUPDETAIL);
		if(groupDetailFragment != null && mPedoUserArray != null)
		{
			groupDetailFragment.UpdateHourStepsChart(mPedoUserArray);
		}		
    }

	public void UpdateMyGroupListView(GroupListFragment context, JSONArray groupArray){
		if (context != null)
		{
			context.SetGroupListView(groupArray);
		}		
	}
	
	
	public void UpdateUserListView(JSONArray userArray){
		GroupDetailFragment groupDetailFragment = (GroupDetailFragment) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_GROUPDETAIL);
		if(groupDetailFragment != null)
		{
			groupDetailFragment.UpdateUserArray(userArray);
			groupDetailFragment.SetUserListView();
		}		
	}
	/**=====================  GroupInfo & UserInfo refresh Functions End ========================**/

    /**===============================  GroupDetail Functions Start =============================**/

	@Override
	public void OnUserListFragmentCreated() {
		GroupDetailFragment groupDetailFragment = (GroupDetailFragment) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_GROUPDETAIL);
		if(groupDetailFragment != null)
		{
			groupDetailFragment.SetListViewForRefreshView();
			groupDetailFragment.SetUserListView();
		}
	}
    	
	private CallbackListener quitGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						Toast.makeText(MainActivity.this, "�˳���ɹ�", Toast.LENGTH_SHORT).show();
						System.out.println("quit group success");
						mNeedUpdateGroupInfo = true;
						
						mPerfData.SaveGroupUsersInfo(mSelectedGroupName, "");
						mSelectedGroupName = "";
						mPerfData.setSelectedGroupName(mSelectedGroupName);
						//mPerfData.SaveSelectedGroupInfo();
						
						ReturnToPrevFragment();
			        	//finish();
					}else{
						Toast.makeText(MainActivity.this, "�˳��ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("quit group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("quitGroupCallback: " + e.toString());
				}
			}
			//progressDialog.dismiss();
		}
	};

    private void ExecuteQuitGroup() {
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_GROUPDETAIL);
    	
    	if(mainfragment != null){
    		mSelectedGroupName = mPerfData.getSelectedGroupName();
    		
	        JSONObject quitGroupObj = new JSONObject();  
	        /**
	         * json={"userId":"539322f172d6355d63ab4f3d","groupName":"������"}
	         */
	        try {
	        	quitGroupObj.put("userId", mPerfData.getUserID());
	        	quitGroupObj.put("groupName", mSelectedGroupName);
	        	
			} catch (JSONException e) {
				System.out.println("ExecuteQuitGroup " + e.toString());
			}
	        String quitGroupStr = "json=" + quitGroupObj.toString();
	        
	        //System.out.println(quitGroupStr);
	        
	    	HttpConnection conn = new HttpConnection();
	    	conn.post("/group/removeuser", quitGroupStr, quitGroupCallbackListener);
	    }
    }
    
    DialogInterface.OnClickListener quitGroupListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
            	ExecuteQuitGroup();
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
                break;  
            default:  
                break;  
            }  
        }  
    }; 
    /**===============================  GroupDetail Functions End =============================**/

    /**===============================  JoinGroup Functions Start =============================**/

    private void SwitchJoinGroupState(){
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_JOINGROUP);
    	
    	if(mainfragment != null){
	    	//ActionBar actionBar = getSupportActionBar();
	    	Button joinButton = (Button)findViewById(R.id.joinGroupButton);
	        LinearLayout targetLayout = (LinearLayout)findViewById(R.id.actTargetLinearLayout);
	    	
	    	if(joinButton.getText().equals("�μ�")){
	    		mActionBarTitle.setText(BARTITLE_CREATEGROUP);
	    		//actionBar.setTitle(BARTITLE_CREATEGROUP);
	    		joinButton.setText("����");
		        targetLayout.setVisibility(View.VISIBLE);
	    		
	    	}else{
	    		mActionBarTitle.setText(BARTITLE_JOINGROUP);
	    		//actionBar.setTitle(BARTITLE_JOINGROUP);
	    		joinButton.setText("�μ�");
		        targetLayout.setVisibility(View.GONE);
	    	}
    	}
    }
    
	private CallbackListener joinGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					//System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						Toast.makeText(MainActivity.this, "�����ɹ�", Toast.LENGTH_SHORT).show();
						mNeedUpdateGroupInfo = true;
						sendUpdateReportJSONCmd();
						System.out.println("join group success");
					}else{
						Toast.makeText(MainActivity.this, "����ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("join group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("JoinGroupFragment: " + e.toString());				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteJoinGroup() {
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_JOINGROUP);
    	
    	if(mainfragment != null){

	        JSONObject joinGroupObj = new JSONObject();  
	
	        EditText nameEditText = (EditText)findViewById(R.id.groupNameEditText);
	        String groupName = nameEditText.getText().toString();
	        
	        EditText passwdEditText = (EditText)findViewById(R.id.passwordEditText);
	        String password = passwdEditText.getText().toString();
	        
	        if(! groupName.equals("")){
		        /**
		         * json={"userId":"539322f172d6355d63ab4f3d","groupName":"������","password":"12345"}
		         */
		        try {
		        	joinGroupObj.put("userId", mPerfData.getUserID());
		        	joinGroupObj.put("groupName", groupName);
		        	if(!password.equals("")){
		        		joinGroupObj.put("password", password);
		        	}
				} catch (JSONException e) {
					System.out.println("JoinGroupFragment: " + e.toString());
				}
		        String joinGroupStr = "json=" + joinGroupObj.toString();
		        
		        //System.out.println(joinGroupStr);
		        
		    	HttpConnection conn = new HttpConnection();
		    	conn.post("/group/joingroup", joinGroupStr, joinGroupCallbackListener);
	        }
    	}
    }

	private CallbackListener createGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				Toast.makeText(MainActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						Toast.makeText(MainActivity.this, "������ɹ�", Toast.LENGTH_SHORT).show();
						mNeedUpdateGroupInfo = true;
						System.out.println("create group success");
					}else{
						Toast.makeText(MainActivity.this, "�����ʧ��", Toast.LENGTH_SHORT).show();
						System.out.println("create group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("JoinGroupFragment: " + e.toString());
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecuteCreateGroup() {
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_JOINGROUP);
    	
    	if(mainfragment != null){

	        JSONObject createGroupObj = new JSONObject();  
	
	        EditText nameEditText = (EditText)findViewById(R.id.groupNameEditText);
	        String groupName = nameEditText.getText().toString();
	        
	        EditText passwdEditText = (EditText)findViewById(R.id.passwordEditText);
	        String password = passwdEditText.getText().toString();
	        
	        TextView targetEditText = (TextView)findViewById(R.id.groupTargetTV);
	        String target = targetEditText.getText().toString();
	
	        if(! groupName.equals("")){
		        /**
		         * json={"groupName":"������","ownerId":"5392dd5e72d69e4d30d22fae",
		         * "password":"12345"��"dailyTarget":"10000"}
		         */
		        try {
		        	createGroupObj.put("ownerId", mPerfData.getUserID());
		        	createGroupObj.put("groupName", groupName);
		        	if(!password.equals("")){
		        		createGroupObj.put("password", password);
		        	}
		       		createGroupObj.put("dailyTarget", target);
		        	
				} catch (JSONException e) {
					System.out.println("JoinGroupFragment: " + e.toString());
				}
		        String createGroupStr = "json=" + createGroupObj.toString();
		        
		        //System.out.println(createGroupStr);
		        
		    	HttpConnection conn = new HttpConnection();
		    	conn.post("/group/create", createGroupStr, createGroupCallbackListener);
	        }
    	}
    }
    
	private CallbackListener joinDefaultGroupCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					//System.out.println(v);
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						System.out.println("join Default group success");
						mDefaultGroupJoined = true;
					}else{
						System.out.println("join Default group failed");
					}
					
				} catch (JSONException e) {
					System.out.println("JoinGroupFragment: " + e.toString());				}
			}
			//progressDialog.dismiss();
			
			// re-get group info after default group joined. 
			ExecuteGetGroupInfo(mPerfData.getUserID());
		}
	};

    public void ExecuteJoinDefaultGroup(String defaultGroupName) {
    	JSONObject joinGroupObj = new JSONObject();  
        /**
         * json={"userId":"539322f172d6355d63ab4f3d","groupName":"������","password":"12345"}
         */
        try {
        	joinGroupObj.put("userId", mPerfData.getUserID());
        	joinGroupObj.put("groupName", defaultGroupName);
       		joinGroupObj.put("password", "bingbing123456");
		} catch (JSONException e) {
			System.out.println("JoinGroupFragment: " + e.toString());
		}
        String joinGroupStr = "json=" + joinGroupObj.toString();
        
        //System.out.println(joinGroupStr);
        
    	HttpConnection conn = new HttpConnection();
    	conn.post("/group/joingroup", joinGroupStr, joinDefaultGroupCallbackListener);
    }
    
    private boolean CheckUserDefaultGroupState(){
    	
    	boolean joined = false;
    	
		try {
			String defaultGroupName = "����ѵ����Ӫ";
        	if( ! mDefaultGroupJoined && mGroupArray != null){
		    	int groupCount = mGroupArray.length();
		    	for(int i=0; i<groupCount; i++){
		    		JSONObject groupEntry = mGroupArray.getJSONObject(i);
		    		String groupName = groupEntry.getString("groupName");
		    		
	        		if( groupName.equals("����ѵ��Ӫ")   || 
	        		    groupName.equals("����ѵ����Ӫ")  ||
	        		    groupName.equals("����ѵ����Ӫ")){
	        			mDefaultGroupJoined = true;
	        		}
	        	}
	    	}
        	
        	if(! mDefaultGroupJoined){
        		ExecuteJoinDefaultGroup(defaultGroupName);
        		joined = true;
        	}
		} catch (JSONException e) {
			System.out.println("CheckUserDefaultGroupState: " + e.toString());
		}
		
		return joined;
    }
    /**===============================  JoinGroup Functions End =============================**/
    
    /**===============================  Training Functions End =============================**/
    DialogInterface.OnClickListener restartPlanListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
            	QuitTrainingPlan();
                break;  
            default:  
                break;  
            }  
        }  
    }; 
    
    private void QuitTrainingPlan(){
		try {
			int planCount = mTrainArray.length();
			JSONArray newTrainArray = new JSONArray();
			for(int i=0; i<planCount; i++){
				JSONObject planEntry = mTrainArray.getJSONObject(i);
				String planName = planEntry.getString("planName");
				if(!planName.equals(mPerfData.getCurrentPlans())){
					newTrainArray.put(planEntry);
				}
			}
			
			mTrainArray = newTrainArray;
			mPerfData.setTrainingPlans(mTrainArray.toString());
    	
		} catch (JSONException e) {
			System.out.println("QuitTrainingPlan: " + e.toString());
		}
		
		ReturnToPrevFragment();
    }
    
    public int GetPlanStatus(String selectedPlanName){
    	int status = TrainingFragment.PLAN_NOTSTARTED;
    	if(mTrainArray != null){
			try {
				JSONObject selectedPlan = null;
	    		int planCount = mTrainArray.length();
	    		for(int i=0; i<planCount;i++){
	    			JSONObject planEntry = mTrainArray.getJSONObject(i);
	    			String planName;
	
						planName = planEntry.getString("planName");
	    			if(planName.equals(selectedPlanName)){
	    				selectedPlan = planEntry;
	    				break;
	    			}
	    		}
	    		
	    		if(selectedPlan != null){
	    			status = selectedPlan.getInt("planStatus");
	    			
	    			long startDate = selectedPlan.getLong("startDate");

	    			Calendar cd = Calendar.getInstance();
	    			long timdiffseconds = (cd.getTimeInMillis() - startDate) / 1000;
	    			long day28 = (28 * 24 * 60 * 60);
	    			//System.out.println("timediff: " + timdiffseconds + " 28day: " + day28);
	    			
	    			if(timdiffseconds >= day28){
	    				status = TrainingFragment.PLAN_COMPLETED;
	    				selectedPlan.put("planStatus", TrainingFragment.PLAN_COMPLETED);

	    				mPerfData.setTrainingPlans(mTrainArray.toString());
	    			}
	    		}
	    			
			} catch (JSONException e) {
				System.out.println("GetPlanStatus: " + e.toString());
			}
    	}
    	
    	//System.out.println(selectedPlanName + " : " + status);
    	return status;
    }
    
    public void TransToTrainingListsFragment(){
    	Fragment mainfragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_TRAININGLIST);
    	if(mainfragment == null){
        	Fragment currentfragment=getSupportFragmentManager().findFragmentById(R.id.container);
        	PushCurrentFragment(currentfragment.getTag());
        	
        	mainfragment = new TrainingListsFragment();
        	FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        	t.add(R.id.container, mainfragment, TAG_FRAGMENT_TRAININGLIST);
            t.remove(currentfragment);
            t.commit();
    	}
    }
    
    /**===============================  Training Functions End =============================**/
    
    
    public static String GetRealGroupName(String groupName){
    	
		String preStr = "";
		String realGroupName;

		int nameStrLen = groupName.length();
		if(nameStrLen>8){
			preStr = groupName.substring(0, 8);
		}
		
		if(preStr.equals("FAMOUSG_")){
			realGroupName = groupName.substring(8, nameStrLen);
		}else{
			realGroupName = groupName;
		}
		
		return realGroupName;
    }

    
	public static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you may tune some of them,
		// or you can create default configuration by
		//  ImageLoaderConfiguration.createDefault(this);
		// method.
		
    	String packageName = context.getPackageName();
        String cacheDirStr=android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
        cacheDirStr += "/" + packageName +"/imageCache";
        File cacheDir = new File(cacheDirStr);
        if(!cacheDir.exists()){
        	cacheDir.mkdirs();
        }
        
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
				.threadPriority(Thread.NORM_PRIORITY - 1)
				.denyCacheImageMultipleSizesInMemory()
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.diskCacheSize(100 * 1024 * 1024) // 100 Mb
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}

    private void showPedoShare() {

		Fragment fragment=getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_PEDO);
		if(fragment != null){
			
		    RelativeLayout shareLayout = (RelativeLayout) MainActivity.this.findViewById( R.id.pedo_sharelayout);
		    TextView progressTV = (TextView) MainActivity.this.findViewById(R.id.cur_progress);
		    String shareString = mPerfData.getUserName() + "�������" + progressTV.getText() + ". ���http://www.candone.cn/download.html ����[����]APP.";
		    
			OnekeyShare oks = new OnekeyShare();
	        //�ر�sso��Ȩ
	        oks.disableSSOWhenAuthorize();

	        // ����ʱNotification��ͼ�������
	        oks.setNotification(R.drawable.app_icon, getString(R.string.app_name));
	        // title���⣬ӡ��ʼǡ����䡢��Ϣ��΢�š���������QQ�ռ�ʹ��
	        oks.setTitle(getString(R.string.share));
	        // titleUrl�Ǳ�����������ӣ�������������QQ�ռ�ʹ��
	        oks.setTitleUrl("http://www.candone.cn");
	        // text�Ƿ����ı�������ƽ̨����Ҫ����ֶ�
	        oks.setText(shareString);
	        // imagePath��ͼƬ�ı���·����Linked-In�����ƽ̨��֧�ִ˲���
	        //oks.setImagePath("/sdcard/test.jpg");
	        oks.setViewToShare(shareLayout.getRootView());
	        // url����΢�ţ��������Ѻ�����Ȧ����ʹ��
	        oks.setUrl("http://www.candone.cn");
	        // comment���Ҷ��������������ۣ�������������QQ�ռ�ʹ��
	        //oks.setComment("���ǲ��������ı�");
	        // site�Ƿ��������ݵ���վ���ƣ�����QQ�ռ�ʹ��
	        oks.setSite(getString(R.string.app_name));
	        // siteUrl�Ƿ��������ݵ���վ��ַ������QQ�ռ�ʹ��
	        oks.setSiteUrl("http://www.candone.cn");
	
	        // ��������GUI
	        oks.show(this);
	    }
   }

    public void showRecordShare() {

		RecordFragment recordfragment= (RecordFragment)getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_RECORD);
		if(recordfragment != null){
			if(recordfragment.mWalkRecordCount >0){
				recordfragment.recAMap.getMapScreenShot(this);
			}
			else{
				Toast.makeText(MainActivity.this, "����û�гɼ����Է���", Toast.LENGTH_SHORT).show();
			}
	    }
    }

	@Override
	public void onMapScreenShot(Bitmap bitmap) {
		
		RecordFragment recordfragment= (RecordFragment)getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT_RECORD);
		if(recordfragment != null){
			
	        try { 
	        	String packageName = getPackageName();
	        	String screenshotPath;
	            if (Environment.getExternalStorageState().equals(  
	                    Environment.MEDIA_MOUNTED)) {
	            	screenshotPath = Environment.getExternalStorageDirectory()  
	                        .getAbsolutePath() + "/" + packageName + "/screenshot";  
	            } else {
	            	screenshotPath = getFilesDir().getAbsolutePath()  
	                        + "/" + packageName + "/screenshot";  
	            }
		        File file = new File(screenshotPath);  
				if(!file.exists()){
					file.mkdirs();
				}
	        	
	            FileOutputStream fos = new FileOutputStream(screenshotPath + "/screenshot.png");
	            boolean b = bitmap.compress(CompressFormat.PNG, 100, fos);
	            try {
	                fos.flush();
	                fos.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	            if (b){
	            	
	    		    String shareString =  "��������˶�" + recordfragment.mWalkrecordDistanceTV.getText() +
	    		    		recordfragment.mWalkrecordUnitTV.getText() + ", ��������" + 
	    		    		recordfragment.mWalkrecordCaloreisTV.getText() + "��, ��ʱ" +
	    		    		recordfragment.mWalkrecordDurationTV.getText() +
	    		    		". ���http://www.candone.cn/download.html ����[����]APP.";
	    		    
	    			OnekeyShare oks = new OnekeyShare();
	    	        //�ر�sso��Ȩ
	    	        oks.disableSSOWhenAuthorize();
	    	
	    	        // ����ʱNotification��ͼ�������
	    	        oks.setNotification(R.drawable.app_icon, getString(R.string.app_name));
	    	        // title���⣬ӡ��ʼǡ����䡢��Ϣ��΢�š���������QQ�ռ�ʹ��
	    	        oks.setTitle(getString(R.string.share));
	    	        // titleUrl�Ǳ�����������ӣ�������������QQ�ռ�ʹ��
	    	        oks.setTitleUrl("http://www.candone.cn");
	    	        // text�Ƿ����ı�������ƽ̨����Ҫ����ֶ�
	    	        oks.setText(shareString);
	    	        // imagePath��ͼƬ�ı���·����Linked-In�����ƽ̨��֧�ִ˲���
	    	        oks.setImagePath(screenshotPath + "/screenshot.png");
	    	        //oks.setViewToShare(shareLayout.getRootView());
	    	        // url����΢�ţ��������Ѻ�����Ȧ����ʹ��
	    	        oks.setUrl("http://www.candone.cn");
	    	        // comment���Ҷ��������������ۣ�������������QQ�ռ�ʹ��
	    	        //oks.setComment("���ǲ��������ı�");
	    	        // site�Ƿ��������ݵ���վ���ƣ�����QQ�ռ�ʹ��
	    	        oks.setSite(getString(R.string.app_name));
	    	        // siteUrl�Ƿ��������ݵ���վ��ַ������QQ�ռ�ʹ��
	    	        oks.setSiteUrl("http://www.candone.cn");
	    	
	    	        // ��������GUI
	    	        oks.show(this);	            	
	            }
	            else {
	            	Toast.makeText(MainActivity.this, "����ʧ��", Toast.LENGTH_SHORT).show();
	            }
	        } catch (FileNotFoundException e) {
	            System.out.println("AMapScreenShot failed: " + e.toString());
	        }			
	    }
	}
	
    
    // **********************Power manage****************************
	private WakeLock wakeLock = null;

	public void acquireWakeLock() {
		if (wakeLock == null) {
			System.out.println("Get Power Lock");
			PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
			wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, this
					.getClass().getCanonicalName());
			wakeLock.acquire();
		}

	}

	public void releaseWakeLock() {
		if (wakeLock != null && wakeLock.isHeld()) {
			System.out.println("Release Power LOCK");
			wakeLock.release();
			wakeLock = null;
		}

	}

	// **********************offline aMap directory****************************
	private String getSdCacheDir(Context context) {
		String returnStr = "";
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			String defaultDir1 = Environment.getExternalStorageDirectory()  
                    .getAbsolutePath() + "/Android/data/com.autonavi.minimap/files/autonavi";
			String defaultDir2 = Environment.getExternalStorageDirectory()  
                    .getAbsolutePath() + "/autonavi";
			String defaultDir3 = Environment.getExternalStorageDirectory()  
                    .getAbsolutePath() + "/amap";
			
			String packageName = context.getPackageName();
			String offlineMapPath = Environment.getExternalStorageDirectory()  
                    .getAbsolutePath() + "/" + packageName + "/offlineMap";
			
			File file1 = new File(defaultDir1);
			File file2 = new File(defaultDir2);
			File file3 = new File(defaultDir3);
	        File file = new File(offlineMapPath);  
			if(file1.exists()){
				returnStr = defaultDir1 + "/";
			}else if(file2.exists()){
				returnStr =  defaultDir2 + "/";
			}else if(file3.exists()){
				returnStr =  defaultDir3 + "/";
			}else if(file.exists()) {  
	            returnStr =  offlineMapPath + "/";
	        }else{
	            file.mkdirs();
	        	returnStr =  offlineMapPath + "/";
	        }
		} 

		System.out.println("Offine Map Dir: " + returnStr);
		return returnStr;
	}

}
