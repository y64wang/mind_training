package cn.candone.appstepfun;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.umeng.analytics.MobclickAgent;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.candone.appstepfun.R;
import cn.candone.appstepfun.graphview.SimpleBarGraphView;
import cn.candone.appstepfun.graphview.GraphView;
import cn.candone.appstepfun.graphview.GraphView.GraphViewData;
import cn.candone.appstepfun.graphview.GraphViewDataInterface;
import cn.candone.appstepfun.graphview.GraphViewSeries;
import cn.candone.appstepfun.graphview.GraphViewSeries.GraphViewSeriesStyle;
import cn.candone.appstepfun.graphview.GraphViewStyle.GridStyle;
import cn.candone.appstepfun.graphview.ValueDependentColor;
import cn.candone.appstepfun.helper.StepFunDBHelper;
import cn.candone.appstepfun.widget.RoundRndProgressBar;

public class PedoFragment  extends Fragment {
	private final String mPageName = "PedoFragment";

    private LinearLayout mChartLayout;

    private boolean mWaitDouble = true;
    private static final int DOUBLE_CLICK_TIME = 350; //���ε�����ʱ����

    public PedoFragment() {
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	//System.out.println("PedoFragment onCreateView called");
      	
    	View rootView = inflater.inflate(R.layout.main_pedo_fragment, container, false);

    	MainActivity mainAct = (MainActivity)getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_SHARE);
        	//mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_PEDO);
        }
        
		TextView curTextView = (TextView) rootView.findViewById(R.id.cur_progress);
		curTextView.setText(mainAct.mSteps + "��");
        
        RoundRndProgressBar progressBar = (RoundRndProgressBar) rootView.findViewById(R.id.progressBar_pedo);
        progressBar.setStartColor(MainActivity.COLOR_SKYBLUE);
        progressBar.setEndColor(MainActivity.COLOR_BOTTOMBLUE);
        progressBar.setMax(mainAct.mPerfData.getUserTarget());
        progressBar.setProgress(mainAct.mSteps);
        
        
        int calorie = (int)(mainAct.mSteps * 400 / 10000);
        int chicken_num  = (int)(calorie / 200);
        int rice_num = (int)((calorie%200)/50);
        int coffee_num = (int)((calorie%50)/20);
        
        TextView calText = (TextView) rootView.findViewById(R.id.calorie);
        calText.setText("ȼ��"+calorie+"��");
        
        TextView chickenNumTV = (TextView) rootView.findViewById(R.id.chicken_number);
        chickenNumTV.setText("x" + chicken_num);
        
        TextView riceNumTV = (TextView) rootView.findViewById(R.id.rice_number);
        riceNumTV.setText("x" + rice_num);
        
        TextView coffeeNumTV = (TextView) rootView.findViewById(R.id.coffee_number);
        coffeeNumTV.setText("x" + coffee_num);
        
    	Calendar cd=Calendar.getInstance();
    	Date curDate = cd.getTime();

    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", getResources().getConfiguration().locale);       
       	String date = formatter.format(curDate);
    	
    	TextView dateView = (TextView)rootView.findViewById(R.id.cur_date);
    	dateView.setText(date);
 
    	TextView targetView = (TextView)rootView.findViewById(R.id.target);
    	targetView.setText("Ŀ��" + mainAct.mPerfData.getUserTarget());

    	mChartLayout = (LinearLayout) rootView.findViewById(R.id.mypedo_chart);

    	rootView.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
		         if ( mWaitDouble == true ){
		        	 mWaitDouble = false;
		        	 Thread thread = new Thread() {
		        		 @Override
		        		 public void run() {
		        			 try {
		        				 sleep(DOUBLE_CLICK_TIME);
		        				 if ( mWaitDouble == false ) {
		        					 mWaitDouble = true;
		        					 onSingleClick();
		        				 }
		        			 } catch (InterruptedException e) {
		        				 e.printStackTrace();
		        			 }
		        		 }
		             };
		             thread.start();
		         }else{
		        	 mWaitDouble = true;
		             onDoubleClick();
		         }
		     }

		    private void onSingleClick(){
		    }
		    
		    private void onDoubleClick(){
		    	TransToGroupDetailActivity();
		    }
    	});

        return rootView;
    }

	private void TransToGroupDetailActivity(){
		
		MainActivity mainAct = (MainActivity)getActivity();
		
    	Fragment mainfragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_PEDOHISTORY);
    	if(mainfragment == null){
        	Fragment currentfragment=mainAct.getSupportFragmentManager().findFragmentById(R.id.container);
        	mainAct.PushCurrentFragment(currentfragment.getTag());
        	
        	mainfragment = new PedoHistoryFragment();
        	FragmentTransaction t = mainAct.getSupportFragmentManager().beginTransaction();
        	t.add(R.id.container, mainfragment, MainActivity.TAG_FRAGMENT_PEDOHISTORY);
            t.remove(currentfragment);
            t.commit();
    	}
	}
    
    @Override
    public void onResume(){
    	super.onResume();
		MobclickAgent.onPageStart(mPageName);

		MainActivity mainAct = (MainActivity)getActivity();
        mainAct.sendUpdateStepCmd();    	

        Calendar cd=Calendar.getInstance();
        int curHour = cd.get(Calendar.HOUR_OF_DAY);
        
    	Date curDate = cd.getTime();   	
    	cd.set(Calendar.HOUR_OF_DAY, 0);
    	cd.set(Calendar.MINUTE, 0);
    	cd.set(Calendar.SECOND, 0);
    	cd.set(Calendar.MILLISECOND, 0);
    	
    	Date startDate = cd.getTime();
    	
       	Cursor cur = StepFunDBHelper.select_StepHistory(mainAct.getBaseContext(), mainAct.mPerfData.getUserID(), startDate, curDate);

       	int totalSteps[] = new int[24];
       	try{
	       	while(cur.moveToNext()){
	       		long longDate = cur.getLong(StepFunDBHelper.COL_STEPHISTORY_DATE);
	       		Date dt = new Date(longDate);
	       		int stepsHour = dt.getHours() - 1;
	       		int entrySteps = cur.getInt(StepFunDBHelper.COL_STEPHISTORY_STEPS);
	
	       		//System.out.println("date: " + dt.toLocaleString() + " steps: " + entrySteps);
	       		if(stepsHour < 0){
	       			continue;
	       		}
	       		totalSteps[stepsHour] = entrySteps;
	       	}
       	}finally{
       		cur.close();
       	}
       	
       	int hourSteps[] = new int[24];
       	hourSteps[0] = totalSteps[0];
       	int preHour = 0;
       	for(int i=1; i<curHour; i++){
       		int step = totalSteps[i] - totalSteps[preHour];
       		if(step > 0){
       			hourSteps[i] = step;
       			preHour = i;
       		}else{
       			hourSteps[i] = 0;
       		}
       	}
       	
       	if(curHour == 0){
       		hourSteps[0] = mainAct.mSteps;
       	}else{
       		hourSteps[curHour] = mainAct.mSteps - totalSteps[preHour];
       	}
       	
      	GraphViewData[] graphDataSet = new GraphViewData[24];
      	for(int i=0; i<24; i++){
      		graphDataSet[i] = new GraphViewData(i, hourSteps[i]);
      	}
       	
    	GraphViewSeriesStyle seriesStyle = new GraphViewSeriesStyle();
      	seriesStyle.setValueDependentColor(new ValueDependentColor() {
      	  //@Override
      	  //public int get(GraphViewDataInterface data) {
      	  //  return Color.CYAN;
      	  //}
      		
      	  @Override
    	  public int get(GraphViewDataInterface data, double max) {
    		if(max <= 0 ){ max = 10000;}
    	    // the higher the more green
    	    return Color.rgb((int)((1.0f-data.getY()/max)*255), 255, (int)((data.getY()/max)*255));
    	  }
    	});

       	GraphViewSeries hourStepSeries = new GraphViewSeries("HourSteps", seriesStyle, graphDataSet);

        // graph with dynamically genereated horizontal and vertical labels
        GraphView graphView = new SimpleBarGraphView(
                    getActivity(), // context
                    "" // heading
            );
       ((SimpleBarGraphView) graphView).setDrawValuesOnTop(true);
       ((SimpleBarGraphView) graphView).setValueUnit("��");
       ((SimpleBarGraphView) graphView).setValuesOnTopColor(getResources().getColor(R.color.orange));
       ((SimpleBarGraphView) graphView).setShowVerticalLabels(false);
       ((SimpleBarGraphView) graphView).setManualYAxis(false);

        // custom static labels
        graphView.setHorizontalLabels(new String[] {"0","","2","","4","","6","","8","","10","","12","","14","","16","","18","","20","","22",""});
        graphView.setVerticalLabels(new String[] {""});
        graphView.getGraphViewStyle().setGridStyle(GridStyle.NONE);
        graphView.getGraphViewStyle().setHorizontalLabelsColor(Color.LTGRAY);
        graphView.addSeries(hourStepSeries); // data

        mChartLayout.removeAllViews();
        mChartLayout.addView(graphView);		
    }
    
    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}

}
