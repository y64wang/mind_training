package cn.candone.appstepfun;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.amap.api.maps.AMap;
import com.amap.api.maps.AMap.OnMapLoadedListener;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.amap.api.maps.model.PolylineOptions;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;

import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class RecordFragment extends Fragment{
	private final String mPageName = "RecordFragment";
	
	public AMap recAMap = null;
	public MapView recMapView = null;
	
	private ImageButton mWalkrecordBackBN = null;
	private ImageButton mWalkrecordForwardBN = null;
	private ImageButton mWalkrecordDeleteBN = null;
	
	public TextView mWalkrecordDurationTV = null;
	public TextView mWalkrecordDistanceTV = null;
	public TextView mWalkrecordUnitTV = null;
	public TextView mWalkrecordCaloreisTV = null;
	public TextView mWalkrecordDateTV = null;
	public TextView mWalkrecordTimeTV = null;
	public TextView mWalkrecordSpeedTV = null;
	
	public int mWalkRecordCount = 0;
	private int mWalkRecordIndex = 0;
	private String mCurrentWalkDate = "";
	
	public RecordFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.main_record_fragment, container, false);

    	MainActivity mainAct = (MainActivity)getActivity();
    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);

        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_SHARE);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_RECORD);
        }

        recMapView = (MapView) rootView.findViewById(R.id.recordMap_view);
        recMapView.onCreate(savedInstanceState);// �˷���������д
        initMap();
        
        mWalkrecordDurationTV = (TextView) rootView.findViewById(R.id.walkrecord_durationTV);
        mWalkrecordDistanceTV = (TextView) rootView.findViewById(R.id.walkrecord_distanceTV);
        mWalkrecordUnitTV = (TextView) rootView.findViewById(R.id.walkrecord_unitTV);
        mWalkrecordCaloreisTV = (TextView) rootView.findViewById(R.id.walkrecord_caloriesTV);
        mWalkrecordDateTV = (TextView) rootView.findViewById(R.id.walkrecord_dateTV);
        mWalkrecordTimeTV = (TextView) rootView.findViewById(R.id.walkrecord_timeTV);
        mWalkrecordSpeedTV = (TextView) rootView.findViewById(R.id.walkrecord_speedTV);
        
		Calendar cd = Calendar.getInstance();
		Date date = cd.getTime();
    	
		SimpleDateFormat formatterDate = new SimpleDateFormat("yyyy-MM-dd", getResources().getConfiguration().locale);       
       	String dateStr = formatterDate.format(date);

       	SimpleDateFormat formatterTime = new SimpleDateFormat("HH:mm:ss", getResources().getConfiguration().locale);       
       	String timeStr = formatterTime.format(date);
       	
        mWalkrecordDistanceTV.setText("0.0");
        mWalkrecordUnitTV.setText("��");
		mWalkrecordDurationTV.setText("00:00:00");
		mWalkrecordCaloreisTV.setText("0.0");
		mWalkrecordDateTV.setText(dateStr);
		mWalkrecordTimeTV.setText(timeStr);
		mWalkrecordSpeedTV.setText("0.0");
        
        mWalkrecordBackBN = (ImageButton) rootView.findViewById(R.id.walkrecord_backBN);
        mWalkrecordBackBN.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(mWalkrecordBackBN.isClickable()){
		    	    switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mWalkrecordBackBN.setBackgroundResource(R.drawable.oval_white_orange);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mWalkrecordBackBN.setBackgroundResource(R.drawable.oval_white_alphablue);
	    	            break;
	    	        default:
	    	            break;
		    	    }
				}
	    	    return false;
			}
		});
        
        mWalkrecordBackBN.setOnClickListener(new View.OnClickListener() { 
			@Override 
			public void onClick(View v) {
				if(mWalkRecordIndex > 0){
	    			mWalkRecordIndex --;
	        		try {
	        			MainActivity mainAct = (MainActivity)getActivity();
						JSONObject record = mainAct.mWalkingRecList.getJSONObject(mWalkRecordIndex);
						DisplayWalkingRecord(record);
						
			        	updateButtonState();

	        		} catch (JSONException e) {
						System.out.println("recordFragment: record " + e.toString());
					}
				}
        	} 
		});
        
        mWalkrecordForwardBN = (ImageButton) rootView.findViewById(R.id.walkrecord_forwardBN);
        mWalkrecordForwardBN.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(mWalkrecordForwardBN.isClickable()){
		    	    switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mWalkrecordForwardBN.setBackgroundResource(R.drawable.oval_white_orange);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mWalkrecordForwardBN.setBackgroundResource(R.drawable.oval_white_alphablue);
	    	            break;
	    	        default:
	    	            break;
		    	    }
	    	    }
	    	    return false;
			}
		});

        mWalkrecordForwardBN.setOnClickListener(new View.OnClickListener() { 
			@Override 
			public void onClick(View v) { 
				if(mWalkRecordIndex < (mWalkRecordCount-1)){
	    			mWalkRecordIndex ++;
	        		try {
	        			MainActivity mainAct = (MainActivity)getActivity();
						JSONObject record = mainAct.mWalkingRecList.getJSONObject(mWalkRecordIndex);
						DisplayWalkingRecord(record);
						
			        	updateButtonState();

	        		} catch (JSONException e) {
						System.out.println("recordFragment: record " + e.toString());
					}
				}
			} 
		});
        
        mWalkrecordDeleteBN = (ImageButton) rootView.findViewById(R.id.walkrecord_deleteBN);
        mWalkrecordDeleteBN.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(mWalkrecordDeleteBN.isClickable()){
		    	    switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mWalkrecordDeleteBN.setBackgroundResource(R.drawable.oval_white_orange);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mWalkrecordDeleteBN.setBackgroundResource(R.drawable.oval_white_alphablue);
	    	            break;
	    	        default:
	    	            break;
	    	    }
				}
	    	    return false;
			}
		});

        mWalkrecordDeleteBN.setOnClickListener(new View.OnClickListener() { 
			@Override 
			public void onClick(View v) {
	            AlertDialog isDelete = new AlertDialog.Builder(getActivity()).create();
	            isDelete.setTitle("������ʾ");  
	            isDelete.setMessage("�����ǰ���˶���¼? ");  
	            isDelete.setButton("ȷ��", deleteListener);
	            isDelete.setButton2("ȡ��", deleteListener);
	            isDelete.show();				
			} 
		});

		return rootView;
	}

	
    DialogInterface.OnClickListener deleteListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳�����
            	DeleteCurrentRecord();
                break;  
            case AlertDialog.BUTTON_NEGATIVE:// "ȡ��"�ڶ�����ťȡ���Ի���  
                break; 
            }  
        }  
    };    

	private void DeleteCurrentRecord(){
		MainActivity mainAct = (MainActivity)getActivity();
		try{
			JSONArray newWalkingRecList = new JSONArray();
			for(int i=0; i<mWalkRecordCount; i++){
				JSONObject record = mainAct.mWalkingRecList.getJSONObject(i);
				if(i != mWalkRecordIndex){
					newWalkingRecList.put(record);
				}
			}
			
			if(mWalkRecordIndex == (mWalkRecordCount - 1)){
				mWalkRecordIndex --;
			}
			mWalkRecordCount --;
			mainAct.mWalkingRecList = newWalkingRecList;
			
			mainAct.mPerfData.setWalkingRecList(mainAct.mWalkingRecList.toString());
			mainAct.mPerfData.SaveWalkingRecordList();
			mainAct.mPerfData.SaveWalkingRecord(mCurrentWalkDate, "");
			
			if(mWalkRecordCount > 0){
				//display next record
				JSONObject record = newWalkingRecList.getJSONObject(mWalkRecordIndex);
				DisplayWalkingRecord(record);
				
			}else{
				
				// all record deleted;
				recAMap.clear();
			}

			updateButtonState();
			
		}catch(JSONException e){
			System.out.println("Delete Record" + e.toString());
		}
	}
	
	private void DisplayWalkingRecord(JSONObject record){
		if(record != null){
			try {
				MainActivity mainAct = (MainActivity)getActivity();
				
				mCurrentWalkDate = record.getString("date");
				
				long duration = 0;
				double distance = 0;
				double cal = 0;
				double avgspeed = 0;
				
				if(record.has("duration")){
					duration = record.getLong("duration");
					distance = record.getDouble("distance");
					cal = record.getDouble("calories");
					avgspeed = record.getDouble("speed");
				}
	    		
				String walkRecordStr = mainAct.mPerfData.LoadWalkingRecord(mCurrentWalkDate);
				if(!walkRecordStr.equals("")){
					
					JSONArray walkrecArray = new JSONArray(walkRecordStr);
					int pointCount = walkrecArray.length();
					if(pointCount > 1){
						List<LatLng> pointList = new ArrayList<LatLng>();
						for(int i=0; i<pointCount; i++){
							JSONObject point = walkrecArray.getJSONObject(i);
							int index = point.getInt("ind");
							double lat = point.getDouble("lat");
							double lng = point.getDouble("long");
							
							pointList.add(new LatLng(lat, lng));
						}
						
						recAMap.clear();
						
						LatLng prevPoint = pointList.get(0);
						addStartMarker(prevPoint);

						double minLat = prevPoint.latitude;
						double maxLat = prevPoint.latitude;
						double minLng = prevPoint.longitude;
						double maxLng = prevPoint.longitude;
						

						for(int i=1; i<pointCount; i++){
							
							LatLng curPoint = pointList.get(i);
							recAMap.addPolyline((new PolylineOptions()).add(prevPoint, curPoint)
									.width(25).geodesic(false).color(Color.GREEN));
							if(minLat > curPoint.latitude){
								minLat = curPoint.latitude;
							}
							
							if(minLng > curPoint.longitude){
								minLng = curPoint.longitude;
							}
							
							if(maxLat < curPoint.latitude){
								maxLat = curPoint.latitude;
							}
							
							if(maxLng < curPoint.longitude){
								maxLng = curPoint.longitude;
							}
							prevPoint = curPoint;
						}
						addEndMarker(prevPoint);
		
					    LatLngBounds bounds = new LatLngBounds.Builder()
		            		.include(new LatLng(minLat, minLng)).include(new LatLng(maxLat, maxLng))
		            		.build();

					    recAMap.setOnCameraChangeListener(null);
					    recAMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 
					    		200));

						DecimalFormat dcmFmt1 = new DecimalFormat("0.0");
    					DecimalFormat dcmFmt2 = new DecimalFormat("0.00");
    					
    					if(distance <= 1000){
					        mWalkrecordDistanceTV.setText(dcmFmt1.format(distance));
					        mWalkrecordUnitTV.setText("��");
    					}else{
					        mWalkrecordDistanceTV.setText(dcmFmt2.format(distance/1000));
					        mWalkrecordUnitTV.setText("ǧ��");
    					}
    					
    					String dateStr = mCurrentWalkDate.substring(0, 10);
    					String timeStr = mCurrentWalkDate.substring(11, 19);
    					long elapsedTime = duration/1000;
						mWalkrecordDurationTV.setText(String.format("%02d:%02d:%02d", elapsedTime / 3600, 
			    				(elapsedTime % 3600) / 60, 
			    				(elapsedTime % 60))); 
						mWalkrecordCaloreisTV.setText(dcmFmt1.format(cal));
						mWalkrecordDateTV.setText(dateStr);
						mWalkrecordTimeTV.setText(timeStr);
						mWalkrecordSpeedTV.setText(dcmFmt2.format(avgspeed));
					}
				}
				
			} catch (JSONException e) {
				System.out.println("DisplayWalkingRecord: " + e.toString());
			}
		}
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
		recMapView.onResume();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd(mPageName);
		recMapView.onPause();
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		recMapView.onSaveInstanceState(outState);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		MainActivity mainAct = (MainActivity) getActivity();
		SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		
		recMapView.onDestroy();
	}

	private void initMap() {
		if (recAMap == null) {
			recAMap = recMapView.getMap();
			setUpMap();
		}
	}
	
	private void setUpMap() {
		
		MainActivity mainAct = (MainActivity)getActivity();
		LatLng curLatLng = new LatLng(mainAct.mLatitude, mainAct.mLongitude);
		
		recAMap.setMyLocationRotateAngle(180);
		recAMap.getUiSettings().setMyLocationButtonEnabled(false);// ����Ĭ�϶�λ��ť�Ƿ���ʾ
		recAMap.setMyLocationEnabled(false); 
		recAMap.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.builder()
				.target(curLatLng)
				.zoom(18)
				.tilt(45)
				.build()));
		
		recAMap.setOnMapLoadedListener(new AMap.OnMapLoadedListener() {
			@Override
			public void onMapLoaded() {
				MainActivity mainAct = (MainActivity)getActivity();
		        //load the first walk record
		        if(mainAct.mWalkingRecList != null){
		        	mWalkRecordCount = mainAct.mWalkingRecList.length();

		        	if(mWalkRecordCount == 0){
		        		Toast.makeText(getActivity(), "����û���˶��ɼ�" , Toast.LENGTH_SHORT).show();
		        	}else{
		    			mWalkRecordIndex = mWalkRecordCount - 1;
		        		try {
							JSONObject lastRecord = mainAct.mWalkingRecList.getJSONObject(mWalkRecordIndex);
							DisplayWalkingRecord(lastRecord);
						} catch (JSONException e) {
							System.out.println("recordFragment: lastRecord " + e.toString());
						}
		        	}
		        	updateButtonState();
		        }
			}
			
		});
	}

	private void updateButtonState(){
		if(mWalkRecordCount == 0){
    		mWalkrecordBackBN.setClickable(false);
    		mWalkrecordBackBN.setBackgroundResource(R.drawable.oval_white_alphagray);
    		
    		mWalkrecordForwardBN.setClickable(false);
			mWalkrecordForwardBN.setBackgroundResource(R.drawable.oval_white_alphagray);
			
    		mWalkrecordDeleteBN.setClickable(false);
    		mWalkrecordDeleteBN.setBackgroundResource(R.drawable.oval_white_alphagray);			
		}else{
    		mWalkrecordDeleteBN.setClickable(true);
    		mWalkrecordDeleteBN.setBackgroundResource(R.drawable.oval_white_alphablue);			

    		if(mWalkRecordIndex == (mWalkRecordCount - 1)){
        		mWalkrecordForwardBN.setClickable(false);
    			mWalkrecordForwardBN.setBackgroundResource(R.drawable.oval_white_alphagray);
			}else{
	    		mWalkrecordForwardBN.setClickable(true);
				mWalkrecordForwardBN.setBackgroundResource(R.drawable.oval_white_alphablue);
			}
    		
    		if(mWalkRecordIndex == 0){
        		mWalkrecordBackBN.setClickable(false);
        		mWalkrecordBackBN.setBackgroundResource(R.drawable.oval_white_alphagray);
    		}else{
        		mWalkrecordBackBN.setClickable(true);
        		mWalkrecordBackBN.setBackgroundResource(R.drawable.oval_white_alphablue);
    		}
    		
		}
		
		
		
	}
	
	private void addStartMarker(LatLng curLatLng){
		recAMap.addMarker(new MarkerOptions().position(curLatLng).draggable(false)
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.walking_start)));
	}

	private void addEndMarker(LatLng curLatLng){
		recAMap.addMarker(new MarkerOptions().position(curLatLng).draggable(false)
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.walking_end)));
	}

}
