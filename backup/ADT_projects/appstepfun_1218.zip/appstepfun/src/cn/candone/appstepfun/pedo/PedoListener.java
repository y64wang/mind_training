package cn.candone.appstepfun.pedo;

public interface PedoListener {
    public void onStep();
    public void passValue();
}
