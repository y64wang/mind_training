package cn.candone.appstepfun;

import java.util.Calendar;

import org.json.JSONArray;

import com.umeng.analytics.MobclickAgent;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MyGroupFragment extends Fragment {

	private final String mPageName = "MyGroupFragment";
	private long mLastUpdateTime = 0;
	
	public GroupListFragment mPrivateGroupList;
	public GroupListFragment mFamousGroupList;
	
	private TextView mJoinGroupBN = null;
	private TextView mSearchGroupBN = null;

	public MyGroupFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.main_group_fragment, container, false);

    	MainActivity mainAct = (MainActivity) getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_GROUP_CREATE);
        	//mainAct.getSupportActionBar().setTitle(MainActivity.BARTITLE_MYGROUP);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_MYGROUP);
        }		
		
		FragmentTransaction t = getActivity().getSupportFragmentManager().beginTransaction();
		mPrivateGroupList = new GroupListFragment();
		mPrivateGroupList.setGroupListFragmentTag(GroupListFragment.TAG_PRIVATE);
		t.replace(R.id.myact_privatelist, mPrivateGroupList);
		
		mFamousGroupList = new GroupListFragment();
		mFamousGroupList.setGroupListFragmentTag(GroupListFragment.TAG_FAMOUSE);
		t.replace(R.id.myact_publiclist, mFamousGroupList);
		t.commit();
		
		mJoinGroupBN = (TextView) rootView.findViewById(R.id.group_joinGroupBN);
		mJoinGroupBN.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
	    	  switch (event.getAction()) { 	  
    	        case MotionEvent.ACTION_DOWN:
    	        	mJoinGroupBN.setBackgroundResource(R.drawable.oval_skyblue_orange);
    	            break;
    	        case MotionEvent.ACTION_CANCEL:
    	        case MotionEvent.ACTION_UP:
    	        	mJoinGroupBN.setBackgroundResource(R.drawable.oval_skyblue);
    	            break;
    	        default:
    	            break;
	    	    }
	    	    return false;
			}
		});
		
		mJoinGroupBN.setOnClickListener(new View.OnClickListener() { 
			@Override 
			public void onClick(View v) { 
				MainActivity mainAct = (MainActivity) getActivity();
				mainAct.TransToJoinGroupFragment(mainAct.BARTITLE_JOINGROUP);
			} 
		});
		
		
		mSearchGroupBN = (TextView) rootView.findViewById(R.id.group_searchGroupBN);
		mSearchGroupBN.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
	    	  switch (event.getAction()) { 	  
    	        case MotionEvent.ACTION_DOWN:
    	        	mSearchGroupBN.setBackgroundResource(R.drawable.oval_skyblue_orange);
    	            break;
    	        case MotionEvent.ACTION_CANCEL:
    	        case MotionEvent.ACTION_UP:
    	        	mSearchGroupBN.setBackgroundResource(R.drawable.oval_skyblue);
    	            break;
    	        default:
    	            break;
	    	    }
	    	    return false;
			}
		});
		
		mSearchGroupBN.setOnClickListener(new View.OnClickListener() { 
			@Override 
			public void onClick(View v) { 
				MainActivity mainAct = (MainActivity) getActivity();
				mainAct.TransToSquareFragment();
			} 
		});
		
		return rootView;
	}
	
    @Override
	public void onResume() {
        super.onResume();
		MobclickAgent.onPageStart(mPageName);

		Calendar cd = Calendar.getInstance();
		
		MainActivity mainAct = (MainActivity) getActivity();
		long duration = (cd.getTimeInMillis() - mainAct.mLastGetGroupInfoTime) / 1000;
		
        mainAct.sendUpdateStepCmd();
		if(mainAct.mNeedUpdateGroupInfo || duration > 600){ 
			//update group data on request or duration > 600s
			mainAct.ExecuteGetGroupInfo(mainAct.mPerfData.getUserID());
			mainAct.mNeedUpdateGroupInfo = false;
		}else{
			//update pedo data
			mainAct.ExecuteGetGroupPedo(true);
		}
    }

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
    public void SetGroupListView(GroupListFragment context, JSONArray groupArray){
		if(context != null && groupArray != null){
			context.SetGroupListView(groupArray);
		}
	}		
    
	

}
