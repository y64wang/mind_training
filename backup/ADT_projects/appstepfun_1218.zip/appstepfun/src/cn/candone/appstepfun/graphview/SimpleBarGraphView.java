/**
 * This file is part of GraphView.
 *
 * GraphView is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphView is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphView.  If not, see <http://www.gnu.org/licenses/lgpl.html>.
 *
 * Copyright Jonas Gehring
 */

package cn.candone.appstepfun.graphview;

import cn.candone.appstepfun.R;
import java.io.InputStream;

import cn.candone.appstepfun.UserListFragment.OnUserListFragmentCreatedListener;
import cn.candone.appstepfun.graphview.GraphViewSeries.GraphViewSeriesStyle;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint.Align;
import android.util.AttributeSet;

/**
 * Draws a Simple Bar Chart
 *
 */
public class SimpleBarGraphView extends GraphView {
	
	private boolean drawValuesOnTop = false;
	private int valuesOnTopColor = Color.WHITE;
	private String valueUnit = "";
	private boolean drawTargetBar = false;

	public SimpleBarGraphView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public SimpleBarGraphView(Context context, String title) {
		super(context, title);
	}


	@Override
	protected void drawHorizontalLabels(Canvas canvas, float border,
			float horstart, float height, String[] horlabels, float graphwidth) {
		// horizontal labels + lines
		paint.setTextAlign(Align.CENTER);

		int hors = horlabels.length;
		float barwidth = graphwidth/horlabels.length;
		float textOffset = barwidth/2;
		for (int i = 0; i < horlabels.length; i++) {
			// lines
			float x = ((graphwidth / hors) * i) + horstart;
            if(getShowHorizontalLabels()) {
                // text
                x = barwidth*i + textOffset + horstart;
                paint.setColor(graphViewStyle.getHorizontalLabelsColor());
                canvas.drawText(horlabels[i], x, height - 4, paint);
            }
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void drawSeries(Canvas canvas, GraphViewDataInterface[] values, float graphwidth, float graphheight,
			float border, double minX, double minY, double diffX, double diffY,
			float horstart, GraphViewSeriesStyle style) {
		float colwidth = graphwidth / (values.length);

		paint.setStrokeWidth(style.thickness);
		
		float offset = 0;
		double maxY = minY + diffY;
		boolean ontarget = false;
		
		// draw data
		for (int i = 0; i < values.length; i++) {
			//show diff
			//float valY = (float) (values[i].getY() - minY);
			//float ratY = (float) (valY / diffY);
			
			//show totoal
			float valY = (float) values[i].getY();
			float ratY = (float) (valY / maxY);
			//System.out.println("valY: " + valY + " maxY: " + maxY);
			if(ratY > 1f){ratY = 1f;}  // do not display bar over maxY.
			if(ratY >= 1f){ontarget = true;}
			
			float y = graphheight * ratY;

			// hook for value dependent color
			if (style.getValueDependentColor() != null) {
				paint.setColor(style.getValueDependentColor().get(values[i], maxY));
			} else {
				paint.setColor(style.color);
			}

			float left = (i * colwidth) + horstart -offset;
			float bottom = graphheight + border - 1;
			float top = (border - y) + graphheight;
			if(top >= bottom) {
				top = bottom - 2.0f;
			}
			float right = ((i * colwidth) + horstart) + (colwidth * 0.9f - 1) -offset;
			canvas.drawRect(left, top, right, bottom, paint);

		}
		// -----Set values on top of graph---------
		if (drawValuesOnTop) {
			float y = border - 6;
			float x = horstart + 10;
			paint.setTextAlign(Align.LEFT);
			paint.setTextSize(10f + getGraphViewStyle().getTextSize());
			paint.setColor(valuesOnTopColor);
			canvas.drawText(formatLabel(getMaxY(), false) + valueUnit, x, y, paint);
			paint.setTextSize(getGraphViewStyle().getTextSize());

			paint.setColor(Color.WHITE);
			y = border;
			canvas.drawLine(horstart, y, graphwidth, y, paint);
		}

		if(drawTargetBar){
			paint.setColor(Color.LTGRAY);
			
			float y = border;
			canvas.drawRect(graphwidth, y, graphwidth + 20, y + graphheight, paint);
			
			if(ontarget)
			{
				try{
					/**
			        InputStream is = getResources().openRawResource(R.drawable.targetcompleted);   
			       
			        BitmapFactory.Options newOpts = new BitmapFactory.Options(); 
			        newOpts.inJustDecodeBounds = true; 
			        Bitmap bm = BitmapFactory.decodeStream(is, null, newOpts);
			        newOpts.inJustDecodeBounds = false;
			        int w = newOpts.outWidth;
			        float newW = 30f;
			        int be = 1;
			        be = (int)(w / newW);
			        if(be <=0) {be = 1;}
			        newOpts.inSampleSize = be;
			        bm = BitmapFactory.decodeStream(is, null, newOpts);
			        **/
					InputStream is = getResources().openRawResource(R.drawable.targetcompleted_30);
					Bitmap bm = BitmapFactory.decodeStream(is);
	 		        canvas.drawBitmap(bm, graphwidth - 25, y + graphheight + 5, paint);
				}catch(Exception e){
					System.out.println("drawTargetBar: " + e.toString());
				}
			}
		}
	}

	public boolean getDrawValuesOnTop() {
		return drawValuesOnTop;
	}

	public int getValuesOnTopColor() {
		return valuesOnTopColor;
	}
	
	public String getValueUnit(){
		return valueUnit;
	}

	public boolean getDrawTargetBar() {
		return drawTargetBar;
	}

	/**
	 * You can set the flag to let the GraphView draw the values on top of the bars
	 * @param drawValuesOnTop
	 */
	public void setDrawValuesOnTop(boolean drawValuesOnTop) {
		this.drawValuesOnTop = drawValuesOnTop;
	}

	public void setValuesOnTopColor(int valuesOnTopColor) {
		this.valuesOnTopColor = valuesOnTopColor;
	}

	public void setValueUnit(String unit){
		this.valueUnit = unit;
	}

	public void setDrawTargetBar(boolean drawTargetBar) {
		this.drawTargetBar = drawTargetBar;
	}

}
