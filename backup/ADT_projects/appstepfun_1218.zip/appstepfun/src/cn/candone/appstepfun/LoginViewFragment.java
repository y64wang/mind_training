package cn.candone.appstepfun;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.candone.appstepfun.widget.SwitchBox;

/**
 * A placeholder fragment containing all views.
 * The default view is the user login view.
 */
public class LoginViewFragment extends Fragment  implements cn.candone.appstepfun.widget.SwitchBox.OnChangedListener{
	private final String mPageName = "LoginViewFragment";
	
	private SwitchBox mSwitchBox_TargetReminder;
	private SwitchBox mSwitchBox_HealthTip;
	private SwitchBox mSwitchBox_SquareSharing;
	private TextView mTargetButton;
	private TextView mTargetTV;

	private PreferencesData mPerfData;
	
    public LoginViewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

    	MainActivity mainAct = (MainActivity) getActivity();

    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
   	
    	mPerfData = (PreferencesData) mainAct.getApplicationContext();
    	String userID = mPerfData.getUserID();

    	if(!userID.equals("")){
	    	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_LOGIN_LOGOUT);
    	}else{
			//mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_LOGIN_LOGIN);
    		mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
		}
    	
    	View rootView = inflater.inflate(R.layout.main_login_fragment, container, false);
    	
    	mTargetTV = (TextView) rootView.findViewById(R.id.userTarget);
    	mTargetTV.setText(mPerfData.getUserTarget() + "��");
        
        mSwitchBox_TargetReminder = (SwitchBox)rootView.findViewById(R.id.switchbox_targetreminder);
        mSwitchBox_TargetReminder.setChecked(mPerfData.getTargetReminder());
        mSwitchBox_TargetReminder.setOnChangedListener(this);       	

        mSwitchBox_HealthTip = (SwitchBox)rootView.findViewById(R.id.switchbox_healthtip);
        mSwitchBox_HealthTip.setEnabled(false);
        //mSwitchBox_HealthTip.setChecked(mPerfData.getHealthTip());
        //mSwitchBox_HealthTip.setOnChangedListener(this);

        mSwitchBox_SquareSharing = (SwitchBox)rootView.findViewById(R.id.switchbox_squareshare);
        mSwitchBox_SquareSharing.setChecked(mPerfData.getSquareSharing());
        mSwitchBox_SquareSharing.setOnChangedListener(this); 	

        ImageView headView = (ImageView)rootView.findViewById(R.id.headerImage);
        MainActivity.displayHeadImage(mPerfData.getUserIconUrl(), headView);
		
		if(! userID.equals("")){
			TextView nameView = (TextView)rootView.findViewById(R.id.nameTextView);
			nameView.setText(mPerfData.getUserName());
		}
		 
        if(mainAct.mActionBarMenu != null){
        	if(userID.equals("")){
        		mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_LOGIN_LOGIN);
        	}else{
        		mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_LOGIN_LOGOUT);
        	}
        	//mainAct.getSupportActionBar().setTitle(MainActivity.BARTITLE_LOGINVIEW);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_LOGINVIEW);
        }

        final Builder targetBuilder = new AlertDialog.Builder(getActivity());
        final CharSequence[] charSequences = {"2000","5000","10000","20000", "50000"};
        mTargetButton = (TextView)rootView.findViewById(R.id.textTargetButton);
        mTargetButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				targetBuilder.setIcon(R.drawable.app_icon);
				targetBuilder.setTitle("ÿ��Ŀ��");
				targetBuilder.setItems(charSequences, new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {

						switch(which){
						case 0:
							mPerfData.setUserTareget(2000);
							break;
						case 1:
							mPerfData.setUserTareget(5000);
							break;
						case 2:
							mPerfData.setUserTareget(10000);
							break;
						case 3:
							mPerfData.setUserTareget(20000);
							break;
						case 4:
							mPerfData.setUserTareget(50000);
							break;
						default:
							mPerfData.setUserTareget(10000);
							break;
						}
						
						mTargetTV.setText(mPerfData.getUserTarget() + "��");
					}
					});
				
				targetBuilder.create().show();
			}
		});
        
        mTargetButton.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	switch (event.getAction()) { 	  
    	        case MotionEvent.ACTION_DOWN:
    	        	mTargetButton.setTextColor(getResources().getColor(R.color.deepskyblue));
    	            break;
    	        case MotionEvent.ACTION_CANCEL:
    	        case MotionEvent.ACTION_UP:
    	        	mTargetButton.setTextColor(getResources().getColor(R.color.white));
    	            break;
    	        default:
    	            break;
		    	}
		    	
		    	return false;
			}
        });
        
        return rootView;
    }

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
	@Override
	public void OnChanged(SwitchBox switchbox, boolean checkState) {

		if(mSwitchBox_TargetReminder == switchbox){
			mPerfData.setTargetReminder(checkState);
		}else if(mSwitchBox_HealthTip == switchbox){
			mPerfData.setHealthTip(checkState);
		}else if(mSwitchBox_SquareSharing == switchbox){
			mPerfData.setSquareSharing(checkState);
		}
	}
	
	@Override
	public void onDestroy(){
		super.onDestroy();
    	MainActivity mainAct = (MainActivity) getActivity();

    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);

	}

}

