package cn.candone.appstepfun.helper;

import java.util.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StepFunDBHelper extends SQLiteOpenHelper {

	private static StepFunDBHelper mInstance = null;
	
	private final static String DATABASE_NAME = "appstepfun_db";  
    private final static int DATABASE_VERSION = 1;  
    private final static String TABLE_STEP_HISTORY = "stepHistoryTable";

    // table column definition
    public final static int COL_STEPHISTORY_USERID = 1;
    public final static int COL_STEPHISTORY_USERNAME = 2;
    public final static int COL_STEPHISTORY_STEPS = 3;
    public final static int COL_STEPHISTORY_DATE = 4;
    
    public StepFunDBHelper(Context context) {  
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    } 

    public synchronized static StepFunDBHelper getInstance(Context context) {
    	if (mInstance == null) {
    		SDCardDatabaseContext sdcardContxt = SDCardDatabaseContext.getContext(context);
    		mInstance = new StepFunDBHelper(sdcardContxt);
    	}
    	return mInstance;
    };
    
    @Override
    public void onCreate(SQLiteDatabase db) {
    	
    	try{
    		db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_STEP_HISTORY   
                + "(_id INTEGER PRIMARY KEY autoincrement,"   
                + " UserID VARCHAR(30)  NOT NULL,"   
                + " UserName VARCHAR(20),"  
                + " Steps INTEGER,"
                + " Date  LONG)");
    	}catch(SQLException se){
    		System.out.println("AppStepFunDataBaseHelper Create Table failed: " + se.toString());
    	}
    }	

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}
	
    public static Cursor select_StepHistory(Context context, String userID, Date startDate, Date endDate){
    	
    	Cursor cursor = null;
    	SQLiteDatabase db = getInstance(context).getReadableDatabase();  
		cursor = db.rawQuery("select * from " + TABLE_STEP_HISTORY 
				+ " where UserID = \"" + userID
				+ "\" and Date >= " + startDate.getTime()
				+ " and Date < " + endDate.getTime(), null);
    	
        return cursor;  
        
    }
    
    public static long insert_StepHistory(Context context, String userId, String userName, int steps, long date){
        SQLiteDatabase db = getInstance(context).getWritableDatabase();  
        ContentValues cv = new ContentValues();  
        cv.put("UserID", userId);  
        cv.put("UserName", userName);
        cv.put("Steps", steps);
        cv.put("Date", date);
        long row = db.insert(TABLE_STEP_HISTORY, null, cv);  
        return row;  
    }
    
    public static void delete_StepHistory(Context context, int id){  
        SQLiteDatabase db = getInstance(context).getWritableDatabase();  
        String where = "_id" + "=?";  
        String[] whereValue = { Integer.toString(id) };  
        db.delete(TABLE_STEP_HISTORY, where, whereValue);  
    }
    
    public static void update_StepHistory(Context context, int id, int steps, long date){  
        SQLiteDatabase db = getInstance(context).getWritableDatabase();  
        String where = "_id" + "=?";  
        String[] whereValue = { Integer.toString(id) };  
  
        ContentValues cv = new ContentValues();  
        cv.put("Steps", steps);  
        cv.put("Date", date);  
          
        db.update(TABLE_STEP_HISTORY, cv, where, whereValue);  
    }  
}
