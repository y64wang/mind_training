package cn.candone.appstepfun;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class GroupListFragment extends ListFragment {
	OnGroupListFragmentCreatedListener mListCreatedListener;
	
	public static final String TAG_PRIVATE = "PrivateGroup";
	public static final String TAG_FAMOUSE = "FamousGroup";
	
	private String mTag = "";
	private DisplayImageOptions mImageLoaderOptions;

	public GroupListFragment(){
		
	}
	
    public String getGroupListFragmentTag(){
    	return this.mTag;
    }

    public void setGroupListFragmentTag(String tag){
    	this.mTag = tag;
    }

    
    public interface OnGroupListFragmentCreatedListener {
        public void OnGroupListFragmentCreated(GroupListFragment context);
    }    
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		mImageLoaderOptions = new DisplayImageOptions.Builder()  
        .showImageOnLoading(R.drawable.app_default)
        .showImageForEmptyUri(R.drawable.app_default)  
        .showImageOnFail(R.drawable.app_default)
        .cacheInMemory(true)  
        .cacheOnDisk(true)
        .considerExifParams(true)
        //.imageScaleType(ImageScaleType.IN_SAMPLE_INT)
        .bitmapConfig(Bitmap.Config.RGB_565)  
        //.decodingOptions(android.graphics.BitmapFactory.Options decodingOptions)//����ͼƬ�Ľ�������  
        //.delayBeforeLoading(1000)   //int delayInMillisΪ�����õ�����ǰ���ӳ�ʱ��
        //����ͼƬ���뻺��ǰ����bitmap��������  
        //.preProcessor(BitmapProcessor preProcessor)  
        //.resetViewBeforeLoading(true)//����ͼƬ������ǰ�Ƿ����ã���λ  
        .displayer(new RoundedBitmapDisplayer(180)) // round conner
        .handler(new Handler())
        .build();
		return inflater.inflate(R.layout.list, null);
	}

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
        	mListCreatedListener = (OnGroupListFragmentCreatedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnListFragmentCreatedListener");
        }
    }

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onResume(){
		super.onResume();
    	if(mListCreatedListener != null){
    		mListCreatedListener.OnGroupListFragmentCreated(this);
    	}
	}
	
	@Override
	public void onDestroy(){
    	ImageLoader.getInstance().stop();
    	super.onDestroy();
	}
	  
    public class GroupItem {
		
		public String groupName;
		public String target;
		public String ownerIconUrl;
		public String mySequence;
		public String champion;
		public int  userNumber;
		

		
		public GroupItem(String groupName, String target, String ownerIconUrl,
				       String mySequence, String champion, int userNumber) {
			this.groupName = groupName;
			this.target = target;
			this.ownerIconUrl = ownerIconUrl;
			this.mySequence = mySequence;
			this.champion = champion;
			this.userNumber = userNumber;
		}

	}

	public class ActivityAdapter extends ArrayAdapter<GroupItem> {

		public ActivityAdapter(Context context) {
			super(context, 0);
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = LayoutInflater.from(getContext()).inflate(R.layout.group_row, null);
			}
			ImageView iconIV = (ImageView) convertView.findViewById(R.id.myactrow_icon);
			displayHeadImage(getItem(position).ownerIconUrl, iconIV);
			
			TextView groupNameTV = (TextView) convertView.findViewById(R.id.myactrow_groupName);
			groupNameTV.setText("����: " + MainActivity.GetRealGroupName(getItem(position).groupName));
			TextView targetTV = (TextView) convertView.findViewById(R.id.myactrow_target);
			targetTV.setText("Ŀ��: " + getItem(position).target+"��");
			TextView sequenceTV = (TextView) convertView.findViewById(R.id.myactrow_seq);
			sequenceTV.setText(getItem(position).mySequence);
			TextView championTV = (TextView) convertView.findViewById(R.id.myactrow_champion);
			championTV.setText(getItem(position).champion);
			TextView numberTV = (TextView) convertView.findViewById(R.id.myactrow_number);
			numberTV.setText("С�鹲" + getItem(position).userNumber+"��");

			return convertView;
		}
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		ActivityAdapter adapter =  (ActivityAdapter) getListAdapter();
		
		GroupItem selectedItem = adapter.getItem(position);
		TransToGroupDetailActivity(selectedItem);
		
		super.onListItemClick(l, v, position, id);
	}			

	private void TransToGroupDetailActivity(GroupItem selectedItem){
		
		MainActivity mainAct = (MainActivity)getActivity();
		
    	Fragment mainfragment = mainAct.getSupportFragmentManager().findFragmentByTag(MainActivity.TAG_FRAGMENT_GROUPDETAIL);
    	if(mainfragment == null){
        	Fragment currentfragment=mainAct.getSupportFragmentManager().findFragmentById(R.id.container);
        	mainAct.PushCurrentFragment(currentfragment.getTag());
        	
        	mainfragment = new GroupDetailFragment();
        	FragmentTransaction t = mainAct.getSupportFragmentManager().beginTransaction();
        	t.add(R.id.container, mainfragment, MainActivity.TAG_FRAGMENT_GROUPDETAIL);
            t.remove(currentfragment);
            t.commit();

            mainAct.mSelectedGroupName = selectedItem.groupName;
            mainAct.mPerfData.setSelectedGroupName(selectedItem.groupName);
            if(selectedItem.target.equals("������")){
            	mainAct.mPerfData.setSelectedGroupTarget(10000);
            }else{
            	mainAct.mPerfData.setSelectedGroupTarget(Integer.valueOf(selectedItem.target));
            }
    		//mainAct.mPerfData.SaveSelectedGroupInfo();
    	}
	}
	
	public void SetGroupListView(JSONArray groupArray){

		ActivityAdapter adapter = new ActivityAdapter(getActivity());

		int groupCount = groupArray.length();
		if(groupCount > 0){
			
			try{
				
				for(int i=0; i<groupCount; i++){
					JSONObject groupEntry = groupArray.getJSONObject(i);
					String groupName = groupEntry.getString("groupName");
					String target = groupEntry.getString("dailyTarget");
					String ownerIconUrl = groupEntry.getString("photoUrl");
					
					String mySequence;
					if(groupEntry.has("mySequence")){
						mySequence = groupEntry.getString("mySequence");
					}else{
						mySequence = "���޳ɼ�";
					}
					
					String champion;
					if(groupEntry.has("champion")){
						champion = groupEntry.getString("champion");
					}else{
						champion = "���޳ɼ�";
					}
					int userNumber = groupEntry.getInt("userNumber");
					
					adapter.add(new GroupItem(groupName, target, ownerIconUrl, 
							mySequence, champion, userNumber));
				}
				
				
			}catch(JSONException e){
				System.out.println("SetGroupListView: " + e.toString());
			};
		}

		setListAdapter(adapter);
	}

    private void displayHeadImage(String url, ImageView imgView){
        ImageLoader.getInstance().displayImage(url, imgView, mImageLoaderOptions);
    }

}