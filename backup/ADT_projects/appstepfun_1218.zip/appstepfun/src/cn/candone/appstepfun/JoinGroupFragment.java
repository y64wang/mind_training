package cn.candone.appstepfun;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;

import cn.candone.appstepfun.widget.SwitchBox;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class JoinGroupFragment extends Fragment implements cn.candone.appstepfun.widget.SwitchBox.OnChangedListener  {
	private final String mPageName = "JoinGroupFragment";
	
	private SwitchBox mSwitchBox_password;
	private boolean mPasswdEnabled = false;

	private Button mJoinButton;
	private TextView mGroupTargetButton;
	private TextView mGroupTargetTV;
	private ImageView mLockImage;
	private FrameLayout mPasswordFrameLayout;
	private TextView mPasswordTextView;
	private EditText mPasswdEditText;
	
    public JoinGroupFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

    	MainActivity mainAct = (MainActivity) getActivity();

        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_GROUP_SWITCH);
        	//mainAct.getSupportActionBar().setTitle(MainActivity.BARTITLE_JOINGROUP);
        	mainAct.mActionBarTitle.setText(mainAct.mJoinGroupState);
        }

    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
		
        View rootView = inflater.inflate(R.layout.main_joingroup_fragment, container, false);
   
        mLockImage = (ImageView) rootView.findViewById(R.id.lockImage);
        mLockImage.setImageDrawable(getResources().getDrawable(R.drawable.unlock_48));
        
        mSwitchBox_password = (SwitchBox)rootView.findViewById(R.id.switchbox_password);
        mSwitchBox_password.setOnChangedListener(this);
        
        LinearLayout targetLayout = (LinearLayout)rootView.findViewById(R.id.actTargetLinearLayout);

        mPasswdEditText = (EditText)rootView.findViewById(R.id.passwordEditText);
        mPasswordFrameLayout = (FrameLayout)rootView.findViewById(R.id.passwordFrameLayout);
        mPasswordTextView = (TextView)rootView.findViewById(R.id.passwordTextView);

        mPasswdEditText.setFocusable(false);
        mPasswdEditText.setFocusableInTouchMode(false);

        mPasswdEditText.setBackgroundResource(R.drawable.oval_gray);
    	mPasswordFrameLayout.setBackgroundResource(R.drawable.oval_gray);
    	mPasswordTextView.setTextColor(getResources().getColor(R.color.gray));
    	
    	mJoinButton = (Button)rootView.findViewById(R.id.joinGroupButton);
    	
    	if(mainAct.mActionBarTitle.getText().equals(mainAct.BARTITLE_JOINGROUP)){
    		mJoinButton.setText("�μ�");
            targetLayout.setVisibility(View.GONE);
    	}else{
    		mJoinButton.setText("����");
            targetLayout.setVisibility(View.VISIBLE);
    	}
    	mJoinButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity mainAct = (MainActivity) getActivity();
		     	if(mJoinButton.getText().equals("�μ�")){
		    		mainAct.ExecuteJoinGroup();
		    	}else{
		    		mainAct.ExecuteCreateGroup();
		    	}				
			}
		});

    	mJoinButton.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mJoinButton.setBackgroundResource(R.drawable.oval_blue_solid);
	    	        	mJoinButton.setTextColor(getResources().getColor(R.color.whitesmoke));
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mJoinButton.setBackgroundResource(R.drawable.oval_yellow);
	    	        	mJoinButton.setTextColor(getResources().getColor(R.color.orange));
	    	            break;
	    	        default:
	    	            break;
	    	    }
				return false;
			}
		});
    	
    	mGroupTargetTV = (TextView)rootView.findViewById(R.id.groupTargetTV);
    	
    	final Builder targetBuilder = new AlertDialog.Builder(getActivity());
        final CharSequence[] charSequences = {"2000","5000","10000","20000", "50000"};
    	mGroupTargetButton = (TextView) rootView.findViewById(R.id.groupTargetButton);
    	mGroupTargetButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				targetBuilder.setIcon(R.drawable.app_icon);
				targetBuilder.setTitle("�˶�Ŀ��");
				targetBuilder.setItems(charSequences, new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {

						switch(which){
						case 0:
							mGroupTargetTV.setText("2000");
							break;
						case 1:
							mGroupTargetTV.setText("5000");
							break;
						case 2:
							mGroupTargetTV.setText("10000");
							break;
						case 3:
							mGroupTargetTV.setText("20000");
							break;
						case 4:
							mGroupTargetTV.setText("50000");
							break;
						default:
							mGroupTargetTV.setText("10000");
							break;
						}
					}
					});
				
				targetBuilder.create().show();
			}
		});

    	mGroupTargetButton.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	switch (event.getAction()) { 	  
    	        case MotionEvent.ACTION_DOWN:
    	        	mGroupTargetButton.setTextColor(getResources().getColor(R.color.deepskyblue));
    	            break;
    	        case MotionEvent.ACTION_CANCEL:
    	        case MotionEvent.ACTION_UP:
    	        	mGroupTargetButton.setTextColor(getResources().getColor(R.color.white));
    	            break;
    	        default:
    	            break;
		    	}				
		    	return false;
			}
		});
        return rootView;
	}

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
    @Override
	public void OnChanged(SwitchBox switchbox, boolean checkState) {

		if(mSwitchBox_password == switchbox){
			mPasswdEnabled = checkState;
			
	        mPasswdEditText.setFocusable(mPasswdEnabled);
	        mPasswdEditText.setFocusableInTouchMode(mPasswdEnabled);
	       
	        if(mPasswdEnabled){
	            AlertDialog noteDialog = new AlertDialog.Builder(getActivity()).create();  
	            noteDialog.setTitle("�������ܻ");
	            noteDialog.setMessage("ֻ�м������ܻ����Ҫ��������");  
	            noteDialog.setButton("ȷ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						
					}
	            });  
	            noteDialog.show();				

	            mPasswdEditText.setBackgroundResource(R.drawable.oval_skyblue);
	        	mPasswordFrameLayout.setBackgroundResource(R.drawable.oval_skyblue);
	        	mPasswordTextView.setTextColor(getResources().getColor(R.color.blue));
	            mLockImage.setImageDrawable(getResources().getDrawable(R.drawable.lock_48));

	        }else{
	        	mPasswdEditText.setBackgroundResource(R.drawable.oval_gray);
	        	mPasswdEditText.setText("");
	        	mPasswordFrameLayout.setBackgroundResource(R.drawable.oval_gray);
	        	mPasswordTextView.setTextColor(getResources().getColor(R.color.gray));
	            mLockImage.setImageDrawable(getResources().getDrawable(R.drawable.unlock_48));
	        }
	        mLockImage.invalidate();
	    }
	}

    @Override
    public void onDestroy(){
    	super.onDestroy();
    	MainActivity mainAct = (MainActivity) getActivity();

    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
    }
}
