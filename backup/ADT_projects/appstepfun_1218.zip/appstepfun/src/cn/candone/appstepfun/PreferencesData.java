package cn.candone.appstepfun;

import android.app.ActivityManager;
import android.app.Application;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

public class PreferencesData extends Application {
	public static final String PREFS_NAME = "appstepfun_preferences";
	
	public static final String[] PreferenceStrings = {
	"appstepfun_startSteps",
	"appstepfun_savedStepDate",
	"appstepfun_loginMode",
	"appstepfun_userId",
	"appstepfun_uuId",
	"appstepfun_userName",
	"appstepfun_userHeadImageUrl" ,
	"appstepfun_userTargetReminder" ,
	"appstepfun_userHealthTip" ,
	"appstepfun_userSquareShare" ,
	
	"appstepfun_groupList",
	"appstepfun_selecteGroupName",
	"appstepfun_fetchGroupDate",
	"appstepfun_fetchUserArray",
	
	"appstepfun_userHideGroup",
	"appstepfun_selectedGroupTarget",
	"appstepfun_userTarget",
	"appstepfun_famouseGropuList",
	
	"appstepfun_trainingPlans",
	"appstepfun_currentPlan",
	
	"appstepfun_hourReportSteps",

	"appstepfun_lastLatitude",
	"appstepfun_lastLongtitude",

	"appstepfun_walkingRecList",
	};
	
	// shared preference tag.
	public static final int USER_STEPS = 0;
	public static final int USER_STEPDATE = 1;
	public static final int USER_LOGINMODE = 2;
	public static final int USER_USERID = 3;
	public static final int USER_UUID = 4;
	public static final int USER_USERNAME = 5;
	public static final int USER_USERICONURL = 6 ;
	public static final int USER_USERTAREGETREM = 7 ;
	public static final int USER_USERHEALTHTIP = 8 ;
	public static final int USER_USERSQUARESHARE = 9 ;
	
	public static final int GROUP_LIST = 10;
	public static final int GROUP_SELECTED = 11;
	public static final int GROUP_FETCH_DATE = 12;
	public static final int GROUP_FETCH_USERS = 13;
	public static final int GROUP_HIDEGROUP = 14;
	public static final int GROUP_SELECTEDTARGET = 15;
	
	public static final int USER_TARGET = 16;

	public static final int GROUP_FAMOUSLIST = 17;
	public static final int USER_TRAININGPLANS = 18;
	public static final int USER_CURRENTPLAN = 19;
	
	public static final int USER_HOURREPORTSTEPS = 20;
	
	public static final int MAP_LASTLATITUDE = 21;
	public static final int MAP_LASTLONGTITUDE = 22;
	public static final int MAP_WALKRECORDLIST = 23;
	
	// login mode 
	public static final int LOGIN_NONE = 0;   // NOT logined.
	public static final int LOGIN_OWN = 1;    // own system login mode
	public static final int LOGIN_WEIXIN = 2;  // weixin login mode
	public static final int LOGIN_QQ = 3;      // QQ login mode
	public static final int LOGIN_SINA = 4;    // sina weibo login mode
	
	// user info
	private int mLoginMode = LOGIN_NONE;
    private String mUserID = "";
    private String mUUID = "";
    private String mUserName = "";
    private String mUserHeadImageUrl = "";
	private boolean mTargetReminder = false;
	private boolean mHealthTip = true;
	private boolean mSquareSharing = false;
	private String mHideGroup = "";
	private int mTarget;
	private String mTrainingPlans = "";
	private String mCurrentPlan="";
	
	// pedo info
	private int mSteps = 0;
	private String mStepDay = "";
	private int mHourReportSteps = 0;
	
	// group info
	private String mGroupArray = "";
	private String mFamousGroupArray = "";
	private String mSelectedGroupName = "";
	private long mFetchGroupDate = 0;
	private String mPedoUserArrayStr = "";
	private int mSelectedGroupTarget = 0;
	
	// map info
	private String mLastLatitude = "0";
	private String mLastLongtitude = "0";
	private String mWalkingRecList = "";
	
    public PreferencesData() {
    }

    // User info
    public void setLoginMode(int loginMode){
    	this.mLoginMode = loginMode;
    }
    
    public int getLoginMode(){
    	return mLoginMode;
    }

    public void setUserID(String userId){
    	this.mUserID = userId;
    }

    public String getUserID(){
    	return mUserID;
    }
    
    public void setThirdPartID(String thirdPartId){
    	this.mUUID = thirdPartId;
    }

    public String getThirdPartID(){
    	return mUUID;
    }

    public void setUserName(String userName){
    	this.mUserName = userName;
    }
        
    public String getUserName(){
    	return mUserName;
    }
        
    public void setUserIconUrl(String userIconUrl){
    	this.mUserHeadImageUrl = userIconUrl;
    }

    public String getUserIconUrl(){
    	return mUserHeadImageUrl;
    }

    public void setHideGroup(String hidegroup){
    	this.mHideGroup = hidegroup;
    }

    public String getHideGroup(){
    	return mHideGroup;
    }
    
    public void setTargetReminder(boolean targetReminder){
    	this.mTargetReminder = targetReminder;
    }
    
    public boolean getTargetReminder(){
    	return mTargetReminder;
    }

    public void setHealthTip(boolean healthTip){
    	this.mHealthTip = healthTip;
    }
    
    public boolean getHealthTip(){
    	return mHealthTip;
    }
    
    public void setSquareSharing(boolean squareSharing){
    	this.mSquareSharing = squareSharing;
    }
    
    public boolean getSquareSharing(){
    	return mSquareSharing;
    }
    
    public void setUserTareget(int target){
    	this.mTarget = target;
    }
    
    public int getUserTarget(){
    	return mTarget;
    }

    public String getTrainingPlans(){
    	return mTrainingPlans;
    }
    
    public void setTrainingPlans(String plans){
    	this.mTrainingPlans = plans;
    }    
    
    public String getCurrentPlans(){
    	return mCurrentPlan;
    }
    
    public void setCurrentPlans(String plan){
    	this.mCurrentPlan = plan;
    }    
        // Pedo info
    public void setUserSteps(int steps){
    	this.mSteps = steps;
    }
    
    public int getUserSteps(){
    	return mSteps;
    }
        
    public void setUserStepDay(String stepDay){
    	this.mStepDay = stepDay;
    }
    
    public String getUserStepDay(){
    	return mStepDay;
    }    
    
    public void setUserHourSteps(int steps){
    	this.mHourReportSteps = steps;
    }
    
    public int getUserHourSteps(){
    	return mHourReportSteps;
    }
    
    // Group info
    public void setGroupArray(String groupArrayStr){
    	this.mGroupArray = groupArrayStr;
    }
    
    public String getGroupArray(){
    	return mGroupArray;
    }
    
    public void setFamousGroupArray(String famousGroupStr){
    	this.mFamousGroupArray = famousGroupStr;
    }
    
    public String getFamousGroupArray(){
    	return mFamousGroupArray;
    }
    
    public void setSelectedGroupName(String groupName){
    	this.mSelectedGroupName = groupName;
    }
    
    public String getSelectedGroupName(){
    	return mSelectedGroupName;
    }
    
    public void setSelectedGroupTarget(int target){
    	this.mSelectedGroupTarget = target;
    }
    
    public int getSelectedGroupTarget(){
    	return mSelectedGroupTarget;
    }
    
    public void setFetchGroupDate(long fetchDate){
    	this.mFetchGroupDate = fetchDate;
    }
    
    public long getFetchGroupDate(){
    	return mFetchGroupDate;
    }

    public void setFetchUserArray(String userArray){
    	this.mPedoUserArrayStr = userArray;
    }
    
    public String getFetchUserArray(){
    	return mPedoUserArrayStr;
    }

    public void setLastLatitude(double latitude){
    	this.mLastLatitude = Double.toString(latitude);
    }
    
    public double getLastLatitude(){
    	return Double.valueOf(mLastLatitude);
    }
    
    public void setLastLongtitude(double longtitude){
    	this.mLastLongtitude = Double.toString(longtitude);
    }
    
    public double getLastLongtitude(){
    	return Double.valueOf(mLastLongtitude);
    }
    
    public void setWalkingRecList(String recList){
    	this.mWalkingRecList = recList;
    }
    
    public String getWalkingRecList(){
    	return this.mWalkingRecList;
    }
    
    public void ClearUserLoginInfo(){
    	mLoginMode = LOGIN_NONE;
        mUserID = "";
        mUUID = "";
        mUserName = "";
        mUserHeadImageUrl = "";
        mHideGroup = "";
    	mTargetReminder = true;
    	mHealthTip = false; 
    	mSquareSharing = true;
    	mHideGroup = "";
    	mTarget = 10000;
    	mTrainingPlans = "";
    	mCurrentPlan = "";
    }
    
    public void SaveUserLoginInfo(){
		// update user state in preference
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt(PreferenceStrings[USER_LOGINMODE], mLoginMode);
		editor.putString(PreferenceStrings[USER_USERID], mUserID);
		editor.putString(PreferenceStrings[USER_UUID], mUUID);
		editor.putString(PreferenceStrings[USER_USERNAME], mUserName);
		editor.putString(PreferenceStrings[USER_USERICONURL], mUserHeadImageUrl);
		editor.putBoolean(PreferenceStrings[USER_USERTAREGETREM], mTargetReminder);
		editor.putBoolean(PreferenceStrings[USER_USERHEALTHTIP], mHealthTip);
		editor.putBoolean(PreferenceStrings[USER_USERSQUARESHARE], mSquareSharing);
		editor.putInt(PreferenceStrings[USER_TARGET], mTarget);
		editor.putString(PreferenceStrings[USER_TRAININGPLANS], mTrainingPlans);
		editor.putString(PreferenceStrings[USER_CURRENTPLAN], mCurrentPlan);
		editor.commit();    	
    }

    public void UpdateUserID(){
		SharedPreferences settings = getSharedPreferences(PreferencesData.PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(PreferenceStrings[USER_USERID], mUserID);

        // Commit the edits!
		editor.commit();		
	}
    public void LoadUserLoginInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);

        mLoginMode = settings.getInt(PreferenceStrings[USER_LOGINMODE], PreferencesData.LOGIN_NONE);
        mUserID = settings.getString(PreferenceStrings[USER_USERID], "");
        mUUID = settings.getString(PreferenceStrings[USER_UUID],"");
        mUserName = settings.getString(PreferenceStrings[USER_USERNAME], "");
        mUserHeadImageUrl = settings.getString(PreferenceStrings[USER_USERICONURL], "");
        mTargetReminder = settings.getBoolean(PreferenceStrings[USER_USERTAREGETREM], true);
        mHealthTip = settings.getBoolean(PreferenceStrings[USER_USERHEALTHTIP], false);	
        mSquareSharing = settings.getBoolean(PreferenceStrings[USER_USERSQUARESHARE], true);
        mTarget = settings.getInt(PreferenceStrings[USER_TARGET], 10000);
        mTrainingPlans = settings.getString(PreferenceStrings[USER_TRAININGPLANS], "");
        mCurrentPlan = settings.getString(PreferenceStrings[USER_CURRENTPLAN], "");
        
        mSteps = settings.getInt(PreferenceStrings[USER_STEPS], 0);
    }
    
	public void LoadPedoInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mStepDay = settings.getString(PreferenceStrings[USER_STEPDATE], "");
       	mSteps = settings.getInt(PreferenceStrings[USER_STEPS], 0);
       	mHourReportSteps = settings.getInt(PreferenceStrings[USER_HOURREPORTSTEPS], 0);
	}    
	
	public void SavePedoInfo(){
		// update user state in preference
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt(PreferenceStrings[USER_STEPS], mSteps);
		editor.putString(PreferenceStrings[USER_STEPDATE], mStepDay);
		editor.putInt(PreferenceStrings[USER_HOURREPORTSTEPS], mHourReportSteps);
		editor.commit();	
	}
	
	public void ClearGroupArrayInfo(){
		mGroupArray = "";
		mHideGroup = "";
		mFamousGroupArray = "";
	}
	
	public void LoadGroupArrayInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mGroupArray = settings.getString(PreferenceStrings[GROUP_LIST], "");
        mHideGroup = settings.getString(PreferenceStrings[GROUP_HIDEGROUP], "");
        mFamousGroupArray = settings.getString(PreferenceStrings[GROUP_FAMOUSLIST], "");
	}    
	
	public void SaveGroupArrayInfo(){
		// update user state in preference
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(PreferenceStrings[GROUP_LIST], mGroupArray);
		editor.putString(PreferenceStrings[GROUP_HIDEGROUP], mHideGroup);
		editor.putString(PreferenceStrings[GROUP_FAMOUSLIST], mFamousGroupArray);
		editor.commit();	
	} 
	
	public String LoadGroupUsersInfo(String groupName){
		String pattern = "appstepfunGrpUser_" + groupName;
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        return settings.getString(pattern, "");
	}    
	
	public void SaveGroupUsersInfo(String groupName, String groupUsers){
		// update user state in preference
		String pattern = "appstepfunGrpUser_" + groupName;
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(pattern, groupUsers);
		editor.commit();	
	} 
	
	public void LoadSelectedGroupInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mSelectedGroupName = settings.getString(PreferenceStrings[GROUP_SELECTED], "");
        mSelectedGroupTarget = settings.getInt(PreferenceStrings[GROUP_SELECTEDTARGET], 10000);
	}    
	
	public void SaveSelectedGroupInfo(){
		// update user state in preference
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(PreferenceStrings[GROUP_SELECTED], mSelectedGroupName);
		editor.putInt(PreferenceStrings[GROUP_SELECTEDTARGET], mSelectedGroupTarget);
		editor.commit();	
	}
	
	public void ClearFetchGroupInfo(){
		mFetchGroupDate = 0;
		mPedoUserArrayStr = "";
	}
	
	public void LoadFetchGroupInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mFetchGroupDate = settings.getLong(PreferenceStrings[GROUP_FETCH_DATE], 0);
        mPedoUserArrayStr = settings.getString(PreferenceStrings[GROUP_FETCH_USERS], "");
	}    
	
	public void SaveFetchGroupInfo(){
		// update user state in preference
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putLong(PreferenceStrings[GROUP_FETCH_DATE], mFetchGroupDate);
		editor.putString(PreferenceStrings[GROUP_FETCH_USERS], mPedoUserArrayStr);
		editor.commit();	
	} 

	public void LoadLocationInfo(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mLastLatitude = settings.getString(PreferenceStrings[MAP_LASTLATITUDE], "0");
        mLastLongtitude = settings.getString(PreferenceStrings[MAP_LASTLONGTITUDE], "0");
        mWalkingRecList = settings.getString(PreferenceStrings[MAP_WALKRECORDLIST], "");
	}    
	
	public void SaveLocationInfo(){
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(PreferenceStrings[MAP_LASTLATITUDE], mLastLatitude);
		editor.putString(PreferenceStrings[MAP_LASTLONGTITUDE], mLastLongtitude);
		editor.putString(PreferenceStrings[MAP_WALKRECORDLIST], mWalkingRecList);
		editor.commit();	
	}

	public void LoadWalkingRecordList(){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        mWalkingRecList = settings.getString(PreferenceStrings[MAP_WALKRECORDLIST], "");
	}    
	
	public void SaveWalkingRecordList(){
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(PreferenceStrings[MAP_WALKRECORDLIST], mWalkingRecList);
		editor.commit();	
	}
	
	public String LoadWalkingRecord(String walkDate){
		String pattern = "appstepfunWlkRec_" + walkDate;
	    SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
	    return settings.getString(pattern, "");
	}    
	
	public void SaveWalkingRecord(String walkDate, String walkRecord){
		// update user state in preference
		String pattern = "appstepfunWlkRec_" + walkDate;
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString(pattern, walkRecord);
		editor.commit();	
	}
}
