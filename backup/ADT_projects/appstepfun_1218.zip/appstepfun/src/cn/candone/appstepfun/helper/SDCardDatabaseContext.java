package cn.candone.appstepfun.helper;

import java.io.File;
import java.io.IOException;

import android.content.Context;
import android.content.ContextWrapper;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class SDCardDatabaseContext extends ContextWrapper {

	private static SDCardDatabaseContext mContext = null;

	public SDCardDatabaseContext(Context base) {
		super(base);
	}

    public synchronized static SDCardDatabaseContext getContext(Context base) {
    	if (mContext == null) {
    		mContext = new SDCardDatabaseContext(base);
    	}
    	return mContext;
    };
	
    @Override
    public File getDatabasePath(String name) {
        boolean sdExist = android.os.Environment.MEDIA_MOUNTED.equals(android.os.Environment.getExternalStorageState());
        if(!sdExist){
            System.out.println("SD card not exists!");
            return null;
        } 
        else{
        	String packageName = getApplicationContext().getPackageName();
            String dbDir=android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
            dbDir += "/" + packageName +"/database";
            String dbPath = dbDir+"/"+name;
            // dbPath = /storage/emulated/0/cn.candone.appstepfun/database/appstepfun_db
            
            //check if the database file exists
            File dirFile = new File(dbDir);
            if(!dirFile.exists()){
                dirFile.mkdirs();
            }
            
            boolean isFileCreateSuccess = false; 
            File dbFile = new File(dbPath);
            if(!dbFile.exists()){
                try {                    
                    isFileCreateSuccess = dbFile.createNewFile();
                } catch (IOException e) {
                	System.out.println("SDCardDatabaseContext: " +e.toString());
                }
            }
            else{     
                isFileCreateSuccess = true;
            }
            
            if(isFileCreateSuccess){
                return dbFile;
            }else{ 
                return null;
            }
        }
        
    }

    @Override
    public SQLiteDatabase openOrCreateDatabase(String name, int mode, 
            SQLiteDatabase.CursorFactory factory) {
        SQLiteDatabase result = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(name), null);
        return result;
    }
    
    @Override
    public SQLiteDatabase openOrCreateDatabase(String name, int mode, CursorFactory factory,
            DatabaseErrorHandler errorHandler) {
        SQLiteDatabase result = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(name), null);
        return result;
    }
}    
    

