package cn.candone.appstepfun;

import com.umeng.analytics.MobclickAgent;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class TrainingListsFragment extends Fragment{
	private final String mPageName = "TrainingListsFragment";
	
	private RelativeLayout mLayout1; 
	private RelativeLayout mLayout2; 
	private RelativeLayout mLayout3; 
	private RelativeLayout mLayout4; 
	
	public TrainingListsFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.training_list_fragment, container, false);

    	MainActivity mainAct = (MainActivity) getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_TRAINING);
        }		
		
        int status1 = mainAct.GetPlanStatus("���������ȼƻ�");
        int status2 = mainAct.GetPlanStatus("�����߿����ƻ�");
        int status3 = mainAct.GetPlanStatus("��������ǿ�ƻ�");
        int status4 = mainAct.GetPlanStatus("�����߱��ּƻ�");
        
        ImageView planImage1 = (ImageView) rootView.findViewById(R.id.imagePlan1);
        ImageView planImage2 = (ImageView) rootView.findViewById(R.id.imagePlan2);
        ImageView planImage3 = (ImageView) rootView.findViewById(R.id.imagePlan3);
        ImageView planImage4 = (ImageView) rootView.findViewById(R.id.imagePlan4);
        
        if(status1 == TrainingFragment.PLAN_NOTSTARTED){
        	planImage1.setImageResource(R.drawable.exercise_notstart);
        }else if(status1 == TrainingFragment.PLAN_INPROGRESS){
        	planImage1.setImageResource(R.drawable.exercise_ongoing);
        }else if(status1 == TrainingFragment.PLAN_INPROGRESS){
        	planImage1.setImageResource(R.drawable.exercise_done);
        }else{
        	planImage1.setImageResource(R.drawable.exercise_notstart);
        }
        
        if(status2 == TrainingFragment.PLAN_NOTSTARTED){
        	planImage2.setImageResource(R.drawable.exercise_notstart);
        }else if(status2 == TrainingFragment.PLAN_INPROGRESS){
        	planImage2.setImageResource(R.drawable.exercise_ongoing);
        }else if(status2 == TrainingFragment.PLAN_INPROGRESS){
        	planImage2.setImageResource(R.drawable.exercise_done);
        }else{
        	planImage2.setImageResource(R.drawable.exercise_notstart);
        }

        if(status3 == TrainingFragment.PLAN_NOTSTARTED){
        	planImage3.setImageResource(R.drawable.exercise_notstart);
        }else if(status3 == TrainingFragment.PLAN_INPROGRESS){
        	planImage3.setImageResource(R.drawable.exercise_ongoing);
        }else if(status3 == TrainingFragment.PLAN_INPROGRESS){
        	planImage3.setImageResource(R.drawable.exercise_done);
        }else{
        	planImage3.setImageResource(R.drawable.exercise_notstart);
        }

        if(status4 == TrainingFragment.PLAN_NOTSTARTED){
        	planImage4.setImageResource(R.drawable.exercise_notstart);
        }else if(status4 == TrainingFragment.PLAN_INPROGRESS){
        	planImage4.setImageResource(R.drawable.exercise_ongoing);
        }else if(status4 == TrainingFragment.PLAN_INPROGRESS){
        	planImage4.setImageResource(R.drawable.exercise_done);
        }else{
        	planImage4.setImageResource(R.drawable.exercise_notstart);
        }
        
        mLayout1 = (RelativeLayout)rootView.findViewById(R.id.planItem1);
        mLayout1.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	  switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mLayout1.setBackgroundResource(R.color.whitesmoke);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mLayout1.setBackgroundResource(R.color.white);
	    	            break;
	    	        default:
	    	            break;
	    	    }
			    return false;
			}
		});
        mLayout1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity mainAct = (MainActivity)getActivity();
				mainAct.mPerfData.setCurrentPlans("���������ȼƻ�");
				mainAct.ReturnToPrevFragment();
			}
		});

        mLayout2 = (RelativeLayout)rootView.findViewById(R.id.planItem2);
        mLayout2.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	  switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mLayout2.setBackgroundResource(R.color.whitesmoke);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mLayout2.setBackgroundResource(R.color.white);
	    	            break;
	    	        default:
	    	            break;
	    	    }
			    return false;
			}
		});
        mLayout2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity mainAct = (MainActivity)getActivity();
				mainAct.mPerfData.setCurrentPlans("�����߿����ƻ�");
				mainAct.ReturnToPrevFragment();
			}
		});
        
        mLayout3 = (RelativeLayout)rootView.findViewById(R.id.planItem3);
        mLayout3.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	  switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mLayout3.setBackgroundResource(R.color.whitesmoke);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mLayout3.setBackgroundResource(R.color.white);
	    	            break;
	    	        default:
	    	            break;
	    	    }
			    return false;
			}
		});
        mLayout3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity mainAct = (MainActivity)getActivity();
				mainAct.mPerfData.setCurrentPlans("��������ǿ�ƻ�");
				mainAct.ReturnToPrevFragment();
			}
		});
        
        mLayout4 = (RelativeLayout)rootView.findViewById(R.id.planItem4);
        mLayout4.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
		    	  switch (event.getAction()) { 	  
	    	        case MotionEvent.ACTION_DOWN:
	    	        	mLayout4.setBackgroundResource(R.color.whitesmoke);
	    	            break;
	    	        case MotionEvent.ACTION_CANCEL:
	    	        case MotionEvent.ACTION_UP:
	    	        	mLayout4.setBackgroundResource(R.color.white);
	    	            break;
	    	        default:
	    	            break;
	    	    }
			    return false;
			}
		});
        mLayout4.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity mainAct = (MainActivity)getActivity();
				mainAct.mPerfData.setCurrentPlans("�����߱��ּƻ�");
				mainAct.ReturnToPrevFragment();
			}
		});
        
        return rootView;
	}
    
    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
	
}
