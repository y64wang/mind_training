package cn.candone.appstepfun;

import java.util.Comparator;

import org.json.JSONObject;

public  class PedoDataSortComparator implements Comparator{
    @Override  
    public int compare(Object lhs, Object rhs) {  
        JSONObject a = (JSONObject) lhs;  
        JSONObject b = (JSONObject) rhs;
        
        int aStep;
		try {
			aStep = Integer.parseInt(a.getString("steps"));
		} catch (Exception e) {
			aStep = 0;
		}
        int bStep;
		try {
			bStep = Integer.parseInt(b.getString("steps"));
		} catch (Exception e) {
			bStep = 0;
		}
  
        return (bStep - aStep);  
    }
} 