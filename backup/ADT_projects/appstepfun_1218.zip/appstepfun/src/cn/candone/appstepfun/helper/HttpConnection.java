package cn.candone.appstepfun.helper;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class HttpConnection implements Runnable {

	public static final String STRING_NETWORK_FAIL="�������粻����";
	public static final String SERVER_URL="http://121.40.80.143:2014/client/api";
	
	public static final int DID_START = 0;
	public static final int DID_ERROR = 1;
	public static final int DID_SUCCEED = 2;
	
	private static final int GET = 0;
	private static final int POST = 1;
	private static final int PUT = 2;
	private static final int DELETE = 3;
	private static final int BITMAP = 4;
	
	private String mUrl;
	private int mMethod;
	private String mData;
	private CallbackListener mListener;
	
	private HttpClient mHttpClient;

	// public HttpConnection() {
	// this(new Handler());
	// }

	public void create(int method, String url, String data, CallbackListener listener) {
		this.mMethod = method;
		this.mUrl = url;
		this.mData = data;
		this.mListener = listener;
		ConnectionManager.getInstance().push(this);
	}
	
	public void get(String url, CallbackListener listener) {
		create(GET, url, null, listener);
	}
	
	public void post(String url, String data, CallbackListener listener) {
		create(POST, url, data, listener);
	}
	
	public void put(String url, String data, CallbackListener listener) {
		create(PUT, url, data, listener);
	}
	
	public void delete(String url, CallbackListener listener) {
		create(DELETE, url, null, listener);
	}
	
	public void bitmap(String url, CallbackListener listener) {
		create(BITMAP, url, null, listener);
	}
	
	public interface CallbackListener {
		public void callBack(String result);
	}
	
	private static final Handler handler = new Handler() {
		@Override
		public void handleMessage(Message message) {
			switch (message.what) {
				case HttpConnection.DID_START: {
					break;
				}
				case HttpConnection.DID_SUCCEED: {
					CallbackListener listener = (CallbackListener) message.obj;
					Object data = message.getData();
					if (listener != null) {
						if(data != null) {
							Bundle bundle = (Bundle)data;
							String result = bundle.getString("result");
							listener.callBack(result);
						}
					}
					break;
				}
				case HttpConnection.DID_ERROR: {
					break;
				}
			}
		}
	};

	public void run() {
	//	handler.sendMessage(Message.obtain(handler, HttpConnection.DID_START));
		mHttpClient = getHttpClient();
		try {
			HttpResponse httpResponse = null;
			switch (mMethod) {
			case GET:
				httpResponse = mHttpClient.execute(new HttpGet(SERVER_URL + mUrl));
			
				if(isHttpSuccessExecuted(httpResponse)) {
					BufferedReader br = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));
					String line, result = "";
					while ((line = br.readLine()) != null)
						result += line;
					
					this.sendMessage(result);
				}else{
					this.sendMessage("fail");
				}
				break;
			case POST:
				HttpPost httpPost = new HttpPost(SERVER_URL + mUrl);
				httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
				
				httpPost.setEntity(new StringEntity(mData, HTTP.UTF_8));

				httpResponse = mHttpClient.execute(httpPost);
				if (isHttpSuccessExecuted(httpResponse)) {
					String result = EntityUtils.toString(httpResponse.getEntity(), HTTP.UTF_8);
					this.sendMessage(result);
				}else{
					this.sendMessage("fail");
				}
				break;
			/**
			case BITMAP:
				mHttpClient = getCachingHttpClient();
				
				HttpContext localContext = new BasicHttpContext();
				HttpGet httpGet = new HttpGet(mUrl);
				httpResponse = mHttpClient.execute(httpGet, localContext); 
				CacheResponseStatus responseStatus = (CacheResponseStatus) localContext.getAttribute(
						CachingHttpClient.CACHE_RESPONSE_STATUS);
				switch (responseStatus) {
				case CACHE_HIT:
				System.out.println("A response was generated from the cache with no requests " +
				"sent upstream");
				break;
				case CACHE_MODULE_RESPONSE:
				System.out.println("The response was generated directly by the caching module");
				break;
				case CACHE_MISS:
				System.out.println("The response came from an upstream server");
				break;
				case VALIDATED:
				System.out.println("The response was generated from the cache after validating " +
				"the entry with the origin server");
				break;
				}
				if (isHttpSuccessExecuted(httpResponse)) {
					BufferedHttpEntity bufHttpEntity = new BufferedHttpEntity(httpResponse.getEntity());
					Bitmap bm = BitmapFactory.decodeStream(bufHttpEntity.getContent());
					this.sendMessage("success", bm);
				}else{
					this.sendMessage("fail", null);
				}
				break;
			**/
			}
		} catch (Exception e) {
			this.sendMessage("fail");
			System.out.println(e.toString());
		}
		ConnectionManager.getInstance().didComplete(this);
	}

	private void sendMessage(String result){
		Message message = Message.obtain(handler, DID_SUCCEED,
				mListener);
		Bundle data = new Bundle();
		data.putString("result", result);
		message.setData(data);
		handler.sendMessage(message);
	}
	
	public HttpClient getHttpClient() {
		HttpParams httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, 10000);
		HttpConnectionParams.setSoTimeout(httpParams, 10000);
		if(mMethod == BITMAP){
			HttpConnectionParams.setSocketBufferSize(httpParams, 8192);
		}
		
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParams);
		return httpClient;
	}

	/**
	public HttpClient getCachingHttpClient() {
		CacheConfig cacheConfig = new CacheConfig();
		cacheConfig.setMaxCacheEntries(100);
		cacheConfig.setMaxObjectSizeBytes(8192);
		HttpClient httpClient = new CachingHttpClient(new DefaultHttpClient(), cacheConfig);
		
		return httpClient;
	}
	**/
	public static boolean isHttpSuccessExecuted(HttpResponse response) {
		int statusCode = response.getStatusLine().getStatusCode();
		return (statusCode > 199) && (statusCode < 400);
	}

}
