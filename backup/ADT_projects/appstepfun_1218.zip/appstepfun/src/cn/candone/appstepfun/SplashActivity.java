package cn.candone.appstepfun;

import org.json.JSONException;
import org.json.JSONObject;

import com.umeng.analytics.MobclickAgent;

import cn.candone.appstepfun.R;
import cn.candone.appstepfun.ThirdPartLoginActivity;
import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class SplashActivity extends Activity {
	private final  String mPageName = "SplashActivity";	
    private final int SPLASH_DISPLAY_LENGHT = 2000; // �ӳ�1�� 
    
    private PreferencesData mPrefData;
    
    @Override  
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.splash_activity);  
  
        mPrefData = (PreferencesData) getApplicationContext();

        new Handler().postDelayed(new Runnable() {  
            public void run() {
                Intent mainIntent = new Intent();  
            	if(mPrefData.getLoginMode() == PreferencesData.LOGIN_NONE){
	                mainIntent.setClass(SplashActivity.this,  
	                		ThirdPartLoginActivity.class);
            	}else{
	                mainIntent.setClass(SplashActivity.this,  
                        MainActivity.class);
            	}
                SplashActivity.this.startActivity(mainIntent);  
                SplashActivity.this.finish();  
            }  
  
        }, SPLASH_DISPLAY_LENGHT);  
  
        mPrefData.LoadUserLoginInfo();
        
        System.out.println("LoginMode: "+ mPrefData.getLoginMode());
        System.out.println("userId: "+ mPrefData.getUserID());
        if(mPrefData.getLoginMode() != PreferencesData.LOGIN_NONE && mPrefData.getUserID().equals("")){
        	String postStr = ThirdPartLoginActivity.PrepareThridPartLoginString(mPrefData.getLoginMode(),
        			mPrefData.getThirdPartID(), 
        			mPrefData.getUserName(), 
        			mPrefData.getUserIconUrl());
        	ExecuteLogin(postStr);
        }
    }  
    
    @Override
    protected void onResume() {
        super.onResume();
		MobclickAgent.onPageStart( mPageName );
		MobclickAgent.onResume(this);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
		MobclickAgent.onPageEnd( mPageName );
		MobclickAgent.onPause(this);
	}

	private CallbackListener callbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			//System.out.println("callBack: " + v);
			
			if(v.equals("fail")) {
				Toast.makeText(SplashActivity.this, HttpConnection.STRING_NETWORK_FAIL, Toast.LENGTH_SHORT).show();
				System.out.println("http response error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success","userId":"53a008fb9f68f41988fb4897",
				 *  "userName":"RobinNewName2"}
				 *  
				 *  {"result":"failed","reason":"user Not exist!"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
				    	mPrefData.setUserID(obj.getString("userId"));
				    	mPrefData.UpdateUserID();
						System.out.println("appstepfun login successfully!");
					}else{
						String reason = obj.getString("reason");
						System.out.println("appstepfun login failed: " + reason);
					}
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//progressDialog.dismiss();
		}
	};
		
    private void ExecuteLogin(String postStr) {
    	HttpConnection conn = new HttpConnection();
    	conn.post("/register/userlogin", postStr, callbackListener);
    }
    
}

