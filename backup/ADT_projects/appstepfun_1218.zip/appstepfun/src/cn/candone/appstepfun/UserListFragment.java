package cn.candone.appstepfun;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import cn.candone.appstepfun.graphview.GraphView;
import cn.candone.appstepfun.graphview.GraphViewDataInterface;
import cn.candone.appstepfun.graphview.GraphViewSeries;
import cn.candone.appstepfun.graphview.SimpleBarGraphView;
import cn.candone.appstepfun.graphview.ValueDependentColor;
import cn.candone.appstepfun.graphview.GraphView.GraphViewData;
import cn.candone.appstepfun.graphview.GraphViewSeries.GraphViewSeriesStyle;
import cn.candone.appstepfun.graphview.GraphViewStyle.GridStyle;
import cn.candone.appstepfun.widget.RefreshableView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class UserListFragment extends ListFragment {
	OnUserListFragmentCreatedListener mListCreatedListener;

	public ListView mUserListView;

	private PreferencesData mPrefData;
	private String mUserID = "";
	private GraphViewSeriesStyle mSeriesStyle;
	
	private DisplayImageOptions mImageLoaderOptions;
	private int mTarget = 0;
	
	public UserListFragment(){
	}

    public interface OnUserListFragmentCreatedListener {
        public void OnUserListFragmentCreated();
    }    
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.list, null);
		mPrefData = (PreferencesData) getActivity().getApplicationContext();
		mUserID = mPrefData.getUserID();
		
		mTarget = mPrefData.getSelectedGroupTarget();
		//System.out.println("Group target: " + mTarget);
		
		mUserListView = (ListView)rootView;

		mUserListView.setOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
			    switch (scrollState) {
			    case OnScrollListener.SCROLL_STATE_IDLE:
			    	MainActivity mainAct = (MainActivity) getActivity();
			    	UpdateHourStepsChart(mainAct.mPedoUserArray);

			     break;
			    } 
			} 
			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,int visibleItemCount, int totalItemCount) {}
			});

		mSeriesStyle = new GraphViewSeriesStyle();
		mSeriesStyle.setValueDependentColor(new ValueDependentColor() {
      	  //@Override
      	  //public int get(GraphViewDataInterface data) {
      	  //  return Color.CYAN;
      	  //}
      		
      	  @Override
    	  public int get(GraphViewDataInterface data, double max) {
    		if(max <= 0 ){ max = 10000;}
    		double valY = data.getY();
    		if(valY > max ){valY = max;}
    	    // the higher the more green
    	    return Color.rgb((int)((1.0f-valY/max)*255), 255, (int)((valY/max)*255));
      	  }
		});

		mImageLoaderOptions = new DisplayImageOptions.Builder()  
        .showImageOnLoading(R.drawable.app_default)
        .showImageForEmptyUri(R.drawable.app_default)  
        .showImageOnFail(R.drawable.app_default)
        .cacheInMemory(true)  
        .cacheOnDisk(true)
        .considerExifParams(true)
        //.imageScaleType(ImageScaleType.IN_SAMPLE_INT)
        .bitmapConfig(Bitmap.Config.RGB_565)  
        //.decodingOptions(android.graphics.BitmapFactory.Options decodingOptions)//����ͼƬ�Ľ�������  
        //.delayBeforeLoading(1000)   //int delayInMillisΪ�����õ�����ǰ���ӳ�ʱ��
        //����ͼƬ���뻺��ǰ����bitmap��������  
        //.preProcessor(BitmapProcessor preProcessor)  
        //.resetViewBeforeLoading(true)//����ͼƬ������ǰ�Ƿ����ã���λ  
        .displayer(new RoundedBitmapDisplayer(180)) // round conner
        .handler(new Handler())
        .build();
    	
		return rootView;
	}

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
        	mListCreatedListener = (OnUserListFragmentCreatedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnListFragmentCreatedListener");
        }
    }
    
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}
    
	@Override
	public void onResume(){
		super.onResume();
    	if(mListCreatedListener != null){
    		mListCreatedListener.OnUserListFragmentCreated();
    	}
	}

	@Override
	public void onDestroy(){
    	ImageLoader.getInstance().stop();
    	super.onDestroy();
	}
	
	private class UserItem {
		public String userId;
		public String userName;
		public String iconUrl;
		public int sequence;
		public String steps;
		public int[] hourStepsArray;
		
		public UserItem(String userId, String userName, String iconUrl,
				       int sequence, String steps, int[] stepsarray) {
			this.userId = userId;
			this.userName = userName;
			this.iconUrl = iconUrl;
			this.sequence = sequence;
			this.steps = steps;
			this.hourStepsArray = stepsarray;
		}
		
	}

	public class UserAdapter extends ArrayAdapter<UserItem> {

		public UserAdapter(Context context) {
			super(context, 0);

		}

		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = LayoutInflater.from(getContext()).inflate(R.layout.users_row, null);
			}
			
			ImageView iconIV = (ImageView) convertView.findViewById(R.id.userrow_icon);
			TextView userNameTV = (TextView) convertView.findViewById(R.id.userrow_name);
			TextView sequenceTV = (TextView) convertView.findViewById(R.id.userrow_seq);
			TextView stepsTV = (TextView) convertView.findViewById(R.id.userrow_steps);
			LinearLayout chartLayout = (LinearLayout) convertView.findViewById(R.id.userrow_chart);
			
			String steps = getItem(position).steps;
			String userId= getItem(position).userId;

			displayHeadImage(getItem(position).iconUrl, iconIV);
			if(userId.equals(mUserID)){
				userNameTV.setText("��");
			}else{
				userNameTV.setText(getItem(position).userName);
			}
			if(steps.equals("0")){
				sequenceTV.setText("");
			}else{
				String sequenceStr;
				int seqInt = getItem(position).sequence;
				switch(seqInt){
				case 0:
					sequenceStr = "�ھ�";
					break;
				case 1:
					sequenceStr = "�Ǿ�";
					break;
				case 2:
					sequenceStr = "����";
					break;
				default:
					sequenceStr = "��" + (seqInt + 1);
				} 					
				sequenceTV.setText(sequenceStr);
			}
			
			stepsTV.setText(steps);
			
			// user steps chart
			GraphView gView = null;
			GraphViewSeries hourStepSeries = null;
			boolean needupdatechart = false;
			if(chartLayout.getChildCount() > 0){
				gView = (GraphView)chartLayout.getChildAt(0);
				hourStepSeries = gView.getSeries(0);
				
				if(hourStepSeries != null){
					if(!hourStepSeries.getDescription().equals(userId)){
						needupdatechart = true;
					}
				}
			}else{
				needupdatechart = true;
			}
				
			if(needupdatechart){
				chartLayout.removeAllViews();
				
				//if(parent.getChildCount() == position)
				{
					if(getItem(position).hourStepsArray != null && !steps.equals("0")){
						//System.out.println(getItem(position).hourStepsArray.toString());
						
						GraphViewData[] graphDataSet = new GraphViewData[24];
		
						for(int i=0; i<24; i++){
							graphDataSet[i] = new GraphViewData(i, getItem(position).hourStepsArray[i]);
						}
		
						hourStepSeries = new GraphViewSeries(userId, mSeriesStyle, graphDataSet);
						// graph with dynamically genereated horizontal and vertical labels
						gView = new SimpleBarGraphView(
						            getActivity(), // context
						            "" // heading
						        );
						((SimpleBarGraphView) gView).setDrawValuesOnTop(false);
						((SimpleBarGraphView) gView).setDrawTargetBar(true);
						((SimpleBarGraphView) gView).setManualYAxis(false);
						((SimpleBarGraphView) gView).setManualMaxY(true);
						((SimpleBarGraphView) gView).setShowVerticalLabels(false);
						((SimpleBarGraphView) gView).setManualYAxisBounds(mTarget, 0d);
						   
						// custom static labels
						gView.setHorizontalLabels(new String[] {"","","","","","","6","","","9","","","12","","","15","","","18","","","21","",""});
						//gView.setVerticalLabels(new String[] {""});
						gView.getGraphViewStyle().setGridStyle(GridStyle.NONE);
						gView.getGraphViewStyle().setHorizontalLabelsColor(Color.LTGRAY);
						gView.getGraphViewStyle().setTextScaleSize(9);
						gView.addSeries(hourStepSeries); // data
		
				        chartLayout.addView(gView);
					}
				}
			}
			return convertView;
		}
	}

	
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		super.onListItemClick(l, v, position, id);
	}

	public void SetUserListAdapter(JSONArray userArray){
		
		if(userArray != null){
			int userCount = userArray.length();
			
			if(userCount>0){
				
				MainActivity mainAct = (MainActivity)getActivity();
				
				int pedoUserCount = 0;
				if(mainAct.mPedoUserArray != null){
					pedoUserCount = mainAct.mPedoUserArray.length();
				}
				
				try {
					
					int myposition = 0;
					UserAdapter adapter = new UserAdapter(getActivity());
					for(int i=0; i<userCount; i++){

						JSONObject userEntry = userArray.getJSONObject(i);
						String userId = userEntry.getString("userId");
						if(userId.equals(mainAct.mPerfData.getUserID())){
							myposition = i;
						}
						
						String userName = userEntry.getString("userName");
						String userIcon;
						if(userEntry.has("photoUrl")){
							userIcon = userEntry.getString("photoUrl");
							if(userIcon.toLowerCase().startsWith("http://localhost")){
								userIcon = "";
							}								
						}else{
							userIcon = "";
						}
						String steps = userEntry.getString("steps");
	
						int[] stepsArray = new int[24];
						for(int k=0; k<24; k++){
							stepsArray[k] = 0;
						}
						
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getResources().getConfiguration().locale);
						for(int j=0; j<pedoUserCount; j++){
							JSONObject pedoEntry = mainAct.mPedoUserArray.getJSONObject(j);
							String pedoUserID = pedoEntry.getString("userId");
							if(pedoUserID.equals(userId)){
								String pedoDateStr = pedoEntry.getString("date");
								String pedoStepsStr = pedoEntry.getString("steps");

								Date pedoDate = formatter.parse(pedoDateStr);
								Calendar cd = Calendar.getInstance();
								cd.setTime(pedoDate);
								int pedoHour = cd.get(Calendar.HOUR_OF_DAY);
								int pedoStep = Integer.valueOf(pedoStepsStr);
								
								if(pedoHour>=0 && pedoHour<24){
									stepsArray[pedoHour] = pedoStep;
									//System.out.println( pedoEntry.get("userName") + "hour: " + pedoHour + " step: " + pedoStep);
								}
							}
						}
						
						adapter.add(new UserItem(userId, userName, userIcon, 
								i, steps, stepsArray));
					}
					
					//getListView().addFooterView(mUserListVew);
					setListAdapter(adapter);
					getListView().setSelection(myposition);
					
				} catch (Exception e) {
					System.out.println("UserListFragment: " + e.toString());
				}
			}
		}
	}
	
	public void UpdateHourStepsChart(JSONArray userPedoArray){
		if(mUserListView != null && userPedoArray != null){
			int pedoCount = userPedoArray.length();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getResources().getConfiguration().locale);
			
			int listCount = mUserListView.getCount();
			try {
				for(int ind=0; ind<listCount; ind++){
					UserItem item= (UserItem)mUserListView.getItemAtPosition(ind);
					for(int i=0; i<pedoCount; i++){
						JSONObject userPedoEntry = userPedoArray.getJSONObject(i);
						String userId = userPedoEntry.getString("userId");
						if(userId.equals(item.userId)){
							String pedoDateStr = userPedoEntry.getString("date");
							String pedoStepsStr = userPedoEntry.getString("steps");

							Date pedoDate = formatter.parse(pedoDateStr);
							Calendar cd = Calendar.getInstance();
							cd.setTime(pedoDate);
							int pedoHour = cd.get(Calendar.HOUR_OF_DAY);
							int pedoStep = Integer.valueOf(pedoStepsStr);
							
							if(pedoHour>=0 && pedoHour<24){
								item.hourStepsArray[pedoHour] = pedoStep;
								//System.out.println(userPedoEntry.getString("date") + " " + pedoHour + " : " + pedoStep);
							}
						}
					}
				}
			} catch (Exception e) {
				System.out.println("UpdateHourStepsChart: " + e.toString());
			}
			UserAdapter adpter = (UserAdapter) mUserListView.getAdapter();
	        adpter.notifyDataSetChanged();
		}
	}
    private void displayHeadImage(String url, ImageView imgView){
    	ImageLoader.getInstance().displayImage(url, imgView, mImageLoaderOptions);
    }
}