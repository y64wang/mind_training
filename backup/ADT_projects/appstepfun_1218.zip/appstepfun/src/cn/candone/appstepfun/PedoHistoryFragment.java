package cn.candone.appstepfun;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.umeng.analytics.MobclickAgent;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import cn.candone.appstepfun.R;
import cn.candone.appstepfun.graphview.BarGraphView;
import cn.candone.appstepfun.graphview.SimpleBarGraphView;
import cn.candone.appstepfun.graphview.GraphView;
import cn.candone.appstepfun.graphview.GraphView.GraphViewData;
import cn.candone.appstepfun.graphview.GraphViewDataInterface;
import cn.candone.appstepfun.graphview.GraphViewSeries;
import cn.candone.appstepfun.graphview.GraphViewSeries.GraphViewSeriesStyle;
import cn.candone.appstepfun.graphview.GraphViewStyle.GridStyle;
import cn.candone.appstepfun.graphview.ValueDependentColor;
import cn.candone.appstepfun.helper.StepFunDBHelper;
import cn.candone.appstepfun.helper.SDCardDatabaseContext;
import cn.candone.appstepfun.widget.RoundRndProgressBar;

public class PedoHistoryFragment  extends Fragment {
	private final String mPageName = "PedoHistoryFragment";

    private LinearLayout mChartLayout;
    private Date mDisplayDate;
    private TextView mDateTV;
    private ImageView mBackButton;
    private ImageView mForwardButton;
    
    private TextView mIndicationV;
    private TextView mStepsV;

    private int mHourSteps[];
    private int mTotoalSteps;
    
    public PedoHistoryFragment() {
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        mHourSteps = new int[24];
        mTotoalSteps = 0;
        
    	View rootView = inflater.inflate(R.layout.pedo_history_fragment, container, false);

    	MainActivity mainAct = (MainActivity)getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_DISABLED);
        	//mainAct.getSupportActionBar().setTitle(MainActivity.BARTITLE_PEDO);
        	mainAct.mActionBarTitle.setText(MainActivity.BARTITLE_PEDOHISTORY);
        }
    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
        
        mDateTV = (TextView) rootView.findViewById(R.id.pedo_history_date);
    	mChartLayout = (LinearLayout) rootView.findViewById(R.id.pedo_history_chart);
    	
        		
    	Calendar cd=Calendar.getInstance();
    	mDisplayDate = cd.getTime();
    	

    	mIndicationV = (TextView)rootView.findViewById(R.id.pedo_history_indication);
    	mStepsV = (TextView)rootView.findViewById(R.id.pedo_history_hourSteps);

    	
    	mBackButton = (ImageView)rootView.findViewById(R.id.pedo_history_backbutton);
    	mBackButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Calendar cd=Calendar.getInstance();
				cd.setTime(mDisplayDate);
				cd.add(Calendar.DAY_OF_MONTH, -1);
				
				mDisplayDate = cd.getTime();
				CreateBarChartForDate();
			}
		});
    	
    	mForwardButton = (ImageView)rootView.findViewById(R.id.pedo_history_forwardbutton);
    	mForwardButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Calendar cd=Calendar.getInstance();
				cd.setTime(mDisplayDate);
				cd.add(Calendar.DAY_OF_MONTH, 1);
				
				mDisplayDate = cd.getTime();
				CreateBarChartForDate();
			}
		});
        
    	mChartLayout.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				
				if(mChartLayout.getChildCount() == 2){
					if((event.getAction() & MotionEvent.ACTION_DOWN) == MotionEvent.ACTION_DOWN){
						float eventX = event.getX();
						float eventY = event.getY();

						View chartV = mChartLayout.getChildAt(1);
						float chartX = chartV.getX();
						float chartY = chartV.getY();
						
						if(eventX > chartX && eventX < (chartX +chartV.getWidth()) && 
								eventY > chartY && eventY < (chartY + chartV.getHeight())){
							float colwidth = chartV.getWidth() / 24;
							int col_x = (int)((event.getX() - chartX) / colwidth);
							if(col_x > 23){ col_x = 23;}
							if(col_x < 0){col_x = 0;}
							OnHourSelected(col_x);
						}
					}
				}
				return false;
			}
		});
    	
    	CreateBarChartForDate();

    	return rootView;
    }

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	    
    @Override
	public void onDestroy(){
		super.onDestroy();
    	MainActivity mainAct = (MainActivity) getActivity();

    	SlidingMenu sm = mainAct.getSlidingMenu();
		sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);

	}    

    private void OnHourSelected(int x){
    	mIndicationV.setText(x + "ʱ");
    	mStepsV.setText(mHourSteps[x] + "��");
    }
    
    private void CreateBarChartForDate(){
    	
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", getResources().getConfiguration().locale);       
       	String date = formatter.format(mDisplayDate);
       	mDateTV.setText(date);
       	
    	Calendar cd = Calendar.getInstance();
    	cd.setTime(mDisplayDate);
    	
    	cd.set(Calendar.HOUR_OF_DAY, 1);
    	cd.set(Calendar.MINUTE, 0);
    	cd.set(Calendar.SECOND, 0);
    	cd.set(Calendar.MILLISECOND, 0);
    	
    	Date startDate = cd.getTime();
    	
    	cd.add(Calendar.DAY_OF_MONTH, 1);
    	Date endDate = cd.getTime();
    	
    	MainActivity mainAct = (MainActivity)getActivity();
       	Cursor cur = StepFunDBHelper.select_StepHistory(mainAct.getBaseContext(), mainAct.mPerfData.getUserID(), startDate, endDate);
       	int totalSteps[] = new int[24];
       	try{
	       	if(cur.getCount() == 0){
	       		Toast.makeText(getActivity(), "û�м�¼", Toast.LENGTH_SHORT).show();
	       	}
	      	
	       	while(cur.moveToNext()){
	       		long longDate = cur.getLong(StepFunDBHelper.COL_STEPHISTORY_DATE);
	       		Date dt = new Date(longDate);
	       		int stepsHour = dt.getHours() - 1;
	       		int entrySteps = cur.getInt(StepFunDBHelper.COL_STEPHISTORY_STEPS);
	
	       		//System.out.println("date: " + dt.toLocaleString() + " steps: " + entrySteps);
	       		if(stepsHour < 0){
	       			stepsHour = 23;
	       		}
	       		totalSteps[stepsHour] = entrySteps;
	       	}
       	}finally{
       		cur.close();
       	}
       	
       	mTotoalSteps = 0;
       	for(int i=0; i<24; i++){
       		mHourSteps[i] = 0;
       	}
       	
       	mHourSteps[0] = totalSteps[0];
       	int preHour = 0;
       	for(int i=1; i<24; i++){
       		int step = totalSteps[i] - totalSteps[preHour];
       		if(step > 0){
       			mHourSteps[i] = step;
       			mTotoalSteps = totalSteps[i];
       			preHour = i;
       		}else{
       			mHourSteps[i] = 0;
       		}
       	}
       	
      	GraphViewData[] graphDataSet = new GraphViewData[24];
      	for(int i=0; i<24; i++){
      		graphDataSet[i] = new GraphViewData(i, mHourSteps[i]);
      	}
       	
    	GraphViewSeriesStyle seriesStyle = new GraphViewSeriesStyle();
      	seriesStyle.setValueDependentColor(new ValueDependentColor() {
      	  //@Override
      	  //public int get(GraphViewDataInterface data) {
      	  //  return Color.CYAN;
      	  //}
      		
      	  @Override
    	  public int get(GraphViewDataInterface data, double max) {
    		
    	    int valX = (int)data.getX();
    	    int color = ((valX & 1) == 1)?(MainActivity.COLOR_SKYBLUE):(MainActivity.COLOR_ORANGE);
    	    return color;
    	  }
    	});

       	GraphViewSeries hourStepSeries = new GraphViewSeries("HourSteps", seriesStyle, graphDataSet);

        // graph with dynamically genereated horizontal and vertical labels
        GraphView graphView = new SimpleBarGraphView(
                    getActivity(), // context
                    "" // heading
            );
       ((SimpleBarGraphView) graphView).setDrawValuesOnTop(true);
       ((SimpleBarGraphView) graphView).setValueUnit("��");
       ((SimpleBarGraphView) graphView).setValuesOnTopColor(getResources().getColor(R.color.orange));
       ((SimpleBarGraphView) graphView).setShowVerticalLabels(false);
       ((SimpleBarGraphView) graphView).setManualYAxis(false);

        // custom static labels
        graphView.setHorizontalLabels(new String[] {"0","","","","","","","","","","","","","","","","","","","","","","","23"});
        graphView.setVerticalLabels(new String[] {""});
        graphView.getGraphViewStyle().setGridStyle(GridStyle.NONE);
        graphView.getGraphViewStyle().setHorizontalLabelsColor(MainActivity.COLOR_SKYBLUE);
        graphView.getGraphViewStyle().setTextScaleSize(14);
        graphView.getGraphViewStyle().setBackgroundColor(getResources().getColor(R.color.gray));
        graphView.addSeries(hourStepSeries); // data
    
        if(mChartLayout.getChildCount() == 2){
        	mChartLayout.removeViewAt(1);
        }
        mChartLayout.addView(graphView);
        
    	mIndicationV.setText("����");
    	mStepsV.setText(mTotoalSteps + "��");
    }
}
