package cn.candone.appstepfun;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.umeng.analytics.MobclickAgent;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import cn.candone.appstepfun.widget.RefreshableView;
import cn.candone.appstepfun.widget.RefreshableView.PullToRefreshListener;

public class GroupDetailFragment extends Fragment{
	private final String mPageName = "GroupDetailFragment";
	
	public UserListFragment mUserListFragment;
	private RefreshableView mRefreshableView;
	private boolean mUpdateResult = true;

	private Button mHideButton;
	private PreferencesData mPrefData;
	
	private String mGroupName = "";
	private String mUserArrayStr = "";
	
	private JSONArray mUserArray = new JSONArray();

	private boolean mIsGroupHide = false;
	
    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.users_fragment, container, false);

		MainActivity mainAct = (MainActivity)getActivity();
        mPrefData = (PreferencesData) mainAct.getApplicationContext();
		mGroupName = mPrefData.getSelectedGroupName();

		if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_GROUP_QUIT);
        	//mainAct.getSupportActionBar().setTitle(mGroupName);
        	mainAct.mActionBarTitle.setText(MainActivity.GetRealGroupName(mGroupName));
        }
        
		FragmentTransaction t = mainAct.getSupportFragmentManager().beginTransaction();
		mUserListFragment = new UserListFragment();
		t.replace(R.id.group_userlist, mUserListFragment);
		t.commit();

		if(!mGroupName.equals("")){
			mUserArrayStr = mPrefData.LoadGroupUsersInfo(mGroupName);
			
			if(!mUserArrayStr.equals("")){
				try {
					mUserArray = new JSONArray(mUserArrayStr);
					//System.out.println(mUserArray.toString());
					
				} catch (JSONException e) {
					System.out.println("GroupDetailFragment: JSONArray mUserArray create failed.");
				}
			}
		}
		
    	mHideButton = (Button)rootView.findViewById(R.id.hideButton);
    	mHideButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(mIsGroupHide){
					RemoveHideGroup(mGroupName);
    				mIsGroupHide = false;
					mHideButton.setTextColor(getResources().getColor(R.color.deepskyblue));
					mHideButton.setBackgroundResource(R.drawable.oval_blue_white);
					
					//inform pedo service to update groupinfo.
					MainActivity mainAct = (MainActivity)getActivity();
					mainAct.sendUpdateReportJSONCmd();
				}else{
					mIsGroupHide = true;
					mHideButton.setTextColor(getResources().getColor(R.color.white));
					mHideButton.setBackgroundResource(R.drawable.oval_blue_skyblue);
					
		            AlertDialog isHide = new AlertDialog.Builder(getActivity()).create();  
		            isHide.setTitle("��ʾ");
		            isHide.setMessage("���������ѽ��ῴ����������³ɼ���");  
		            isHide.setButton("ȷ��", hideGroupListener);  
		            isHide.show();				
		        }

			}
		});
    	
    	mIsGroupHide = IsGroupHideState(mGroupName);
    	if(mIsGroupHide){
			mHideButton.setTextColor(getResources().getColor(R.color.white));
			mHideButton.setBackgroundResource(R.drawable.oval_blue_skyblue);
    	}else{
			mHideButton.setTextColor(getResources().getColor(R.color.deepskyblue));
			mHideButton.setBackgroundResource(R.drawable.oval_blue_white);
    	}
		
        return rootView;
    }
    
    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
    @Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mRefreshableView = (RefreshableView) getActivity().findViewById(R.id.user_refreshableview);
        mRefreshableView.setOnRefreshListener(new PullToRefreshListener() {
			@Override
			public void onRefresh() {
				try {
					MainActivity mainAct = (MainActivity)getActivity();
					mainAct.ExecuteGetGroupPedo(false);
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mRefreshableView.finishRefreshing(mUpdateResult);
			}
		}, 0);    		
    

	}

    DialogInterface.OnClickListener hideGroupListener = new DialogInterface.OnClickListener()  
    {  
        public void onClick(DialogInterface dialog, int which)  
        {  
            switch (which)  
            {  
            case AlertDialog.BUTTON_POSITIVE:// "ȷ��"��ť�˳����� 
            	AddHideGroup(mGroupName);
            	
				//inform pedo service to update groupinfo.
				MainActivity mainAct = (MainActivity)getActivity();
				mainAct.sendUpdateReportJSONCmd();            	
                break;  
            default:  
                break;  
            }  
        }  
    };
    
    public void UpdateUserArray(JSONArray userArray){
    	if(userArray != null){
    		mUserArray = userArray;
    	}
    }

	public void SetUserListView(){
		if(mUserListFragment != null  && mUserArray != null){
			mUserListFragment.SetUserListAdapter(mUserArray);
		}
	}

	public void UpdateHourStepsChart(JSONArray userPedoArray){
		if(mUserListFragment != null){
			mUserListFragment.UpdateHourStepsChart(userPedoArray);
		}
	}
	
	public void SetListViewForRefreshView(){
		if(mRefreshableView != null && mUserListFragment.mUserListView !=null){
			mRefreshableView.setListView(mUserListFragment.mUserListView);
		}		
	}
	
	private boolean IsGroupHideState(String groupName){
		boolean isHideGroup = false;
		
		MainActivity mainAct = (MainActivity)getActivity();
		if(mainAct.mHideGroupArray != null){
			try {
				int hideGroupCount = mainAct.mHideGroupArray.length();
				for(int i=0; i<hideGroupCount; i++){
					JSONObject hidegroupEntry = mainAct.mHideGroupArray.getJSONObject(i);
					String hidegroupName = hidegroupEntry.getString("groupName");
					if(hidegroupName.equals(groupName)){
						isHideGroup = true;
						break;
					}
				}
			} catch (JSONException e) {
				System.out.println("CheckHideGroupState: " + e.toString());
			}
		}
		
		return isHideGroup;
	}

	private void AddHideGroup(String groupName){
		MainActivity mainAct = (MainActivity)getActivity();
		if(mainAct.mHideGroupArray != null){
			JSONObject hidegroupEntry = new JSONObject();
			try {
				hidegroupEntry.put("groupName", groupName);
				
				mainAct.mHideGroupArray.put(hidegroupEntry);
				mainAct.mPerfData.setHideGroup(mainAct.mHideGroupArray.toString());
			} catch (JSONException e) {
				System.out.println("AddHieGroup: " + e.toString());
			}
			
		}
	}
	
	private void RemoveHideGroup(String groupName){
		MainActivity mainAct = (MainActivity)getActivity();
		if(mainAct.mHideGroupArray != null){
			try {
				JSONArray newHideGroupArray = new JSONArray();
				int hideGroupCount = mainAct.mHideGroupArray.length();
				for(int i=0; i<hideGroupCount; i++){
					JSONObject hidegroupEntry = mainAct.mHideGroupArray.getJSONObject(i);
					String hidegroupName = hidegroupEntry.getString("groupName");
					if(!hidegroupName.equals(groupName)){
						newHideGroupArray.put(hidegroupEntry);
					}
				}
				mainAct.mHideGroupArray = newHideGroupArray;
				mainAct.mPerfData.setHideGroup(mainAct.mHideGroupArray.toString());
			} catch (JSONException e) {
				System.out.println("CheckHideGroupState: " + e.toString());
			}
		}
	}
}
