package cn.candone.appstepfun;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.umeng.analytics.MobclickAgent;

import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.SDCardDatabaseContext;
import cn.candone.appstepfun.helper.StepFunDBHelper;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class TrainingDetailFragment extends Fragment {
	private final String mPageName = "TrainingDetailFragment";
	
    private ExpandableListView mTrainingDetailListView;
	private TrainingExpandableListViewAdapter mAdapter;
	
	public TrainingDetailFragment() {
    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.plan_list_fragment, container, false);

    	MainActivity mainAct = (MainActivity) getActivity();
        if(mainAct.mActionBarMenu != null){
        	mainAct.mActionBarMenu.setText(MainActivity.MENUTITLE_RESTARTPLAN);
        	mainAct.mActionBarTitle.setText(mainAct.mPerfData.getCurrentPlans());
        }		
        mTrainingDetailListView = (ExpandableListView)rootView.findViewById(R.id.plan_expandablelist);
        mTrainingDetailListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
			
			@Override
			public boolean onGroupClick(ExpandableListView parent, View v,
					int groupPosition, long id) {

				ProgressBar b = (ProgressBar)v.getTag();
				//mAdapter.updateGroupData(groupPosition);
				return false;
			}
		});

        SetTrainingExpandableList();

		
		return rootView;
	}

    @Override
  	public void onPause() {
  		super.onPause();
  		MobclickAgent.onPageEnd(mPageName);
  	}
    
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(mPageName);
	}
	
	private int GetPedoDataByDate(Date date){
    	
    	Calendar cd = Calendar.getInstance();
    	cd.setTime(date);
    	
    	cd.set(Calendar.HOUR_OF_DAY, 1);
    	cd.set(Calendar.MINUTE, 0);
    	cd.set(Calendar.SECOND, 0);
    	cd.set(Calendar.MILLISECOND, 0);
    	
    	Date startDate = cd.getTime();
    	
    	cd.add(Calendar.DAY_OF_MONTH, 1);
    	Date endDate = cd.getTime();
    	
    	MainActivity mainAct = (MainActivity)getActivity();
       	Cursor cur = StepFunDBHelper.select_StepHistory(mainAct.getBaseContext(), mainAct.mPerfData.getUserID(), startDate, endDate);

       	int totalSteps[] = new int[24];
       	try{
	       	if(cur.getCount() == 0){
	       		return 0;
	       	}
	      	
	       	while(cur.moveToNext()){
	       		long longDate = cur.getLong(StepFunDBHelper.COL_STEPHISTORY_DATE);
	       		Date dt = new Date(longDate);
	       		int stepsHour = dt.getHours() - 1;
	       		int entrySteps = cur.getInt(StepFunDBHelper.COL_STEPHISTORY_STEPS);
	
	       		//System.out.println("date: " + dt.toLocaleString() + " steps: " + entrySteps);
	       		if(stepsHour < 0){
	       			stepsHour = 23;
	       		}
	       		totalSteps[stepsHour] = entrySteps;
	       	}
       	} finally{
       		cur.close();
       	}
       	
       	int lastTotalSteps = 0;
       	int hourSteps[] = new int[24];

       	hourSteps[0] = totalSteps[0];
       	int preHour = 0;
       	for(int i=1; i<24; i++){
       		int step = totalSteps[i] - totalSteps[preHour];
       		if(step > 0){
       			hourSteps[i] = step;
       			lastTotalSteps = totalSteps[i];
       			preHour = i;
       		}else{
       			hourSteps[i] = 0;
       		}
       	}
       	
       	return lastTotalSteps;
    }
    
	public void SetTrainingExpandableList(){
		
		MainActivity mainAct = (MainActivity) getActivity();
		JSONObject currntPlanEntry = null;
		try {
			
			int planCount = mainAct.mTrainArray.length();
			for(int i=0; i<planCount; i++){
				JSONObject planEntry = mainAct.mTrainArray.getJSONObject(i);
				String planName = planEntry.getString("planName");
				if(planName.equals(mainAct.mPerfData.getCurrentPlans())){
					currntPlanEntry = planEntry;
					break;
				}
			}
			
			if(currntPlanEntry == null){
				currntPlanEntry = new JSONObject();
				currntPlanEntry.put("planName", mainAct.mPerfData.getCurrentPlans());
				
				Calendar cd = Calendar.getInstance();
				currntPlanEntry.put("startDate", cd.getTimeInMillis());
				
				currntPlanEntry.put("planStatus", TrainingFragment.PLAN_INPROGRESS);
				
				mainAct.mTrainArray.put(currntPlanEntry);
				mainAct.mPerfData.setTrainingPlans(mainAct.mTrainArray.toString());
			}

        	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", getResources().getConfiguration().locale);       
	        Calendar cd = Calendar.getInstance();
	        String curDateStr = formatter.format(cd.getTime());

        	long startDateLong = currntPlanEntry.getLong("startDate");
	        cd.setTimeInMillis(startDateLong);
	        String dateStr = formatter.format(cd.getTime());
	        
 
	        List<List<Map<String, Object>>> trainingDays = new ArrayList<List<Map<String, Object>>>();
	        List<Map<String, String>> groupWeek = new ArrayList<Map<String, String>>();
	
	        Map<String, Object> dayItem;
	        List<Map<String, Object>> weekDays;
	        Map<String, String> groupWeekItem;
	        int targetSteps[];
	        int groupid = 0, childid = 0;
	        for(int week=0; week<4; week++){
	        	targetSteps = TrainingFragment.GetPlanTarget(mainAct.mPerfData.getCurrentPlans(), week);
	        	int weekTargetSteps = 0;
	        	int weekProgress = 0;
	        	
		        weekDays = new ArrayList<Map<String, Object>>();
		        for(int i=0; i<7; i++){
		        	dayItem = new HashMap<String, Object>();
		        	
		        	if(curDateStr.equals(dateStr)){
		        		dayItem.put("plan_day_name", "�������");
			        	dayItem.put("plan_day_progress", mainAct.mSteps + "��");
			        	weekProgress += mainAct.mSteps;
			        	groupid= week; childid = i;
		        	}else{
		        		int dayProgress = GetPedoDataByDate(cd.getTime());
		        		dayItem.put("plan_day_name", "��" + (i + 1 + week * 7) +"�����");
			        	dayItem.put("plan_day_progress", dayProgress + "��");
			        	//weekProgress += daySteps[i + week * 7];
			        	weekProgress += dayProgress;
		        	}
		        	dayItem.put("plan_day_target", targetSteps[i] + "��");
		        	dayItem.put("plan_day_date", dateStr);
		        	weekDays.add(dayItem);
		        	
		        	weekTargetSteps += targetSteps[i];
		        	
		        	cd.add(Calendar.DAY_OF_MONTH, 1);
		        	dateStr = formatter.format(cd.getTime());
		        }
		        
		        trainingDays.add(weekDays);
		        
	        	groupWeekItem = new HashMap<String, String>();
	        	groupWeekItem.put("plan_weekName", "��" + (week+1) + "/4��");
	            groupWeekItem.put("plan_weekprogress", weekProgress + "��");
	            groupWeekItem.put("plan_weektarget", weekTargetSteps + "��");
	            groupWeekItem.put("plan_weekProgressBarProgress", "" + weekProgress);
	            groupWeekItem.put("plan_weekProgressBarMax", "" + weekTargetSteps);
	        	groupWeek.add(groupWeekItem);
	        }
	        
	        String[] groupFrom = new String[]{"plan_weekName", "plan_weekprogress", "plan_weektarget", "plan_weekProgressBarProgress", "plan_weekProgressBarMax"};
	        int[] groupTo = new int[]{R.id.plan_weekName, R.id.plan_weekprogress, R.id.plan_weektarget, R.id.plan_weekProgressBar, R.id.plan_weekProgressBar};
	
	        String[] childFrom = new String[]{"plan_day_name", "plan_day_progress", "plan_day_target", "plan_day_date"};
	        int[] childTo = new int[]{R.id.plan_day_name, R.id.plan_day_progress, R.id.plan_day_target, R.id.plan_day_date};
	        
	        mAdapter = new TrainingExpandableListViewAdapter(mTrainingDetailListView.getContext(),
	        		groupWeek, R.layout.plan_week_row, groupFrom, groupTo, trainingDays, R.layout.plan_day_row,
					childFrom, childTo);
	        
	        mTrainingDetailListView.setAdapter(mAdapter);
	        mTrainingDetailListView.setSelectedChild(groupid, childid, true);
	        mTrainingDetailListView.expandGroup(groupid);
	        
		} catch (JSONException e) {
			System.out.println("SetTrainingExpandableList: " + e.toString());
		}
        
 	}
	
	
	public class TrainingExpandableListViewAdapter extends BaseExpandableListAdapter {

		private List<? extends Map<String, String>> mGroupData;
		private int mExpandedGroupLayout;
		private int mCollapsedGroupLayout;
		private String[] mGroupFrom;
		private int[] mGroupTo;

		private List<? extends List<? extends Map<String, ?>>> mChildData;
		private int mChildLayout;
		private int mLastChildLayout;
		private String[] mChildFrom;
		private int[] mChildTo;

		private LayoutInflater mInflater;

		/**
		 * ��������һ�����캯��������From��To�ĺ���Ͳ�ͬ��ListView��ͬ��
		 * ���Բο�ListView����SimpleExpandableListViewAdapter
		 * 
		 * @param context
		 * @param groupData
		 * @param groupLayout
		 * @param groupFrom
		 * @param groupTo
		 * @param childData
		 * @param childLayout
		 * @param childFrom
		 * @param childTo
		 */
		public TrainingExpandableListViewAdapter(Context context,
				List<? extends Map<String, String>> groupData, int groupLayout,
				String[] groupFrom, int[] groupTo,
				List<? extends List<? extends Map<String, ?>>> childData,
				int childLayout, String[] childFrom, int[] childTo) {
			this(context, groupData, groupLayout, groupLayout, groupFrom, groupTo,
					childData, childLayout, childLayout, childFrom, childTo);
		}

		/**
		 * 
		 * @param context
		 * @param groupData
		 * @param expandedGroupLayout
		 * @param collapsedGroupLayout
		 * @param groupFrom
		 * @param groupTo
		 * @param childData
		 * @param childLayout
		 * @param lastChildLayout
		 * @param childFrom
		 * @param childTo
		 */
		public TrainingExpandableListViewAdapter(Context context,
				List<? extends Map<String, String>> groupData, int expandedGroupLayout,
				int collapsedGroupLayout, String[] groupFrom, int[] groupTo,
				List<? extends List<? extends Map<String, ?>>> childData,
				int childLayout, int lastChildLayout, String[] childFrom,
				int[] childTo) {
			mGroupData = groupData;
			mExpandedGroupLayout = expandedGroupLayout;
			mCollapsedGroupLayout = collapsedGroupLayout;
			mGroupFrom = groupFrom;
			mGroupTo = groupTo;
			mChildData = childData;
			mChildLayout = childLayout;
			mLastChildLayout = lastChildLayout;
			mChildFrom = childFrom;
			mChildTo = childTo;
			mInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		@Override
		public Object getChild(int groupPosition, int childPosition) {
			// ȡ����ָ�����顢ָ������Ŀ���������ݡ�
			return mChildData.get(groupPosition).get(childPosition);
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			// ȡ�ø��������и�������ͼ��ID�� ����ID������������Ψһ�ġ���ϵ�ID ���μ�getCombinedGroupId(long)��
			// ���벻ͬ����������ID�����鼰����Ŀ��ID����
			return childPosition;
		}

		@Override
		public View getChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {
			// ȡ����ʾ�������������λ�õ������õ���ͼ��
			View v;
			if (convertView == null) {
				v = newChildView(isLastChild, parent);
			} else {
				v = convertView;
			}
			bindChildView(v, mChildData.get(groupPosition).get(childPosition),
					mChildFrom, mChildTo);
			return v;
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			// ȡ��ָ���������Ԫ������
			return mChildData.get(groupPosition).size();
		}

		@Override
		public Object getGroup(int groupPosition) {
			// ȡ�������������������ݡ�
			return mGroupData.get(groupPosition);
		}

		@Override
		public int getGroupCount() {
			// ȡ�÷�����
			return mChildData.size();
		}

		@Override
		public long getGroupId(int groupPosition) {
			// ȡ��ָ�������ID������ID������������Ψһ�ġ���ϵ�ID ���μ�getCombinedGroupId(long)��
			// ���벻ͬ����������ID�����鼰����Ŀ��ID����
			return groupPosition;
		}

		@Override
		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			// ȡ��������ʾ�����������ͼ�� ������������ط������ͼ���� Ҫ���ȡ��Ԫ�ص���ͼ����
			// ����Ҫ���� getChildView(int, int, boolean, View, ViewGroup)��
			View v;
			if (convertView == null) {
				v = newGroupView(isExpanded, parent);
			} else {
				v = convertView;
			}
			bindGroupView(v, mGroupData.get(groupPosition), mGroupFrom, mGroupTo);
			return v;
		}

		@Override
		public boolean hasStableIds() {
			// �Ƿ�ָ��������ͼ��������ͼ��ID��Ӧ�ĺ�̨���ݸı�Ҳ�ᱣ�ָ�ID��
			return true;
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			// ָ��λ�õ�����ͼ�Ƿ��ѡ��
			return true;
		}

		/**
		 * �����µ�����ͼ
		 * 
		 * @param isExpanded
		 * @param parent
		 * @return
		 */
		public View newGroupView(boolean isExpanded, ViewGroup parent) {
			return mInflater.inflate((isExpanded) ? mExpandedGroupLayout
					: mCollapsedGroupLayout, parent, false);
		}

		/**
		 * �����µ�����ͼ
		 * 
		 * @param isLastChild
		 * @param parent
		 * @return
		 */
		public View newChildView(boolean isLastChild, ViewGroup parent) {
			return mInflater.inflate((isLastChild) ? mLastChildLayout
					: mChildLayout, parent, false);
		}

		/**
		 * ��������
		 * 
		 * @param view
		 * @param data
		 * @param from
		 * @param to
		 */
		private void bindGroupView(View view, Map<String, ?> data, String[] from,
				int[] to) {
			// ������ͼ�����ݣ����Group��Layout����TextView�����
			TextView v0 = (TextView) view.findViewById(to[0]);
			if (v0 != null) {
				v0.setText((String) data.get(from[0]));
			}
			
			TextView v1 = (TextView) view.findViewById(to[1]);
			if (v1 != null) {
				v1.setText((String) data.get(from[1]));
			}

			TextView v2 = (TextView) view.findViewById(to[2]);
			if (v2 != null) {
				v2.setText((String) data.get(from[2]));
			}

			ProgressBar b = (ProgressBar) view.findViewById(to[3]);
			
			view.setTag(b);
			b.setProgress(Integer.valueOf((String)data.get(from[3])));
			b.setMax(Integer.valueOf((String)data.get(from[4])));
		}

		public void updateGroupData(int groupPosition) {
			String progress = (String) mGroupData.get(groupPosition).get("plan_weekProgressBarProgress");
			String max = (String)mGroupData.get(groupPosition).get("plan_weekProgressBarMax");
			
			mGroupData.get(groupPosition).remove("plan_weekProgressBarProgress");
			mGroupData.get(groupPosition).remove("plan_weekProgressBarMax");
			
			mGroupData.get(groupPosition).put("plan_weekProgressBarProgress", progress);
			mGroupData.get(groupPosition).put("plan_weekProgressBarMax", max);
			
		}
		/**
		 * ��������
		 * 
		 * @param view
		 * @param data
		 * @param from
		 * @param to
		 */
		private void bindChildView(View view, Map<String, ?> data, String[] from,
				int[] to) {
			
			String day = (String) data.get(from[0]);
			int color = MainActivity.COLOR_SKYBLUE;
			if(day.equals("�������")){
				color = MainActivity.COLOR_ORANGE;
			}
			
			TextView v1 = (TextView) view.findViewById(to[0]);
			if (v1 != null) {
				v1.setTextColor(color);
				v1.setText(day);
			}
			
			TextView v2 = (TextView) view.findViewById(to[1]);
			if (v2 != null) {
				v2.setTextColor(color);
				v2.setText((String) data.get(from[1]));
			}

			TextView v3 = (TextView) view.findViewById(to[2]);
			if (v3 != null) {
				v3.setText((String) data.get(from[2]));
			}
			TextView v4 = (TextView) view.findViewById(to[3]);
			if (v4 != null) {
				v4.setText((String) data.get(from[3]));
			}
		}
	}

}
