package cn.candone.appstepfun.pedo;

import cn.candone.appstepfun.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.location.LocationManagerProxy;
import com.amap.api.location.LocationProviderProxy;
import com.amap.api.maps.LocationSource;

import cn.candone.appstepfun.MainActivity;
import cn.candone.appstepfun.PreferencesData;
import cn.candone.appstepfun.helper.LogcatHelper;
import cn.candone.appstepfun.helper.StepFunDBHelper;
import cn.candone.appstepfun.helper.HttpConnection;
import cn.candone.appstepfun.helper.HttpConnection.CallbackListener;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.GpsStatus;
import android.location.Location;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;


public class PedoService extends Service implements AMapLocationListener,
	LocationSource {
	private static final int NOTIFY_PEDO_ID = 1314;
	
	public static final String UPDATE_STEP = "Update Step";
	public static final String UPDATE_USERGROUP = "Update UserGroup";
	public static final String SWITCH_GPS = "Switch GPSService";
	
	private static final int REPORT_PEDO_PERIOD = 10;  //10s 
	
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private PedoDetector mPedoDetector;
    private PedoDisplayer mPedoDisplayer;

    private int mSteps;
    private String mStepDay = "";
    private int mReportedSteps = -1;
    
    private int mPedoStoreMiniutes = 0;
    
    private JSONObject mPedoReportJSON = new JSONObject();
    private JSONArray mGroupArray = new JSONArray();
    private JSONArray mHideGroupArray = new JSONArray();
    private JSONArray mFamousGroupArray = new JSONArray();
    
    private PreferencesData mPrefData;
    
    private NotificationManager mNotifyManager;
    private NotificationCompat.Builder mBuilder;
    
	private OnLocationChangedListener mListener;
	private LocationManagerProxy mAMapLocationManager;
	private double mLatitude, mLongitude;
	private boolean mMapTracking = false;
	
    public class PedoBinder extends Binder {
        public PedoService getService() {
            return PedoService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        
        LogcatHelper.getInstance(this).start();  
                
        System.out.println("PedoService onCreate.");

        mNotifyManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mBuilder = new NotificationCompat.Builder(this);

        // load saved perference data
        LoadSharedPerferenceData();

        // Start detecting
        mPedoDetector = new PedoDetector();
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        registerDetector();

        // Register our receiver for the ACTION_SCREEN_OFF action. This will make our receiver
        // code be called whenever the phone enters standby mode.
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mReceiver, filter);

        IntentFilter filterSystemTimer = new IntentFilter(Intent.ACTION_TIME_TICK);
        registerReceiver(mReceiver, filterSystemTimer);

        IntentFilter filterUpdateStep = new IntentFilter(UPDATE_STEP);
        registerReceiver(mReceiver, filterUpdateStep);
        
        IntentFilter filterUpdateUserGroup = new IntentFilter(UPDATE_USERGROUP);
        registerReceiver(mReceiver, filterUpdateUserGroup);

        IntentFilter filterSetLocationService = new IntentFilter(SWITCH_GPS);
        registerReceiver(mReceiver, filterSetLocationService);

        mPedoDisplayer = new PedoDisplayer();
        mPedoDisplayer.setSteps(mSteps);
        mPedoDisplayer.addListener(mPedoListener);
        mPedoDetector.addPedoListener(mPedoDisplayer);

    	//start timer
        timerHandler.postDelayed(timerRunnable,5000);
        
        //caculate a random minutes between 0~10m to do pedo store per hour 
        mPedoStoreMiniutes = (int) (Math.random() * 10); 
        System.out.println("Pedo Store at time: " + mPedoStoreMiniutes);
        
		mAMapLocationManager = LocationManagerProxy.getInstance(this);
		mAMapLocationManager.setGpsEnable(false);
		mAMapLocationManager.requestLocationData(
				LocationProviderProxy.AMapNetwork, 5 * 1000, 10, this);
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!mPrefData.getUserID().equals("")){
    		UpdateReportPedoGroups();
        }
		
		/// set PedoService as foreground so that it is less likely to be killed by system
        Intent it = new Intent(this,MainActivity.class);
        it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, it, 0);           

		if (mAMapLocationManager != null) {
			mAMapLocationManager.requestLocationData(
					LocationProviderProxy.AMapNetwork, 5 * 1000, 10, this);
		}
		
        mBuilder.setContentIntent(pi);
	    mBuilder.setContentTitle(getString(R.string.app_name));
	    mBuilder.setSmallIcon(R.drawable.app_icon);
	    mBuilder.setContentText("�����Ѿ����" + mSteps + "��          Ŀ��: " + mPrefData.getUserTarget() +"��" );
	    mBuilder.setWhen(System.currentTimeMillis());
	    mBuilder.setProgress(mPrefData.getUserTarget(), mSteps, false);
	    mBuilder.setTicker(getString(R.string.app_name));
	    mBuilder.setAutoCancel(false);

	    //mNotifyManager.notify(NOTIFY_PEDO_ID, mBuilder.build());
	    startForeground(NOTIFY_PEDO_ID, mBuilder.build());
	    
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        System.out.println("PedoService onDestroy.");

        //stop location service.
        deactivate();

		
		// save history step info on exit.
        Calendar cd = Calendar.getInstance();
        StepFunDBHelper.insert_StepHistory(getBaseContext(), mPrefData.getUserID(), mPrefData.getUserName(),
				                 mSteps, cd.getTime().getTime());

        // Unregister our receiver.
        unregisterReceiver(mReceiver);
        unregisterDetector();
        
        // Stop detecting
        mSensorManager.unregisterListener(mPedoDetector);

        // Stop timer
        timerHandler.removeCallbacks(timerRunnable);

        //save steps into shared perference data.

        SaveSharedPerferenceData();
 
        mNotifyManager.cancel(NOTIFY_PEDO_ID);
        stopForeground(true);
        
        super.onDestroy();

    }

    private void registerDetector() {
        mSensor = mSensorManager.getDefaultSensor(
            Sensor.TYPE_ACCELEROMETER /*| 
            Sensor.TYPE_MAGNETIC_FIELD | 
            Sensor.TYPE_ORIENTATION*/);
        mSensorManager.registerListener(mPedoDetector,
            mSensor,
            SensorManager.SENSOR_DELAY_FASTEST);
    }

    private void unregisterDetector() {
        mSensorManager.unregisterListener(mPedoDetector);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /**
     * Receives messages from activity.
     */
    private final IBinder mBinder = new PedoBinder();

    public interface ICallback {
        public void stepsChanged(int value);
        public void locationChanged(double latitude,
        		double longitude, 
        		double speed, 
        		String city, 
        		String citycode, 
        		String provider);
    }
    
    private ICallback mCallback;

    public void registerCallback(ICallback cb) {
        mCallback = cb;
        //mPedoDisplayer.passValue();
    }
    
    /**
     * Forwards pace values from PaceNotifier to the activity. 
     */
    private PedoDisplayer.Listener mPedoListener = new PedoDisplayer.Listener() {
        public void stepsChanged(int value) {
            mSteps = value;
            passValue();
        
            mBuilder.setProgress(mPrefData.getUserTarget(), mSteps, false);
            mBuilder.setWhen(System.currentTimeMillis());
        	mBuilder.setContentText("�����Ѿ����" + mSteps + "��             Ŀ��: " + mPrefData.getUserTarget() +"��" );
        	if(mPrefData.getTargetReminder() && mSteps == 13100){  //mPrefData.getUserTarget()
            	mBuilder.setTicker("����Ŀ���Ѿ����" );
        	}
            mNotifyManager.notify(NOTIFY_PEDO_ID, mBuilder.build());

        }
        public void passValue() {
            if (mCallback != null) {
                mCallback.stepsChanged(mSteps);
            }
        }
    };
    
    // BroadcastReceiver for handling ACTION_SCREEN_OFF.
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Check action just to be on the safe side.
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                // Unregisters the listener and registers it again.
                PedoService.this.unregisterDetector();
                PedoService.this.registerDetector();
            }else if(intent.getAction().equals(Intent.ACTION_TIME_TICK)){
    	    	// system tick called every 1m.
            	Calendar cd = Calendar.getInstance();
            	int minute = cd.get(Calendar.MINUTE);
            	int hour = cd.get(Calendar.HOUR_OF_DAY);

    	    	if(minute == 0 ){
    	    		// save history step info every 1 hour.
    	    		StepFunDBHelper.insert_StepHistory(getBaseContext(), mPrefData.getUserID(), mPrefData.getUserName(),
	    					mSteps, cd.getTime().getTime());
    	    		
    	    		if(hour == 0){
    	    			//clear steps every day.
    		    		mPedoDisplayer.setSteps(mSteps = 0);
    			    	//update UI to refresh steps.
    			    	mPedoListener.passValue();
    			    	SaveSharedPerferenceData();
    	    		}

    	    		//record the steps for the last hour to be reported.
    	    		mPrefData.setUserHourSteps(mSteps);
    	    	}

    	    	// report pedo per hour
    	    	if(minute == mPedoStoreMiniutes){
    	    		
   	    			ExecutePedoStore(mPrefData.getUserHourSteps(), cd.getTime());
    	    	}


            }else if(intent.getAction().equals(UPDATE_STEP)){
            	mPedoListener.passValue();
            }else if(intent.getAction().equals(UPDATE_USERGROUP)){
            	UpdateReportPedoGroups();
            }else if(intent.getAction().equals(SWITCH_GPS)){
            	boolean locationServiceOnOff = intent.getBooleanExtra(SWITCH_GPS, false);
    			System.out.println("Location service: " + locationServiceOnOff);
    			if(locationServiceOnOff){
    				mMapTracking = true;

    				if(mAMapLocationManager == null){
    					mAMapLocationManager = LocationManagerProxy.getInstance(PedoService.this);
    				}
    				mAMapLocationManager.removeUpdates(PedoService.this);
    				
					mAMapLocationManager.setGpsEnable(true);
					mAMapLocationManager.requestLocationData(
							LocationProviderProxy.AMapNetwork, 5 * 1000, 10, PedoService.this);
            	}else{
            		mMapTracking = false;
            		deactivate();
            	}
            }
        }
    };

	private CallbackListener ReportPedoCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						//System.out.println("report steps success ");
						
					}else{
						System.out.println("report pedo failed");
					}
					
				} catch (JSONException e) {
					System.out.println("parse report pedo result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};
	
    public void ExecuteReportPedo(Date curDate) {
    	
    	if(!mPrefData.getUserID().equals("") && mPedoReportJSON.has("groupName")){
        	JSONObject reportObj = new JSONObject();
        	reportObj = mPedoReportJSON;
        	
        	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getResources().getConfiguration().locale);       
	       	String date = formatter.format(curDate);

            /**
             * json={"groupName":[{"groupName":"������"},{"groupName":"������"}],
             * "userId":"5393285372d656bd38d964b9","userName":"�Ϲٴ���","steps":317,
             * "date":"2014-06-07 11:06:47"}
             */
            try {
            	reportObj.put("steps", "" + mSteps);
            	reportObj.put("date", date);
            	

    		} catch (JSONException e) {
    			System.out.println("create report pedo failed.");
    		}
            String reportPedoStr = "json=" + reportObj.toString();
            
            
        	HttpConnection conn = new HttpConnection();
        	conn.post("/pedo/report", reportPedoStr, ReportPedoCallbackListener);
    	}
    }
    
	private CallbackListener PedoStoreCallbackListener = new HttpConnection.CallbackListener() {
		@Override
		public void callBack(String v) {
			if(v.equals("fail")) {
				System.out.println("network tranfer error");
			} else {
				/**
				 * response JSON format: 
				 *  {"result":"success"} or
				 *  {"result":"failed"}
				 */
				try {
					JSONObject obj = new JSONObject(v);  
					String result = obj.getString("result");
					if(result.equals("success")){
						//System.out.println("pedo store success ");
						
					}else{
						System.out.println("pedo store failed");
					}
					
				} catch (JSONException e) {
					System.out.println("parse pedo sore result failed");
				}
			}
			//progressDialog.dismiss();
		}
	};

    public void ExecutePedoStore(int steps, Date curDate) {
    	
    	if(!mPrefData.getUserID().equals("") && mPedoReportJSON.has("groupName")){
        	JSONObject reportObj = new JSONObject();
        	reportObj = mPedoReportJSON;
        	
        	
        	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", getResources().getConfiguration().locale);       
	       	String date = formatter.format(curDate);

            /**
             * json={"groupName":[{"groupName":"������"},{"groupName":"������"}],
             * "userId":"5393285372d656bd38d964b9","userName":"�Ϲٴ���","steps":317,
             * "date":"2014-06-07 11:06:47"}
             */
            try {
            	reportObj.put("steps", "" + steps);
            	reportObj.put("date", date);
            	

    		} catch (JSONException e) {
    			System.out.println("create pedo store failed.");
    		}
            String reportPedoStr = "json=" + reportObj.toString();
            
            System.out.println("hour store(" + date + "): " + steps + "��");
            
        	HttpConnection conn = new HttpConnection();
        	conn.post("/group/pedostore", reportPedoStr, PedoStoreCallbackListener);
    	}
    }
    
    // Timer handler called per REPORT_PEDO_PERIOD s -- report pedo
    private Handler timerHandler = new Handler( );
    //private int timerCount = 0;
    private Runnable timerRunnable = new Runnable( ){
	    public void run ( ) {

	    	//timerCount ++;
	    	Calendar cd=Calendar.getInstance();
	    	//System.out.println("dynamic limit: " + mPedoDetector.getCurrentDynamicLimit());
	    	
	    	// report & save pedo every 10s;
	    	//if(timerCount > REPORT_PEDO_PERIOD)
	    	{
	    		if(mSteps != mReportedSteps){
			    	mReportedSteps = mSteps;
			    	mStepDay = cd.get(Calendar.YEAR) + "-" + (cd.get(Calendar.MONTH) + 1) + "-" + cd.get(Calendar.DAY_OF_MONTH);
	
			    	System.out.println(mSteps + "��");
	
			    	ExecuteReportPedo(cd.getTime());
			    	SaveSharedPerferenceData();
	    		}
	    		//timerCount = 0;
	    	}
			
            timerHandler.postDelayed(this, REPORT_PEDO_PERIOD *1000);
            
	    }
    };


	private void LoadSharedPerferenceData(){

		mPrefData = (PreferencesData) getApplicationContext();
        mPrefData.LoadUserLoginInfo();
        mPrefData.LoadGroupArrayInfo();
		mPrefData.LoadPedoInfo();
		mPrefData.LoadLocationInfo();
		
		mLatitude = mPrefData.getLastLatitude();
		mLongitude = mPrefData.getLastLongtitude();

        //mUserID = mPrefData.getUserID();
        //mUserName = mPrefData.getUserName();

        Calendar cd=Calendar.getInstance();
        String curDate = cd.get(Calendar.YEAR) + "-" + (cd.get(Calendar.MONTH) + 1) + "-" + cd.get(Calendar.DAY_OF_MONTH);
        System.out.println("Today: " + curDate);

        mStepDay = mPrefData.getUserStepDay();

        if(mStepDay.equals(curDate)){
        	mSteps = mPrefData.getUserSteps();
        }else{
        	mSteps = 0;
        	mStepDay = curDate;
        	SaveSharedPerferenceData();
        }
	}

	private void SaveSharedPerferenceData(){
		// update user state in preference
		mPrefData.setLastLatitude(mLatitude);
		mPrefData.setLastLongtitude(mLongitude);
		mPrefData.SaveLocationInfo();
		
    	mPrefData.setUserSteps(mSteps);
    	mPrefData.setUserStepDay(mStepDay);
    	mPrefData.SavePedoInfo();
	}
	
	private void UpdateReportPedoGroups(){
		mPedoReportJSON = new JSONObject();
		
		JSONArray groupNameArray = GetGroupArrayInfo();
        /**
         * json={"groupName":[{"groupName":"������"},{"groupName":"������"}],
         * "userId":"5393285372d656bd38d964b9","userName":"�Ϲٴ���"}
         */
        try {
        	if(groupNameArray.length() > 0){
        		mPedoReportJSON.put("groupName", groupNameArray);
        	}
        	mPedoReportJSON.put("userId", mPrefData.getUserID());
        	mPedoReportJSON.put("userName", mPrefData.getUserName());
        	//System.out.println("Pedo Service: " + mPedoReportJSON.toString());
		} catch (JSONException e) {
			System.out.println("prepare mReportGroupObj failed.");
		}
        
	}
		
	private JSONArray GetGroupArrayInfo(){
		
		String groupArrayStr = mPrefData.getGroupArray();
		String famousGroupArrayStr = mPrefData.getFamousGroupArray();
		String hideGroupArrayStr = mPrefData.getHideGroup();
		
		JSONArray newGroupNameArray = new JSONArray();

		try{
			if(!groupArrayStr.equals("")){
				mGroupArray = new JSONArray(groupArrayStr);
			}
			
			if(!hideGroupArrayStr.equals("")){
				mHideGroupArray =  new JSONArray(hideGroupArrayStr);
			}

			if(!famousGroupArrayStr.equals("")){
				mFamousGroupArray = new JSONArray(famousGroupArrayStr);
			}
	
			int hideGroupCount = mHideGroupArray.length();
			int groupCount = mGroupArray.length();
			for(int i=0; i<groupCount; i++){
				JSONObject groupEntry = mGroupArray.getJSONObject(i);
				String groupName = groupEntry.getString("groupName");
				
				boolean isHideGroup = false;
				for(int j=0; j<hideGroupCount; j++){
					JSONObject hidegroupEntry = mHideGroupArray.getJSONObject(j);
					String hideGroupName = hidegroupEntry.getString("groupName");
					if(hideGroupName.equals(groupName)){
						isHideGroup = true;
						break;
					}
				}
				
				if(!isHideGroup){
					JSONObject newGroupEntry = new JSONObject();
					newGroupEntry.put("groupName", groupName);
					
					newGroupNameArray.put(newGroupEntry);
				}
			}
			
			int famousGroupCount = mFamousGroupArray.length();
			for(int i=0; i<famousGroupCount; i++){
				JSONObject groupEntry = mFamousGroupArray.getJSONObject(i);
				String groupName = groupEntry.getString("groupName");
				
				boolean isHideGroup = false;
				for(int j=0; j<hideGroupCount; j++){
					JSONObject hidegroupEntry = mHideGroupArray.getJSONObject(j);
					String hideGroupName = hidegroupEntry.getString("groupName");
					if(hideGroupName.equals(groupName)){
						isHideGroup = true;
						break;
					}
				}
				
				if(!isHideGroup){
					JSONObject newGroupEntry = new JSONObject();
					newGroupEntry.put("groupName", groupName);
					
					newGroupNameArray.put(newGroupEntry);
				}				
			}

		}catch(JSONException e){
			System.out.println("UpdateReportGroupInfo: " + e.toString());
		}

		return newGroupNameArray;
	    
	}

	@Override
	public void onLocationChanged(Location Location) {
	}

	@Override
	public void onProviderDisabled(String provider) {
	}

	@Override
	public void onProviderEnabled(String provider) {
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
	}

	@Override
	public void activate(OnLocationChangedListener listener) {
		mListener = listener;
		if (mAMapLocationManager == null) {
			mAMapLocationManager = LocationManagerProxy.getInstance(this);
			mAMapLocationManager.setGpsEnable(true);
			mAMapLocationManager.requestLocationData(
					LocationProviderProxy.AMapNetwork, 5 * 1000, 10, this);

		}
	}

	@Override
	public void deactivate() {
		mListener = null;
		if (mAMapLocationManager != null) {
			mAMapLocationManager.setGpsEnable(false);
			mAMapLocationManager.removeUpdates(this);
			mAMapLocationManager.destroy();
		}
		mAMapLocationManager = null;
	}

	@Override
	public void onLocationChanged(AMapLocation aLocation) {
		if (mListener != null && aLocation != null
				&& aLocation.getAMapException().getErrorCode() == 0) {
			double speed = 0;
			String citycode = "";
			String city="";
			String provider = "";
			
			mLatitude = aLocation.getLatitude();
			mLongitude = aLocation.getLongitude();
			if (aLocation.getProvider().equals("gps")) {
				speed = aLocation.getSpeed();
				provider = "gps";
			} else if (aLocation.getProvider().equals("lbs")) {
				provider = "lbs";
				citycode = aLocation.getCityCode();
				city=aLocation.getCity();
			}
			mListener.onLocationChanged(aLocation);
			
            if (mCallback != null) {
                mCallback.locationChanged(mLatitude, mLongitude, speed, city, citycode, provider);
            }
		}
	}
}
